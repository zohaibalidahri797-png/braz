#!/usr/bin/env bash
#
# BotDock Cloud release packaging.
#
# Produces TWO independent archives from the same verified tree:
#   download/botdock-cloud.zip     → extracts to botdock-cloud/
#   download/botdock-cloud.tar.gz  → extracts to botdock-cloud/
#
# Then validates both: integrity, extraction, tree diff, essential files,
# and confirms neither archive contains the other archive.
#
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT_DIR="$ROOT/download"
STAGE="$(mktemp -d)"
PKG_NAME="botdock-cloud"

trap 'rm -rf "$STAGE"' EXIT

echo "==> staging $PKG_NAME"
mkdir -p "$STAGE/$PKG_NAME" "$OUT_DIR"

# ── Copy the project, excluding runtime/build/sandbox-only artifacts ─────────
# (Exclusions are deliberate and documented; the lockfile and deployment
#  configs are preserved.)
rsync -a \
  --exclude node_modules/ \
  --exclude .next/ \
  --exclude .open-next/ \
  --exclude .git/ \
  --exclude .zscripts/ \
  --exclude .wrangler/ \
  --exclude .claude/ \
  --exclude .z-ai-config \
  --include '.env.example' \
  --include '.dev.vars.example' \
  --exclude '.env' \
  --exclude '.env.*' \
  --exclude '.dev.vars' \
  --exclude skills/ \
  --exclude bot-data/ \
  --exclude '/upload/' \
  --exclude '/download/' \
  --exclude tool-results/ \
  --exclude .tmp-verify/ \
  --exclude public/releases/ \
  --exclude 'db/*.db' \
  --exclude 'db/*.db.backup-*' \
  --exclude 'db/*.db-journal' \
  --exclude 'db/*.db-wal' \
  --exclude 'db/*.db-shm' \
  --exclude '*.log' \
  --exclude dev.out.log \
  --exclude server.log \
  --exclude worklog.md \
  --exclude '*.tsbuildinfo' \
  --exclude botdock-cloud.zip \
  --exclude botdock-cloud.tar.gz \
  --exclude botdock-cloud.tar \
  "$ROOT/" "$STAGE/$PKG_NAME/"

# keep the (now empty) db folder in the archives
mkdir -p "$STAGE/$PKG_NAME/db"
touch "$STAGE/$PKG_NAME/db/.gitkeep"

# ── Build archives ───────────────────────────────────────────────────────────
# NOTE: `zip -r` MERGES into an existing archive instead of replacing it —
# remove stale outputs first or old (possibly non-compliant) content survives.
rm -f "$OUT_DIR/botdock-cloud.zip" "$OUT_DIR/botdock-cloud.tar.gz" "$OUT_DIR/botdock-cloud.tar" "$OUT_DIR/botdock-cloud-fixed.zip"

echo "==> building botdock-cloud.zip"
( cd "$STAGE" && zip -q -r -X "$OUT_DIR/botdock-cloud.zip" "$PKG_NAME" )

echo "==> building botdock-cloud.tar.gz"
( cd "$STAGE" && tar -czf "$OUT_DIR/botdock-cloud.tar.gz" "$PKG_NAME" )

# The REQUIRED deliverable filename (identical bytes to the validated zip above;
# produced AFTER validation so it can only ever be a copy of a verified archive).
# (Validation below runs before this copy is finalized — see bottom of script.)

# ── Validation ───────────────────────────────────────────────────────────────
echo "==> validating"
fail() { echo "VALIDATION FAILED: $1" >&2; exit 1; }

# 1. integrity
unzip -t "$OUT_DIR/botdock-cloud.zip" > /dev/null || fail "zip integrity"
tar -tzf "$OUT_DIR/botdock-cloud.tar.gz" > /dev/null || fail "tar integrity"

# 2. extract both
EX1="$STAGE/zip-extract"; EX2="$STAGE/tar-extract"
mkdir -p "$EX1" "$EX2"
unzip -q "$OUT_DIR/botdock-cloud.zip" -d "$EX1"
tar -xzf "$OUT_DIR/botdock-cloud.tar.gz" -C "$EX2"

[ -d "$EX1/$PKG_NAME" ] || fail "zip does not extract to $PKG_NAME/"
[ -d "$EX2/$PKG_NAME" ] || fail "tar does not extract to $PKG_NAME/"

# 3. same file lists + same contents
diff <( cd "$EX1/$PKG_NAME" && find . -type f | sort ) \
     <( cd "$EX2/$PKG_NAME" && find . -type f | sort ) \
     || fail "extracted file lists differ"
diff -r "$EX1/$PKG_NAME" "$EX2/$PKG_NAME" || fail "extracted contents differ"

# 4. essential files
for f in package.json bun.lock src/app/page.tsx prisma/schema.prisma \
         prisma/migrations/20260320000000_init/migration.sql \
         wrangler.jsonc open-next.config.ts .env.example .dev.vars.example \
         scripts/cf-verify.mjs scripts/cf-clean.mjs tests/worker-route-matrix.sh \
         README.md \
         .github/workflows/ci.yml tests/runtime-config.test.ts \
         tests/health.test.ts src/lib/platform-health.ts \
         mini-services/bot-runtime/package.json docs/DEPLOYMENT.md \
         docs/RUNTIME-DEPLOYMENT.md docs/SETUP.md docs/ARCHITECTURE.md \
         docs/SECURITY-HYGIENE.md scripts/package-release.sh; do
  [ -f "$EX1/$PKG_NAME/$f" ] || fail "missing essential file: $f"
done

# 4b. no private data or dev artifacts staged
if ls "$EX1/$PKG_NAME"/db/*.db >/dev/null 2>&1; then fail "database files must not be packaged"; fi
if [ -f "$EX1/$PKG_NAME/.env" ]; then fail ".env must not be packaged"; fi
if [ -f "$EX1/$PKG_NAME/worklog.md" ]; then fail "internal worklog must not be packaged"; fi
if ls "$EX1/$PKG_NAME"/*.tsbuildinfo >/dev/null 2>&1; then fail "build artifacts must not be packaged"; fi

# 5. no nested archive copies (never an archive that only contains an archive)
if ( cd "$EX1/$PKG_NAME" && find . -type f \( -name 'botdock-cloud.zip' -o -name 'botdock-cloud.tar.gz' -o -name 'botdock-cloud.tar' \) | grep -q . ); then
  fail "archives must not contain copies of themselves"
fi

# 6. no secrets staged
if [ -f "$EX1/$PKG_NAME/.env" ]; then fail ".env must not be packaged"; fi
# Cross-check: every non-empty VALUE of a secret-keyed line in the local .env
# (if present) must not appear anywhere in the staged tree. Values are never
# printed. Only real secret keys are scanned — non-credentials like APP_URL or
# DATABASE_URL (a local file path) legitimately appear in docs/examples.
if [ -f "$ROOT/.env" ]; then
  SECRET_KEYS='^(APP_SECRET|RUNTIME_API_KEY|ADMIN_BOOTSTRAP_TOKEN|LIBSQL_AUTH_TOKEN|STRIPE_SECRET_KEY|STRIPE_WEBHOOK_SECRET|RESEND_API_KEY|GOOGLE_CLIENT_SECRET|GITHUB_CLIENT_SECRET|TELEGRAM_BOT_TOKEN)='
  while IFS='=' read -r k v; do
    v="${v%\"}"; v="${v#\"}"; v="${v%\'}"; v="${v#\'}"
    [ -n "$v" ] || continue
    if grep -rqF -- "$v" "$EX1/$PKG_NAME" 2>/dev/null; then
      fail "secret value of $k from local .env leaked into the staged tree"
    fi
  done < <(grep -E "$SECRET_KEYS" "$ROOT/.env" || true)
fi
# Placeholder hygiene: .env.example must contain no real-looking keys.
if grep -Eq '(sk_live_|whsec_[A-Za-z0-9]{8,}|postgres://[^@\s]+:[^@\s]+@|libsql://[a-z0-9-]+\.turso\.io)' "$EX1/$PKG_NAME/.env.example" 2>/dev/null; then
  fail ".env.example contains a real-looking credential pattern"
fi

FILES=$(cd "$EX1/$PKG_NAME" && find . -type f | wc -l)
ZIP_MB=$(du -m "$OUT_DIR/botdock-cloud.zip" | cut -f1)
TAR_MB=$(du -m "$OUT_DIR/botdock-cloud.tar.gz" | cut -f1)

echo "==> OK: $FILES files; zip ${ZIP_MB}MB; tar.gz ${TAR_MB}MB"

# ── REQUIRED deliverable: botdock-cloud-fixed.zip ────────────────────────────
# Copy of the now fully validated zip under the mandatory deliverable name,
# plus integrity re-check of the copy itself.
cp "$OUT_DIR/botdock-cloud.zip" "$OUT_DIR/botdock-cloud-fixed.zip"
unzip -t "$OUT_DIR/botdock-cloud-fixed.zip" > /dev/null || fail "botdock-cloud-fixed.zip integrity"
FIXED_MB=$(du -m "$OUT_DIR/botdock-cloud-fixed.zip" | cut -f1)
echo "==> REQUIRED deliverable ready: $OUT_DIR/botdock-cloud-fixed.zip (${FIXED_MB}MB, $FILES files)"

# ── REQUIRED deliverable: botdock-pages.zip (static frontend only) ───────────
# The Cloudflare Pages Direct Upload artifact: the contents of public/
# (index.html at the archive ROOT — Pages requires that — plus assets/,
# _redirects, favicon.svg, 404.html). Validated: every referenced local
# path in every HTML file must exist in the archive.
echo "==> building botdock-pages.zip (static frontend, Pages Direct Upload)"
PAGES_STAGE="$STAGE/pages/site"
mkdir -p "$PAGES_STAGE"
rsync -a --exclude '/logo.svg' "$ROOT/public/" "$PAGES_STAGE/"
[ -f "$PAGES_STAGE/index.html" ] || fail "pages: index.html missing at archive root"
rm -f "$OUT_DIR/botdock-pages.zip"
( cd "$PAGES_STAGE" && zip -q -r -X "$OUT_DIR/botdock-pages.zip" . )

# every local href/src referenced by the HTML must exist in the archive
PAGE_HITS=$(grep -hoE '(href|src)="/[^"#?]*' "$PAGES_STAGE"/*.html | sed -E 's/(href|src)="\///' | sort -u || true)
MISSING=""
while IFS= read -r rel; do
  [ -z "$rel" ] && continue
  # _redirects-proxied API paths are allowed to be "virtual"
  case "$rel" in api/*) continue ;; esac
  if [ ! -e "$PAGES_STAGE/$rel" ]; then MISSING="$MISSING $rel"; fi
done <<EOF
$PAGE_HITS
EOF
if [ -n "$MISSING" ]; then fail "pages: missing referenced files:$MISSING"; fi
unzip -t "$OUT_DIR/botdock-pages.zip" > /dev/null || fail "botdock-pages.zip integrity"
PAGES_FILES=$(cd "$PAGES_STAGE" && find . -type f | wc -l)
PAGES_KB=$(du -k "$OUT_DIR/botdock-pages.zip" | cut -f1)
echo "==> REQUIRED deliverable ready: $OUT_DIR/botdock-pages.zip (${PAGES_KB}KB, $PAGES_FILES files)"

echo "==> outputs:"
echo "    $OUT_DIR/botdock-pages.zip"
echo "    $OUT_DIR/botdock-cloud-fixed.zip"
echo "    $OUT_DIR/botdock-cloud.zip"
echo "    $OUT_DIR/botdock-cloud.tar.gz"
