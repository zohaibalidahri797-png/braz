import type { Metadata } from "next";
import { Boxes, Cpu, FileCode2, GaugeCircle, Layers, ScrollText, ShieldCheck } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { PageH1, PageLead, PublicPage } from "@/content/public-pages";

export const metadata: Metadata = {
  title: "Features",
  description:
    "Isolated bot hosting: Python/Node/Bun runtimes, per-bot resource protection, real build & runtime logs, file manager, GitHub imports and honest capacity handling.",
  alternates: { canonical: "/features" },
};

const DETAILED = [
  {
    icon: Boxes,
    title: "Three real runtimes",
    body: "Python (requirements.txt / pyproject.toml), Node.js and Bun (package.json). Dependencies are installed automatically during each deployment — with a real build log you can read when something fails.",
  },
  {
    icon: Cpu,
    title: "Per-bot resource protection",
    body: "Memory, CPU share, disk and process limits are system-wide infrastructure policy enforced by the runtime worker, not the dashboard — so one bot can never starve the others. Measured usage (RSS, CPU%) is sampled from the live process and shown next to the policy.",
  },
  {
    icon: ScrollText,
    title: "Honest observability",
    body: "Lifecycle events (created → building → deploying → running/stopped/failed) are timestamped and queryable. A process that exited is reported as exited — never as running.",
  },
  {
    icon: FileCode2,
    title: "File manager & editor",
    body: "Browse, upload, download and edit project files in a workspace jailed to your bot. Path traversal and malicious archives are blocked at the API layer.",
  },
  {
    icon: ShieldCheck,
    title: "Security-first architecture",
    body: "Your code never executes inside the platform process. The control plane talks to isolated runtime workers over an authenticated, server-to-server API. Env vars are AES-256-GCM encrypted at rest and never shown again after saving.",
  },
  {
    icon: GaugeCircle,
    title: "No fixed plan caps — honest capacity",
    body: "Create and manage as many bots as your work needs: no fixed bot-count, deployment, or storage caps during the free launch. Resource use is measured and shown honestly, and if the host runs low on real capacity you get a clear explanation — never an upsell.",
  },
  {
    icon: Layers,
    title: "Deployments from anywhere",
    body: "Start from ready-to-run templates, upload a .zip/.tar.gz archive, or import straight from a GitHub repository with a personal access token (stored encrypted).",
  },
];

export default function FeaturesPage() {
  return (
    <PublicPage>
      <div className="mx-auto max-w-5xl px-4 py-16 sm:px-6">
        <PageH1>Everything a bot operator needs</PageH1>
        <PageLead>
          BotDock Cloud is a real hosting platform: a control plane, isolated runtime workers, and
          data you can trust. Every number in the dashboard is measured — nothing is fabricated.
        </PageLead>
        <div className="mt-10 grid gap-5 sm:grid-cols-2">
          {DETAILED.map((f) => (
            <Card key={f.title} className="transition-colors hover:border-emerald-500/40">
              <CardContent className="pt-6">
                <f.icon className="h-6 w-6 text-emerald-500" />
                <h2 className="mt-3 font-semibold">{f.title}</h2>
                <p className="mt-1.5 text-sm text-muted-foreground">{f.body}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </PublicPage>
  );
}
