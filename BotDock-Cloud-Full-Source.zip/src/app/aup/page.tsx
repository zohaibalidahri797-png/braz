import type { Metadata } from "next";
import Link from "next/link";
import { PageH1, PageLead, PublicPage } from "@/content/public-pages";

export const metadata: Metadata = {
  title: "Acceptable Use Policy",
  description:
    "What you may and may not run on BotDock Cloud: bot content rules, resource fairness, prohibited uses, and how enforcement works.",
  alternates: { canonical: "/aup" },
};

const PROHIBITED = [
  "Breaking any law that applies to you or to the platform operator, including sanctions, export controls and local content rules.",
  "Hosting or distributing malware, botnets, ransomware, phishing kits or credential stealers — including Telegram bots that spread them.",
  "Attacking other services or users: denial-of-service traffic, port scanning, brute-forcing, unauthorised access attempts, or spamming via Telegram or any other channel.",
  "Mining cryptocurrency, or running workloads whose primary purpose is to consume CPU/GPU for profit.",
  "Circumventing the platform's limits and isolation: escaping the runtime sandbox, attempting to access other users' bots or the host system, or probing internal services.",
  "Scraping or reselling the platform itself, or operating a commercial hosting reseller on top of your account.",
  "Content you do not have the rights to distribute, and material that is harassing, hateful or sexualises minors.",
  "Deceptive practices: impersonating BotDock Cloud, phishing for credentials, or misleading users about what a bot does.",
];

const ENFORCEMENT = [
  "First response is usually an automated one: the resource guards (per-bot limits, deploy burst limits) simply stop the behaviour.",
  "Operators or administrators may stop and suspend a specific bot, or suspend an account, when these rules are violated — the owner is notified through the dashboard where possible.",
  "Anything that threatens other users or the host (malware, active attacks) may be removed immediately, without prior notice.",
  "Serious violations may be reported to the relevant authorities where legally required.",
];

export default function AupPage() {
  return (
    <PublicPage>
      <div className="mx-auto max-w-3xl px-4 py-16 sm:px-6">
        <PageH1>Acceptable Use Policy</PageH1>
        <PageLead>
          BotDock Cloud hosts your Telegram bots and automations on shared infrastructure. This
          policy defines what that shared infrastructure may and may not be used for. It applies to
          every account and every bot you deploy. It is part of our{" "}
          <Link href="/terms" className="text-emerald-500 hover:underline">Terms of Service</Link>.
        </PageLead>

        <section className="mt-10">
          <h2 className="text-xl font-bold">The short version</h2>
          <p className="mt-3 text-sm text-muted-foreground">
            Run your own bots. Don&apos;t harm other users, the host, or anyone else. Stay inside
            your own sandbox and the platform&apos;s resource guards. If you wouldn&apos;t want a
            hosting provider to run it against you, don&apos;t run it here.
          </p>
        </section>

        <section className="mt-10">
          <h2 className="text-xl font-bold">Prohibited uses</h2>
          <ul className="mt-3 list-disc space-y-1.5 pl-5 text-sm text-muted-foreground">
            {PROHIBITED.map((item) => (
              <li key={item}>{item}</li>
            ))}
          </ul>
        </section>

        <section className="mt-10">
          <h2 className="text-xl font-bold">Fair resource use</h2>
          <p className="mt-3 text-sm text-muted-foreground">
            Every bot runs with system-wide resource protection (memory, CPU, disk and process
            limits). These are infrastructure protections that apply to everyone equally — they are
            not a product tier. Burst limits on deployments protect the platform from runaway
            automation. Continuously trying to work around them (restart loops, multi-accounting,
            load-shifting between bots) is a violation of this policy.
          </p>
        </section>

        <section className="mt-10">
          <h2 className="text-xl font-bold">Your responsibility</h2>
          <p className="mt-3 text-sm text-muted-foreground">
            You are responsible for the code you deploy and the behaviour of your bots, including
            the Telegram bot token you attach to them. Keep your credentials private: environment
            variables are stored encrypted, but anyone with your token can control your bot.
          </p>
        </section>

        <section className="mt-10">
          <h2 className="text-xl font-bold">Enforcement</h2>
          <ul className="mt-3 list-disc space-y-1.5 pl-5 text-sm text-muted-foreground">
            {ENFORCEMENT.map((item) => (
              <li key={item}>{item}</li>
            ))}
          </ul>
        </section>

        <section className="mt-10">
          <h2 className="text-xl font-bold">Reporting violations</h2>
          <p className="mt-3 text-sm text-muted-foreground">
            Report abuse or policy violations via{" "}
            <Link href="/support" className="text-emerald-500 hover:underline">support</Link>,
            including the bot name and what happened. Security issues follow the process on the{" "}
            <Link href="/security" className="text-emerald-500 hover:underline">security page</Link>.
          </p>
        </section>

        <p className="mt-12 text-xs text-muted-foreground">
          Last updated: October 2026. This policy may be updated as the platform evolves; material
          changes are announced on the dashboard.
        </p>
      </div>
    </PublicPage>
  );
}
