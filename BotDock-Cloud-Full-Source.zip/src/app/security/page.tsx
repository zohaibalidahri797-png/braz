import type { Metadata } from "next";
import Link from "next/link";
import { KeyRound, Lock, ShieldCheck, Terminal } from "lucide-react";
import { PageH1, PageLead, PublicPage } from "@/content/public-pages";

export const metadata: Metadata = {
  title: "Security",
  description:
    "How BotDock Cloud protects accounts and runs untrusted bot code: isolated processes, resource limits, encrypted secrets, and how to report vulnerabilities.",
  alternates: { canonical: "/security" },
};

const PRACTICES = [
  {
    icon: KeyRound,
    title: "Account security",
    items: [
      "Passwords are hashed with bcrypt — plaintext is never stored or logged.",
      "Session cookies are httpOnly, SameSite=Lax and Secure in production; they are database-backed and revocable, so signing out really invalidates the session.",
      "Changing a password signs out every existing session.",
      "OAuth sign-ins (Google/GitHub) exchange codes server-side and are protected against CSRF with single-use state cookies; accounts are only linked when the provider attests the email is verified.",
      "Login, registration and password-reset endpoints are rate-limited per IP and per account.",
      "Every account is email-verified before deployments are allowed.",
    ],
  },
  {
    icon: ShieldCheck,
    title: "Running your code safely",
    items: [
      "Your bot code never executes inside the web application process. Deployments run on a separate runtime service.",
      "Each bot is an isolated OS process with CPU, memory, disk and process-count limits enforced by the operating system.",
      "Bot processes receive a scrubbed environment: platform secrets are never injected into your bot's environment.",
      "Dependency installation happens in the bot's own workspace, with timeouts and size caps.",
      "Project files are jailed to the bot's workspace; path-traversal and malicious archive payloads are rejected at the API layer.",
      "Only the bot's owner (or an administrator) can call its lifecycle and file APIs — ownership is checked server-side on every request.",
    ],
  },
  {
    icon: Lock,
    title: "Data protection",
    items: [
      "Bot environment variables (like BOT_TOKEN) are encrypted at rest with AES-256-GCM and never displayed again after saving.",
      "GitHub personal access tokens used for imports are stored encrypted and are never returned by the API after being set.",
      "Security-relevant actions (sign-ins, OAuth links, deployments, admin actions) are written to an internal audit log with secrets redacted.",
      "Administrative endpoints check the administrator role on the server for every request — hidden buttons are not the security boundary.",
    ],
  },
  {
    icon: Terminal,
    title: "Operational honesty",
    items: [
      "Status is measured, not promised: the status page reports live checks, and no uptime percentage is claimed without monitoring history.",
      "If email delivery or a provider is not configured, the platform says so explicitly instead of pretending an action succeeded.",
      "Deployment states reflect the real process lifecycle — an exited process is reported as exited.",
    ],
  },
];

export default function SecurityPage() {
  return (
    <PublicPage>
      <div className="mx-auto max-w-3xl px-4 py-16 sm:px-6">
        <PageH1>Security</PageH1>
        <PageLead>
          What BotDock Cloud actually does to protect your account and to run untrusted bot code
          safely. This page describes implemented, enforced mechanisms — not aspirations.
        </PageLead>

        <div className="mt-10 space-y-6">
          {PRACTICES.map((group) => (
            <section key={group.title} className="rounded-xl border bg-card/60 p-6">
              <div className="flex items-center gap-2">
                <group.icon className="h-5 w-5 text-emerald-500" />
                <h2 className="font-semibold">{group.title}</h2>
              </div>
              <ul className="mt-3 list-disc space-y-1.5 pl-5 text-sm text-muted-foreground">
                {group.items.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
            </section>
          ))}
        </div>

        <div className="mt-10 rounded-xl border border-amber-500/40 bg-amber-500/5 p-6 text-sm">
          <h2 className="font-semibold text-foreground">Report a vulnerability</h2>
          <p className="mt-2 text-muted-foreground">
            Email <span className="font-mono text-foreground">security@botdock.cloud</span> with a
            description and reproduction steps. Please do not test against other users&apos; accounts
            or data. Responsible disclosures are credited.
          </p>
        </div>

        <div className="mt-6 rounded-xl border bg-card/60 p-6 text-sm text-muted-foreground">
          <h2 className="font-semibold text-foreground">Scope and limitations</h2>
          <p className="mt-2">
            These controls reflect the code as shipped. The platform has not been independently
            audited or certified (no SOC 2 / ISO 27001 claims are made), and free-launch hosting runs
            on shared infrastructure — see the{" "}
            <Link href="/aup" className="text-emerald-500 hover:underline">Acceptable Use Policy</Link>{" "}
            for what may run here, and{" "}
            <Link href="/status" className="text-emerald-500 hover:underline">status</Link> for live
            health.
          </p>
        </div>
      </div>
    </PublicPage>
  );
}
