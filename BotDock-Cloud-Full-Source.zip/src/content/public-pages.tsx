/**
 * Shared building blocks for the indexable public pages (/pricing, /features,
 * /docs, /support, /terms, /privacy). Server-safe (no client hooks).
 * The dashboard SPA at `/` keeps its own richer landing; these pages exist so
 * public content is directly reachable, refresh-safe and indexable.
 */

import Link from "next/link";
import { Bot } from "lucide-react";
import { Button } from "@/components/ui/button";

export const SITE_NAME = "BotDock Cloud";

export const FEATURES = [
  {
    title: "Deploy any Telegram bot",
    body: "Python, Node.js and Bun runtimes with automatic dependency installation from requirements.txt or package.json.",
  },
  {
    title: "Isolated by design",
    body: "Every bot runs in its own sandboxed process with CPU, memory and disk limits — never inside the web app.",
  },
  {
    title: "Real logs, real status",
    body: "Build logs, runtime logs, memory and CPU are measured from the live process. No fake green dots.",
  },
  {
    title: "File manager & editor",
    body: "Browse, edit, upload and download project files right from the dashboard, safely jailed to your bot.",
  },
  {
    title: "Deploy from GitHub",
    body: "Import a repository and branch with a personal access token; rebuild any commit in one click.",
  },
  {
    title: "Free during launch",
    body: "Real hosting limits, stated up front and enforced server-side — no payment method, no subscription, no checkout.",
  },
];

export function PublicHeader() {
  return (
    <header className="sticky top-0 z-40 border-b border-border/60 bg-background/80 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-5xl items-center justify-between gap-4 px-4 sm:px-6">
        <Link href="/" aria-label="BotDock Cloud home" className="flex items-center gap-2">
          <span className="grid h-8 w-8 place-items-center rounded-xl bg-emerald-500/15 ring-1 ring-emerald-500/30">
            <Bot className="h-4 w-4 text-emerald-500" />
          </span>
          <span className="font-bold tracking-tight">
            BotDock <span className="text-emerald-500">Cloud</span>
          </span>
        </Link>
        <nav className="flex items-center gap-2 sm:gap-4" aria-label="Main">
          <Link href="/features" className="hidden text-sm text-muted-foreground transition-colors hover:text-foreground sm:block">
            Features
          </Link>
          <Link href="/pricing" className="hidden text-sm text-muted-foreground transition-colors hover:text-foreground sm:block">
            Pricing
          </Link>
          <Link href="/docs" className="hidden text-sm text-muted-foreground transition-colors hover:text-foreground sm:block">
            Docs
          </Link>
          <Link href="/support" className="hidden text-sm text-muted-foreground transition-colors hover:text-foreground sm:block">
            Support
          </Link>
          <Button asChild variant="ghost" size="sm">
            <Link href="/login">Sign in</Link>
          </Button>
          <Button asChild size="sm" className="bg-emerald-600 hover:bg-emerald-500">
            <Link href="/register">Get started</Link>
          </Button>
        </nav>
      </div>
    </header>
  );
}

export function PublicFooter() {
  return (
    <footer className="mt-auto border-t border-border/60 bg-muted/20">
      <div className="mx-auto flex max-w-5xl flex-col items-center justify-between gap-4 px-4 py-8 sm:flex-row sm:px-6">
        <div className="flex items-center gap-4">
          <Link href="/" className="flex items-center gap-2" aria-label="BotDock Cloud home">
            <span className="grid h-7 w-7 place-items-center rounded-lg bg-emerald-500/15 ring-1 ring-emerald-500/30">
              <Bot className="h-3.5 w-3.5 text-emerald-500" />
            </span>
            <span className="text-sm font-semibold">BotDock Cloud</span>
          </Link>
          <span className="text-xs text-muted-foreground">© {new Date().getFullYear()} BotDock Cloud</span>
        </div>
        <nav className="flex flex-wrap items-center gap-4 text-xs text-muted-foreground" aria-label="Footer">
          <Link href="/features" className="hover:text-foreground">Features</Link>
          <Link href="/pricing" className="hover:text-foreground">Pricing</Link>
          <Link href="/docs" className="hover:text-foreground">Docs</Link>
          <Link href="/support" className="hover:text-foreground">Support</Link>
          <Link href="/status" className="hover:text-foreground">Status</Link>
          <Link href="/security" className="hover:text-foreground">Security</Link>
          <Link href="/terms" className="hover:text-foreground">Terms</Link>
          <Link href="/privacy" className="hover:text-foreground">Privacy</Link>
          <Link href="/aup" className="hover:text-foreground">AUP</Link>
        </nav>
      </div>
    </footer>
  );
}

export function PublicPage({
  children,
  className = "",
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <div className="flex min-h-screen flex-col bg-background text-foreground">
      <PublicHeader />
      <main className={`flex-1 ${className}`}>{children}</main>
      <PublicFooter />
    </div>
  );
}

export function PageH1({ children }: { children: React.ReactNode }) {
  return <h1 className="text-3xl font-extrabold tracking-tight sm:text-4xl">{children}</h1>;
}

export function PageLead({ children }: { children: React.ReactNode }) {
  return <p className="mt-3 max-w-2xl text-base text-muted-foreground sm:text-lg">{children}</p>;
}
