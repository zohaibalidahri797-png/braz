"use client";

/**
 * Admin panel (server-enforced ADMIN role): overview stats, user management,
 * plan editor, broadcast composer with delivery tracking, platform-wide
 * deployments, audit log, platform settings.
 */

import { useCallback, useEffect, useState } from "react";
import {
  Activity,
  Bot as BotIcon,
  FileClock,
  Gauge,
  Loader2,
  Megaphone,
  Save,
  ScrollText,
  Settings2,
  Shield,
  Users,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { api, errorMessage, timeAgo, type NotificationRow } from "./api";
import { useApp } from "./store";
import { ErrorNote, InfoNote, LoadingBlock, PageHeader, StatCard } from "./ui-bits";

export function AdminPanel() {
  return (
    <div className="space-y-6">
      <PageHeader
        title={
          <span className="flex items-center gap-2">
            <Shield className="h-6 w-6 text-emerald-500" /> Admin panel
          </span>
        }
        description="Every action here is authorized on the server and recorded in the audit log."
      />
      <AdminTabs />
    </div>
  );
}

function AdminTabs() {
  return (
    <Tabs defaultValue="overview">
      <TabsList className="flex-wrap">
        <TabsTrigger value="overview"><Gauge className="mr-1.5 h-3.5 w-3.5" />Overview</TabsTrigger>
        <TabsTrigger value="users"><Users className="mr-1.5 h-3.5 w-3.5" />Users</TabsTrigger>
        <TabsTrigger value="plans"><Settings2 className="mr-1.5 h-3.5 w-3.5" />Plans</TabsTrigger>
        <TabsTrigger value="broadcasts"><Megaphone className="mr-1.5 h-3.5 w-3.5" />Broadcasts</TabsTrigger>
        <TabsTrigger value="deployments"><Activity className="mr-1.5 h-3.5 w-3.5" />Deployments</TabsTrigger>
        <TabsTrigger value="audit"><ScrollText className="mr-1.5 h-3.5 w-3.5" />Audit log</TabsTrigger>
        <TabsTrigger value="settings"><Settings2 className="mr-1.5 h-3.5 w-3.5" />Settings</TabsTrigger>
      </TabsList>
      <TabsContent value="overview" className="mt-4"><AdminOverview /></TabsContent>
      <TabsContent value="users" className="mt-4"><AdminUsers /></TabsContent>
      <TabsContent value="plans" className="mt-4"><AdminPlans /></TabsContent>
      <TabsContent value="broadcasts" className="mt-4"><AdminBroadcasts /></TabsContent>
      <TabsContent value="deployments" className="mt-4"><AdminDeployments /></TabsContent>
      <TabsContent value="audit" className="mt-4"><AdminAudit /></TabsContent>
      <TabsContent value="settings" className="mt-4"><AdminSettings /></TabsContent>
    </Tabs>
  );
}

interface AdminStats {
  users: { total: number; verified: number; suspendedOrBanned: number };
  bots: Record<string, number>;
  deployments: { last24h: number; failedLast24h: number };
  broadcasts: number;
  emails: Record<string, number>;
  auditLogEntries: number;
  runtime: { health?: { version: string; uptimeSec: number; activeBots: number; host: { platform: string; cpus: number; totalMemMb: number; freeMemMb: number } }; bots?: Array<Record<string, unknown>> } | null;
  runtimeError: string | null;
}

function AdminOverview() {
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api<AdminStats>("/api/admin/stats").then(setStats).catch((e) => setError(errorMessage(e)));
  }, []);

  if (error) return <ErrorNote message={error} />;
  if (!stats) return <LoadingBlock rows={4} />;

  const runningBots = stats.runtime?.bots?.filter((b) => b.state === "RUNNING").length ?? 0;

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4 xl:grid-cols-4">
        <StatCard label="Users" value={stats.users.total} sub={`${stats.users.verified} verified · ${stats.users.suspendedOrBanned} suspended`} icon={<Users className="h-4 w-4" />} />
        <StatCard label="Bots (by status)" value={Object.values(stats.bots).reduce((a, b) => a + b, 0)} sub={Object.entries(stats.bots).map(([k, v]) => `${k}:${v}`).join(" · ") || "none"} icon={<BotIcon className="h-4 w-4" />} tone="success" />
        <StatCard label="Deployments 24h" value={stats.deployments.last24h} sub={`${stats.deployments.failedLast24h} failed`} tone={stats.deployments.failedLast24h > 0 ? "warning" : "default"} icon={<Activity className="h-4 w-4" />} />
        <StatCard label="Runtime service" value={stats.runtimeError ? "OFFLINE" : `v${stats.runtime?.health?.version ?? "?"}`} sub={stats.runtimeError ?? `${runningBots} running · host ${stats.runtime?.health?.host.cpus} cpu / ${stats.runtime?.health?.host.totalMemMb} MB`} tone={stats.runtimeError ? "danger" : "success"} icon={<Gauge className="h-4 w-4" />} />
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader className="pb-3"><CardTitle className="text-sm">Email delivery log</CardTitle></CardHeader>
          <CardContent>
            {Object.keys(stats.emails).length === 0 ? (
              <p className="text-sm text-muted-foreground">No email attempts recorded yet.</p>
            ) : (
              <ul className="space-y-1 text-sm">
                {Object.entries(stats.emails).map(([status, count]) => (
                  <li key={status} className="flex justify-between"><span>{status}</span><span className="font-mono">{count}</span></li>
                ))}
              </ul>
            )}
            <p className="mt-3 text-xs text-muted-foreground">SKIPPED rows mean no email provider was configured at send time — the system records this instead of pretending to send.</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-3"><CardTitle className="text-sm">Runtime bots (live)</CardTitle></CardHeader>
          <CardContent>
            {!stats.runtime?.bots?.length ? (
              <p className="text-sm text-muted-foreground">No bots registered in the runtime.</p>
            ) : (
              <ul className="space-y-1 font-mono text-xs">
                {stats.runtime.bots.map((b, i) => (
                  <li key={i} className="flex justify-between gap-2">
                    <span className="truncate">{String(b.botId)}</span>
                    <span>{String(b.state)} · {typeof b.memoryMb === "number" ? `${b.memoryMb}MB` : "?"} · {String(b.restarts)} restarts</span>
                  </li>
                ))}
              </ul>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

interface AdminUser {
  id: string;
  email: string;
  name: string | null;
  role: string;
  status: string;
  emailVerified: string | null;
  createdAt: string;
  _count: { bots: number };
  subscription: { planId: string; status: string } | null;
}

function AdminUsers() {
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [q, setQ] = useState("");
  const [plans, setPlans] = useState<Array<{ id: string; name: string }>>([]);
  const [error, setError] = useState<string | null>(null);
  const [msg, setMsg] = useState<string | null>(null);

  const load = useCallback(() => {
    api<{ users: AdminUser[] }>(`/api/admin/users?q=${encodeURIComponent(q)}`).then((d) => setUsers(d.users)).catch((e) => setError(errorMessage(e)));
  }, [q]);

  useEffect(() => { load(); }, [load]);
  useEffect(() => {
    api<{ plans: Array<{ id: string; name: string }> }>("/api/admin/plans").then((d) => setPlans(d.plans)).catch(() => undefined);
  }, []);

  const patch = async (userId: string, data: Record<string, unknown>) => {
    setMsg(null);
    setError(null);
    try {
      await api("/api/admin/users", { method: "PATCH", json: { userId, ...data } });
      setMsg("User updated.");
      load();
    } catch (e) {
      setError(errorMessage(e));
    }
  };

  const applyPlan = async (userId: string, planId: string) => {
    try {
      await api("/api/admin/subscription", { method: "POST", json: { userId, planId } });
      setMsg(`Plan ${planId} applied.`);
      load();
    } catch (e) {
      setError(errorMessage(e));
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex gap-2">
        <Input placeholder="Search by email or name…" value={q} onChange={(e) => setQ(e.target.value)} className="max-w-sm" />
        <Button variant="outline" onClick={load}>Search</Button>
      </div>
      {error ? <ErrorNote message={error} /> : null}
      {msg ? <InfoNote>{msg}</InfoNote> : null}
      <div className="overflow-x-auto rounded-xl border">
        <Table className="min-w-[800px]">
          <TableHeader>
            <TableRow>
              <TableHead>User</TableHead>
              <TableHead>Role</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Plan</TableHead>
              <TableHead>Bots</TableHead>
              <TableHead>Joined</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {users.map((u) => (
              <TableRow key={u.id}>
                <TableCell>
                  <p className="text-sm font-medium">{u.name ?? "—"}</p>
                  <p className="text-xs text-muted-foreground">{u.email} {u.emailVerified ? "✓" : "(unverified)"}</p>
                </TableCell>
                <TableCell><Badge variant="outline" className={u.role === "ADMIN" ? "border-emerald-500/40 text-emerald-500" : ""}>{u.role}</Badge></TableCell>
                <TableCell><Badge variant="outline" className={u.status === "ACTIVE" ? "" : "border-red-500/40 text-red-400"}>{u.status}</Badge></TableCell>
                <TableCell>
                  <Select value={u.subscription?.planId ?? "free"} onValueChange={(v) => applyPlan(u.id, v)}>
                    <SelectTrigger className="h-8 w-28 text-xs"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {plans.map((p) => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </TableCell>
                <TableCell className="text-xs tabular-nums">{u._count.bots}</TableCell>
                <TableCell className="text-xs text-muted-foreground">{timeAgo(u.createdAt)}</TableCell>
                <TableCell className="text-right">
                  <div className="flex justify-end gap-1.5">
                    {!u.emailVerified ? (
                      <Button size="sm" variant="outline" className="h-7 text-xs" onClick={() => patch(u.id, { emailVerified: true })}>Verify</Button>
                    ) : null}
                    {u.status === "ACTIVE" ? (
                      <Button size="sm" variant="outline" className="h-7 text-xs text-red-400" onClick={() => patch(u.id, { status: "SUSPENDED" })}>Suspend</Button>
                    ) : (
                      <Button size="sm" variant="outline" className="h-7 text-xs" onClick={() => patch(u.id, { status: "ACTIVE" })}>Reactivate</Button>
                    )}
                    {u.role === "USER" ? (
                      <Button size="sm" variant="outline" className="h-7 text-xs" onClick={() => patch(u.id, { role: "ADMIN" })}>Make admin</Button>
                    ) : (
                      <Button size="sm" variant="outline" className="h-7 text-xs" onClick={() => patch(u.id, { role: "USER" })}>Revoke admin</Button>
                    )}
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}

interface AdminPlan {
  id: string;
  name: string;
  description: string;
  priceMonthly: number;
  priceYearly: number;
  isActive: boolean;
  isPublic: boolean;
  sortOrder: number;
  features: string[];
  limits: {
    maxBots: number;
    memoryMbPerBot: number;
    cpuPercent: number;
    diskMbPerBot: number;
    storageTotalMb: number;
    deploymentsPerDay: number;
    logRetentionDays: number;
    runtimes: string[];
    allowedFeatures: { githubImport: boolean; fileEditor: boolean; envVars: boolean; prioritySupport: boolean };
  };
  subscribers: number;
}

function AdminPlans() {
  const [plans, setPlans] = useState<AdminPlan[]>([]);
  const [editing, setEditing] = useState<AdminPlan | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [msg, setMsg] = useState<string | null>(null);

  const load = useCallback(() => {
    api<{ plans: AdminPlan[] }>("/api/admin/plans").then((d) => setPlans(d.plans)).catch((e) => setError(errorMessage(e)));
  }, []);
  useEffect(load, [load]);

  const save = async () => {
    if (!editing) return;
    setError(null);
    setMsg(null);
    try {
      await api("/api/admin/plans", {
        method: "PUT",
        json: {
          id: editing.id,
          name: editing.name,
          description: editing.description,
          priceMonthly: editing.priceMonthly,
          priceYearly: editing.priceYearly,
          isActive: editing.isActive,
          isPublic: editing.isPublic,
          limits: editing.limits,
          features: editing.features,
        },
      });
      setMsg(`Plan ${editing.id} saved.`);
      setEditing(null);
      load();
    } catch (e) {
      setError(errorMessage(e));
    }
  };

  if (error && plans.length === 0) return <ErrorNote message={error} />;

  return (
    <div className="space-y-4">
      {error ? <ErrorNote message={error} /> : null}
      {msg ? <InfoNote>{msg}</InfoNote> : null}
      <InfoNote>
        Free-launch mode: users are not restricted by plan quotas — bot creation and deployments are protected by
        system-wide abuse guards, and per-bot OS resource limits come from the server capacity policy
        (BOT_MEMORY_MB / BOT_CPU_PERCENT / BOT_DISK_MB environment variables). Plan rows below are legacy
        display/billing data kept for compatibility; editing them does not change runtime resources.
      </InfoNote>
      <div className="grid gap-4 md:grid-cols-2">
        {plans.map((p) => (
          <Card key={p.id}>
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center justify-between text-base">
                {p.name}
                <span className="text-xs font-normal text-muted-foreground">{p.subscribers} subscriber{p.subscribers === 1 ? "" : "s"}</span>
              </CardTitle>
              <CardDescription>${(p.priceMonthly / 100).toFixed(2)}/mo · {p.limits.maxBots} bots · {p.limits.memoryMbPerBot}MB/bot · {p.limits.deploymentsPerDay} deploys/day</CardDescription>
            </CardHeader>
            <CardContent className="flex items-center justify-between">
              <div className="flex gap-1.5">
                {p.isActive ? <Badge variant="outline" className="border-emerald-500/40 text-emerald-500">active</Badge> : <Badge variant="outline">hidden</Badge>}
              </div>
              <Button size="sm" variant="outline" onClick={() => setEditing({ ...p, limits: JSON.parse(JSON.stringify(p.limits)) })}>Edit</Button>
            </CardContent>
          </Card>
        ))}
      </div>

      <Dialog open={editing !== null} onOpenChange={(open) => !open && setEditing(null)}>
        <DialogContent className="max-h-[85vh] max-w-xl overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edit plan {editing?.id}</DialogTitle>
            <DialogDescription>Quotas are enforced server-side the moment you save.</DialogDescription>
          </DialogHeader>
          {editing ? (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5"><Label>Name</Label><Input value={editing.name} onChange={(e) => setEditing({ ...editing, name: e.target.value })} /></div>
                <div className="space-y-1.5"><Label>Price monthly (cents)</Label><Input type="number" value={editing.priceMonthly} onChange={(e) => setEditing({ ...editing, priceMonthly: Number(e.target.value) })} /></div>
                <div className="space-y-1.5"><Label>Max bots</Label><Input type="number" value={editing.limits.maxBots} onChange={(e) => setEditing({ ...editing, limits: { ...editing.limits, maxBots: Number(e.target.value) } })} /></div>
                <div className="space-y-1.5"><Label>Memory / bot (MB)</Label><Input type="number" value={editing.limits.memoryMbPerBot} onChange={(e) => setEditing({ ...editing, limits: { ...editing.limits, memoryMbPerBot: Number(e.target.value) } })} /></div>
                <div className="space-y-1.5"><Label>CPU %</Label><Input type="number" value={editing.limits.cpuPercent} onChange={(e) => setEditing({ ...editing, limits: { ...editing.limits, cpuPercent: Number(e.target.value) } })} /></div>
                <div className="space-y-1.5"><Label>Storage total (MB)</Label><Input type="number" value={editing.limits.storageTotalMb} onChange={(e) => setEditing({ ...editing, limits: { ...editing.limits, storageTotalMb: Number(e.target.value) } })} /></div>
                <div className="space-y-1.5"><Label>Disk / bot (MB)</Label><Input type="number" value={editing.limits.diskMbPerBot} onChange={(e) => setEditing({ ...editing, limits: { ...editing.limits, diskMbPerBot: Number(e.target.value) } })} /></div>
                <div className="space-y-1.5"><Label>Deployments / day</Label><Input type="number" value={editing.limits.deploymentsPerDay} onChange={(e) => setEditing({ ...editing, limits: { ...editing.limits, deploymentsPerDay: Number(e.target.value) } })} /></div>
                <div className="space-y-1.5"><Label>Log retention (days)</Label><Input type="number" value={editing.limits.logRetentionDays} onChange={(e) => setEditing({ ...editing, limits: { ...editing.limits, logRetentionDays: Number(e.target.value) } })} /></div>
                <div className="space-y-1.5"><Label>Price yearly (cents)</Label><Input type="number" value={editing.priceYearly} onChange={(e) => setEditing({ ...editing, priceYearly: Number(e.target.value) })} /></div>
              </div>
              <div className="space-y-2">
                <Label>Features</Label>
                {[
                  ["githubImport", "GitHub import"],
                  ["fileEditor", "File editor"],
                  ["envVars", "Environment variables"],
                  ["prioritySupport", "Priority support"],
                ].map(([k, label]) => (
                  <label key={k} className="flex items-center gap-2 text-sm">
                    <Checkbox
                      checked={editing.limits.allowedFeatures[k as keyof typeof editing.limits.allowedFeatures]}
                      onCheckedChange={(v) => setEditing({ ...editing, limits: { ...editing.limits, allowedFeatures: { ...editing.limits.allowedFeatures, [k]: v === true } } })}
                    />
                    {label}
                  </label>
                ))}
              </div>
              <div className="flex items-center gap-6">
                <label className="flex items-center gap-2 text-sm"><Switch checked={editing.isActive} onCheckedChange={(v) => setEditing({ ...editing, isActive: v })} /> Active (selectable)</label>
                <label className="flex items-center gap-2 text-sm"><Switch checked={editing.isPublic} onCheckedChange={(v) => setEditing({ ...editing, isPublic: v })} /> Public (visible on pricing)</label>
              </div>
              <div className="space-y-1.5">
                <Label>Marketing feature list (one per line)</Label>
                <Textarea rows={4} value={editing.features.join("\n")} onChange={(e) => setEditing({ ...editing, features: e.target.value.split("\n").filter((x) => x.trim()) })} />
              </div>
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setEditing(null)}>Cancel</Button>
                <Button onClick={save} className="bg-emerald-600 hover:bg-emerald-500"><Save className="mr-2 h-4 w-4" /> Save plan</Button>
              </div>
            </div>
          ) : null}
        </DialogContent>
      </Dialog>
    </div>
  );
}

interface BroadcastRow {
  id: string;
  title: string;
  body: string;
  level: string;
  audience: string;
  channels: string;
  status: string;
  totalRecipients: number;
  delivered: number;
  failed: number;
  skipped: number;
  sentAt: string | null;
  createdAt: string;
}

function AdminBroadcasts() {
  const [rows, setRows] = useState<BroadcastRow[]>([]);
  const [channelsAvail, setChannelsAvail] = useState<{ email: boolean; telegram: boolean }>({ email: false, telegram: false });
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [audience, setAudience] = useState("ALL");
  const [level, setLevel] = useState("INFO");
  const [useEmail, setUseEmail] = useState(false);
  const [useTelegram, setUseTelegram] = useState(false);
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [msg, setMsg] = useState<string | null>(null);

  const load = useCallback(() => {
    api<{ broadcasts: BroadcastRow[]; channels: { email: boolean; telegram: boolean } }>("/api/broadcasts")
      .then((d) => {
        setRows(d.broadcasts);
        setChannelsAvail(d.channels);
      })
      .catch((e) => setError(errorMessage(e)));
  }, []);
  useEffect(load, [load]);

  const send = async (opts: { test?: boolean; confirm?: boolean }) => {
    setBusy(opts.test ? "test" : "send");
    setError(null);
    setMsg(null);
    try {
      const channels = ["INAPP", ...(useEmail ? ["EMAIL"] : []), ...(useTelegram ? ["TELEGRAM"] : [])];
      const res = await api<{ ok: boolean; savedAs?: string; unavailable?: string[] }>("/api/broadcasts", {
        method: "POST",
        json: { title, body, level, audience, channels, send: true, test: opts.test ?? false, confirm: opts.confirm ?? false },
      });
      const un = res.unavailable && res.unavailable.length > 0 ? ` (channels skipped: ${res.unavailable.join("; ")})` : "";
      setMsg(`Broadcast result: ${res.savedAs}${un}`);
      load();
    } catch (e) {
      const err = e as { code?: string; detail?: string; data?: { recipientCount?: number } };
      if (err.code === "confirmation_required") {
        const count = err.data?.recipientCount ?? 0;
        if (window.confirm(`This broadcast targets ${count} users. Send it now?`)) {
          await send({ ...opts, confirm: true });
          return;
        }
        setMsg("Cancelled — nothing was sent.");
      } else {
        setError(errorMessage(e));
      }
    } finally {
      setBusy(null);
    }
  };

  return (
    <div className="space-y-4">
      {error ? <ErrorNote message={error} /> : null}
      {msg ? <InfoNote>{msg}</InfoNote> : null}

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm">New broadcast</CardTitle>
          <CardDescription>
            In-app delivery always works. Email requires RESEND_API_KEY; Telegram requires TELEGRAM_BOT_TOKEN and users with a linked chat.
            Unavailable channels are recorded as SKIPPED — never reported as sent.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="space-y-1.5"><Label>Title</Label><Input value={title} onChange={(e) => setTitle(e.target.value)} maxLength={150} /></div>
            <div className="space-y-1.5">
              <Label>Audience</Label>
              <Select value={audience} onValueChange={setAudience}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="ALL">All users</SelectItem>
                  <SelectItem value="VERIFIED">Verified users</SelectItem>
                  <SelectItem value="PLAN:free">Free plan users</SelectItem>
                  <SelectItem value="PLAN:starter">Starter plan users</SelectItem>
                  <SelectItem value="PLAN:pro">Pro plan users</SelectItem>
                  <SelectItem value="SUSPENDED">Suspended / banned</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="space-y-1.5"><Label>Body</Label><Textarea rows={4} value={body} onChange={(e) => setBody(e.target.value)} maxLength={10000} /></div>
          <div className="flex flex-wrap items-center gap-4">
            <Select value={level} onValueChange={setLevel}>
              <SelectTrigger className="w-32"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="INFO">Info</SelectItem>
                <SelectItem value="SUCCESS">Success</SelectItem>
                <SelectItem value="WARNING">Warning</SelectItem>
                <SelectItem value="ERROR">Error</SelectItem>
              </SelectContent>
            </Select>
            <label className="flex items-center gap-2 text-sm"><Checkbox checked={useEmail} onCheckedChange={(v) => setUseEmail(v === true)} /> Email {!channelsAvail.email ? "(not configured → will be skipped)" : ""}</label>
            <label className="flex items-center gap-2 text-sm"><Checkbox checked={useTelegram} onCheckedChange={(v) => setUseTelegram(v === true)} /> Telegram {!channelsAvail.telegram ? "(not configured → will be skipped)" : ""}</label>
          </div>
          <div className="flex gap-2">
            <Button onClick={() => send({})} disabled={busy !== null || !title || !body} className="bg-emerald-600 hover:bg-emerald-500">
              {busy === "send" ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Megaphone className="mr-2 h-4 w-4" />} Send broadcast
            </Button>
            <Button variant="outline" onClick={() => send({ test: true })} disabled={busy !== null || !title || !body}>
              {busy === "test" ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null} Send test to me
            </Button>
          </div>
        </CardContent>
      </Card>

      <div className="overflow-x-auto rounded-xl border">
        <Table className="min-w-[700px]">
          <TableHeader>
            <TableRow>
              <TableHead>Title</TableHead>
              <TableHead>Audience</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Delivered / failed / skipped</TableHead>
              <TableHead>When</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {rows.length === 0 ? (
              <TableRow><TableCell colSpan={5} className="py-6 text-center text-sm text-muted-foreground">No broadcasts yet.</TableCell></TableRow>
            ) : (
              rows.map((b) => (
                <TableRow key={b.id}>
                  <TableCell className="max-w-52"><p className="truncate text-sm font-medium">{b.title}</p><p className="truncate text-xs text-muted-foreground">{b.body}</p></TableCell>
                  <TableCell className="text-xs">{b.audience} · {b.channels}</TableCell>
                  <TableCell><Badge variant="outline">{b.status}</Badge></TableCell>
                  <TableCell className="text-xs tabular-nums">{b.delivered} / {b.failed} / {b.skipped}</TableCell>
                  <TableCell className="text-xs text-muted-foreground">{b.sentAt ? timeAgo(b.sentAt) : "draft"}</TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}

interface AdminDeployment {
  id: string;
  number: number;
  status: string;
  error: string | null;
  triggeredBy: string | null;
  createdAt: string;
  botName: string;
  runtime: string;
  ownerEmail: string;
}

function AdminDeployments() {
  const [rows, setRows] = useState<AdminDeployment[]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api<{ deployments: AdminDeployment[] }>("/api/admin/deployments?take=50").then((d) => setRows(d.deployments)).catch((e) => setError(errorMessage(e)));
  }, []);

  if (error) return <ErrorNote message={error} />;

  return (
    <div className="overflow-x-auto rounded-xl border">
      <Table className="min-w-[760px]">
        <TableHeader>
          <TableRow>
            <TableHead>Bot</TableHead>
            <TableHead>Owner</TableHead>
            <TableHead>#</TableHead>
            <TableHead>Status</TableHead>
            <TableHead className="hidden md:table-cell">Error</TableHead>
            <TableHead>When</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {rows.length === 0 ? (
            <TableRow><TableCell colSpan={6} className="py-6 text-center text-sm text-muted-foreground">No deployments yet.</TableCell></TableRow>
          ) : (
            rows.map((d) => (
              <TableRow key={d.id}>
                <TableCell className="text-sm">{d.botName} <span className="text-xs text-muted-foreground">({d.runtime})</span></TableCell>
                <TableCell className="text-xs text-muted-foreground">{d.ownerEmail}</TableCell>
                <TableCell className="font-mono text-xs">#{d.number}</TableCell>
                <TableCell><Badge variant="outline" className={d.status === "FAILED" ? "border-red-500/40 text-red-400" : ""}>{d.status}</Badge></TableCell>
                <TableCell className="hidden max-w-40 truncate text-xs text-red-400 md:table-cell" title={d.error ?? undefined}>{d.error ?? "—"}</TableCell>
                <TableCell className="text-xs text-muted-foreground">{timeAgo(d.createdAt)}</TableCell>
              </TableRow>
            ))
          )}
        </TableBody>
      </Table>
    </div>
  );
}

interface AuditRow {
  id: string;
  actorEmail: string | null;
  action: string;
  targetType: string | null;
  targetId: string | null;
  detail: string;
  ip: string | null;
  createdAt: string;
}

function AdminAudit() {
  const [rows, setRows] = useState<AuditRow[]>([]);
  const [filter, setFilter] = useState("");
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(() => {
    api<{ logs: AuditRow[] }>(`/api/admin/audit?${filter ? `action=${encodeURIComponent(filter)}` : ""}`).then((d) => setRows(d.logs)).catch((e) => setError(errorMessage(e)));
  }, [filter]);
  useEffect(load, [load]);

  if (error) return <ErrorNote message={error} />;

  return (
    <div className="space-y-3">
      <div className="flex gap-2">
        <Input placeholder="Filter by action (e.g. BOT_, BROADCAST, LOGIN)" value={filter} onChange={(e) => setFilter(e.target.value)} className="max-w-sm" />
        <Button variant="outline" onClick={load}><FileClock className="mr-2 h-4 w-4" /> Refresh</Button>
      </div>
      <div className="overflow-x-auto rounded-xl border">
        <Table className="min-w-[760px]">
          <TableHeader>
            <TableRow>
              <TableHead>When</TableHead>
              <TableHead>Actor</TableHead>
              <TableHead>Action</TableHead>
              <TableHead>Target</TableHead>
              <TableHead>Detail</TableHead>
              <TableHead className="hidden md:table-cell">IP</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {rows.length === 0 ? (
              <TableRow><TableCell colSpan={6} className="py-6 text-center text-sm text-muted-foreground">No audit entries.</TableCell></TableRow>
            ) : (
              rows.map((r) => (
                <TableRow key={r.id}>
                  <TableCell className="whitespace-nowrap text-xs text-muted-foreground">{timeAgo(r.createdAt)}</TableCell>
                  <TableCell className="text-xs">{r.actorEmail ?? "—"}</TableCell>
                  <TableCell className="font-mono text-xs font-medium">{r.action}</TableCell>
                  <TableCell className="text-xs text-muted-foreground">{r.targetType ? `${r.targetType}:${(r.targetId ?? "").slice(0, 12)}` : "—"}</TableCell>
                  <TableCell className="max-w-60 truncate font-mono text-[11px] text-muted-foreground" title={r.detail}>{r.detail}</TableCell>
                  <TableCell className="hidden text-xs text-muted-foreground md:table-cell">{r.ip ?? "—"}</TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}

interface PlatformSettings {
  registrationEnabled?: boolean;
  maintenanceMode?: boolean;
  maintenanceMessage?: string;
  adsEnabled?: boolean;
  adsProviderNote?: string;
  rewardedAdsEnabled?: boolean;
  referralCreditsEnabled?: boolean;
  supportEmail?: string;
  telegramAnnounceChat?: string;
}

function AdminSettings() {
  const [settings, setSettings] = useState<PlatformSettings>({});
  const [error, setError] = useState<string | null>(null);
  const [msg, setMsg] = useState<string | null>(null);

  useEffect(() => {
    api<{ settings: PlatformSettings }>("/api/admin/settings").then((d) => setSettings(d.settings)).catch((e) => setError(errorMessage(e)));
  }, []);

  const save = async () => {
    setError(null);
    setMsg(null);
    try {
      await api("/api/admin/settings", { method: "PUT", json: settings });
      setMsg("Settings saved.");
    } catch (e) {
      setError(errorMessage(e));
    }
  };

  const set = <K extends keyof PlatformSettings>(k: K, v: PlatformSettings[K]) => setSettings((s) => ({ ...s, [k]: v }));

  return (
    <div className="max-w-2xl space-y-4">
      {error ? <ErrorNote message={error} /> : null}
      {msg ? <InfoNote>{msg}</InfoNote> : null}

      <Card>
        <CardHeader className="pb-3"><CardTitle className="text-sm">Access & maintenance</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          <label className="flex items-center justify-between text-sm">
            <span>Registration enabled</span>
            <Switch checked={settings.registrationEnabled ?? true} onCheckedChange={(v) => set("registrationEnabled", v)} />
          </label>
          <label className="flex items-center justify-between text-sm">
            <span>Maintenance mode (banner on landing)</span>
            <Switch checked={settings.maintenanceMode ?? false} onCheckedChange={(v) => set("maintenanceMode", v)} />
          </label>
          <div className="space-y-1.5">
            <Label>Maintenance message</Label>
            <Input value={settings.maintenanceMessage ?? ""} onChange={(e) => set("maintenanceMessage", e.target.value)} maxLength={500} />
          </div>
          <div className="space-y-1.5">
            <Label>Support email</Label>
            <Input value={settings.supportEmail ?? ""} onChange={(e) => set("supportEmail", e.target.value)} />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm">Monetization & advertising</CardTitle>
          <CardDescription>
            Configuration switches only — nothing is enabled unless you actually integrate a provider.
            Rewarded ads must award credits only after server-side verification by the ad network.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <label className="flex items-center justify-between text-sm">
            <span>Show ad placements</span>
            <Switch checked={settings.adsEnabled ?? false} onCheckedChange={(v) => set("adsEnabled", v)} />
          </label>
          <div className="space-y-1.5">
            <Label>Ad provider note (shown to users)</Label>
            <Input value={settings.adsProviderNote ?? ""} onChange={(e) => set("adsProviderNote", e.target.value)} maxLength={300} placeholder="e.g. AdSense will be integrated here" />
          </div>
          <label className="flex items-center justify-between text-sm">
            <span>Rewarded ads enabled</span>
            <Switch checked={settings.rewardedAdsEnabled ?? false} onCheckedChange={(v) => set("rewardedAdsEnabled", v)} />
          </label>
          <label className="flex items-center justify-between text-sm">
            <span>Referral credits enabled</span>
            <Switch checked={settings.referralCreditsEnabled ?? false} onCheckedChange={(v) => set("referralCreditsEnabled", v)} />
          </label>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-3"><CardTitle className="text-sm">Telegram announcements</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-1.5">
            <Label>Announcement channel chat id</Label>
            <Input value={settings.telegramAnnounceChat ?? ""} onChange={(e) => set("telegramAnnounceChat", e.target.value)} placeholder="@your_channel" />
            <p className="text-xs text-muted-foreground">Broadcasts to individual users require TELEGRAM_BOT_TOKEN in the environment and each user to link a chat id.</p>
          </div>
        </CardContent>
      </Card>

      <Button onClick={save} className="bg-emerald-600 hover:bg-emerald-500"><Save className="mr-2 h-4 w-4" /> Save settings</Button>
    </div>
  );
}

export type { NotificationRow };
