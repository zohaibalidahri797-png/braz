"use client";

/**
 * Authenticated app shell: responsive sidebar (drawer on mobile), topbar with
 * runtime health indicator, notifications popover, user menu.
 */

import { useEffect, useState } from "react";
import {
  Bell,
  Bot,
  CreditCard,
  LayoutDashboard,
  LifeBuoy,
  LogOut,
  Menu,
  Rocket,
  Settings,
  Shield,
  Zap,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Badge } from "@/components/ui/badge";
import { api, timeAgo, errorMessage } from "./api";
import type { NotificationRow } from "./api";
import { navigate, useApp } from "./store";
import { HashLink } from "./ui-bits";
import { cn } from "@/lib/utils";

interface NavItem {
  href: string;
  label: string;
  icon: typeof LayoutDashboard;
  adminOnly?: boolean;
}

const NAV: NavItem[] = [
  { href: "/dashboard", label: "Overview", icon: LayoutDashboard },
  { href: "/bots", label: "My bots", icon: Bot },
  { href: "/billing", label: "Plan & usage", icon: CreditCard },
  { href: "/settings", label: "Account settings", icon: Settings },
  { href: "/support", label: "Support", icon: LifeBuoy },
  { href: "/admin", label: "Admin panel", icon: Shield, adminOnly: true },
];

function NavLinks({ active, onNavigate }: { active: string; onNavigate?: () => void }) {
  const me = useApp((s) => s.me);
  return (
    <nav className="flex flex-col gap-1" aria-label="Dashboard">
      {NAV.filter((n) => !n.adminOnly || me?.user.role === "ADMIN").map((item) => {
        const isActive = active === item.href || (item.href !== "/dashboard" && active.startsWith(item.href));
        return (
          <HashLink
            key={item.href}
            href={`#${item.href}`}
            onClick={onNavigate}
            className={cn(
              "flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors",
              isActive ? "bg-emerald-500/15 text-emerald-500" : "text-muted-foreground hover:bg-muted hover:text-foreground",
            )}
          >
            <item.icon className="h-4 w-4 shrink-0" />
            {item.label}
            {item.adminOnly ? <Shield className="ml-auto h-3.5 w-3.5 opacity-60" /> : null}
          </HashLink>
        );
      })}
    </nav>
  );
}

function Brand({ onClick }: { onClick?: () => void }) {
  return (
    <HashLink href="#/dashboard" onClick={onClick} className="flex items-center gap-2 px-1">
      <span className="grid h-8 w-8 place-items-center rounded-xl bg-emerald-500/15 ring-1 ring-emerald-500/30">
        <Bot className="h-4 w-4 text-emerald-500" />
      </span>
      <span className="font-bold">BotDock <span className="text-emerald-500">Cloud</span></span>
    </HashLink>
  );
}

function NotificationsBell() {
  const [items, setItems] = useState<NotificationRow[]>([]);
  const [unread, setUnread] = useState(0);
  const [open, setOpen] = useState(false);

  const load = () => {
    api<{ notifications: NotificationRow[]; unread: number }>("/api/notifications?limit=12")
      .then((d) => {
        setItems(d.notifications);
        setUnread(d.unread);
      })
      .catch(() => undefined);
  };

  useEffect(() => {
    load();
    const t = setInterval(load, 20_000);
    return () => clearInterval(t);
  }, [open]);

  const markAll = async () => {
    await api("/api/notifications", { method: "POST", json: { all: true } }).catch(() => undefined);
    load();
  };

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="icon" className="relative" aria-label={`Notifications (${unread} unread)`}>
          <Bell className="h-4 w-4" />
          {unread > 0 ? (
            <span className="absolute -right-0.5 -top-0.5 grid h-4 min-w-4 place-items-center rounded-full bg-emerald-600 px-1 text-[10px] font-bold text-white">
              {unread > 9 ? "9+" : unread}
            </span>
          ) : null}
        </Button>
      </PopoverTrigger>
      <PopoverContent align="end" className="w-80 p-0">
        <div className="flex items-center justify-between border-b px-3 py-2">
          <p className="text-sm font-semibold">Notifications</p>
          {unread > 0 ? (
            <Button variant="ghost" size="sm" onClick={markAll} className="h-7 text-xs">Mark all read</Button>
          ) : null}
        </div>
        <div className="max-h-96 overflow-y-auto">
          {items.length === 0 ? (
            <p className="px-3 py-8 text-center text-sm text-muted-foreground">No notifications yet.</p>
          ) : (
            items.map((n) => (
              <button
                key={n.id}
                className={cn("block w-full border-b px-3 py-2.5 text-left last:border-0 hover:bg-muted/50", !n.readAt && "bg-emerald-500/5")}
                onClick={() => {
                  if (!n.readAt) {
                    api("/api/notifications", { method: "POST", json: { ids: [n.id] } }).catch(() => undefined);
                  }
                  if (n.link) {
                    navigate(n.link.replace(/^#/, ""));
                    setOpen(false);
                  }
                }}
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="text-sm font-medium">{n.title}</span>
                  <span className="shrink-0 text-[10px] text-muted-foreground">{timeAgo(n.createdAt)}</span>
                </div>
                <p className="mt-0.5 line-clamp-2 text-xs text-muted-foreground">{n.body}</p>
              </button>
            ))
          )}
        </div>
      </PopoverContent>
    </Popover>
  );
}

function UserMenu() {
  const { me, logout } = useApp();
  if (!me) return null;
  const initial = (me.user.name ?? me.user.email)[0]?.toUpperCase() ?? "?";
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button className="flex items-center gap-2 rounded-full outline-none ring-ring focus-visible:ring-2" aria-label="Account menu">
          <span className="grid h-8 w-8 place-items-center rounded-full bg-emerald-600 text-sm font-bold text-white">{initial}</span>
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-56">
        <DropdownMenuLabel>
          <p className="truncate text-sm font-medium">{me.user.name ?? "Account"}</p>
          <p className="truncate text-xs font-normal text-muted-foreground">{me.user.email}</p>
          <p className="mt-1 text-xs">
            <Badge variant="outline" className="border-emerald-500/40 text-emerald-500">{me.plan.name} plan</Badge>
          </p>
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        <DropdownMenuItem onClick={() => navigate("/settings")}>
          <Settings className="mr-2 h-4 w-4" /> Account settings
        </DropdownMenuItem>
        {me.user.role === "ADMIN" ? (
          <DropdownMenuItem onClick={() => navigate("/admin")}>
            <Shield className="mr-2 h-4 w-4" /> Admin panel
          </DropdownMenuItem>
        ) : null}
        <DropdownMenuSeparator />
        <DropdownMenuItem
          onClick={() => {
            void logout();
          }}
        >
          <LogOut className="mr-2 h-4 w-4" /> Sign out
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

function RuntimeBadge() {
  const [ok, setOk] = useState<boolean | null>(null);
  useEffect(() => {
    const check = () => {
      api<{ runtime: { ok: boolean } }>("/api/health")
        .then((d) => setOk(d.runtime.ok))
        .catch(() => setOk(false));
    };
    check();
    const t = setInterval(check, 30_000);
    return () => clearInterval(t);
  }, []);
  if (ok === null) return null;
  return (
    <span
      className={cn("hidden items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs sm:inline-flex",
        ok ? "border-emerald-500/30 bg-emerald-500/10 text-emerald-500" : "border-red-500/30 bg-red-500/10 text-red-400")}
      title={ok ? "Bot runtime service is online" : "Bot runtime service is offline — deploys and start/stop are unavailable"}
    >
      <Zap className="h-3 w-3" />
      {ok ? "Runtime online" : "Runtime offline"}
    </span>
  );
}

export function AppShell({ children }: { children: React.ReactNode }) {
  const { me, route, sidebarOpen, setSidebarOpen } = useApp();
  const active = "/" + (route.segments[0] ?? "dashboard") + (route.segments[0] === "bots" ? "/bots-detail" : route.segments[0] === "admin" ? "" : "");

  return (
    <div className="flex min-h-screen flex-col bg-muted/20">
      {/* Mobile top bar */}
      <div className="sticky top-0 z-40 flex h-14 items-center justify-between gap-2 border-b bg-background px-4 lg:hidden">
        <div className="flex items-center gap-2">
          <Sheet open={sidebarOpen} onOpenChange={setSidebarOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" aria-label="Open navigation">
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-72 px-3">
              <SheetTitle className="sr-only">Navigation</SheetTitle>
              <div className="mt-4"><Brand onClick={() => setSidebarOpen(false)} /></div>
              <div className="mt-6"><NavLinks active={active} onNavigate={() => setSidebarOpen(false)} /></div>
            </SheetContent>
          </Sheet>
          <Brand />
        </div>
        <div className="flex items-center gap-1">
          <RuntimeBadge />
          <NotificationsBell />
          <UserMenu />
        </div>
      </div>

      <div className="flex flex-1">
        {/* Desktop sidebar */}
        <aside className="sticky top-0 hidden h-screen w-60 shrink-0 flex-col border-r bg-background px-3 py-4 lg:flex">
          <Brand />
          <div className="mt-8 flex-1">
            <NavLinks active={active} />
          </div>
          <div className="rounded-xl border bg-muted/30 p-3 text-xs text-muted-foreground">
            <p className="flex items-center gap-1.5 font-medium text-foreground">
              <span className="inline-block h-1.5 w-1.5 rounded-full bg-emerald-500" />
              Free during launch
            </p>
            <p className="mt-1">No payment, no subscription — hosting is free while BotDock is in launch.</p>
            <HashLink href="#/billing" className="mt-2 inline-flex items-center gap-1 font-medium text-emerald-500 hover:underline">
              <Rocket className="h-3 w-3" /> Plan & usage
            </HashLink>
          </div>
          {/* Desktop account controls (previously mobile-only — logout/notifications
              were unreachable at lg+ widths; fixed for the auth-UX repair pass) */}
          <div className="mt-3 flex items-center justify-between gap-2 border-t pt-3">
            <RuntimeBadge />
            <div className="flex items-center gap-1">
              <NotificationsBell />
              <UserMenu />
            </div>
          </div>
        </aside>

        {/* Main */}
        <main className="min-w-0 flex-1 px-4 py-6 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-5xl">
            {!me?.user.emailVerified ? (
              <div className="mb-6 rounded-lg border border-amber-500/30 bg-amber-500/10 px-4 py-3 text-sm text-amber-500">
                <span className="font-semibold">Verify your email</span> — deployment is locked until your address is verified.
                {me?.user.role === "ADMIN"
                  ? " (As the first admin you can verify yourself from Admin → Users, or configure an email provider.)"
                  : me?.emailConfigured === false
                    ? " Email delivery is not configured on this deployment: no verification email could be sent. An administrator can verify your account from the Admin panel, or configure an email provider (see docs/SETUP.md) and then resend the email from Account settings."
                    : " Check your inbox, or resend from Account settings."}
              </div>
            ) : null}
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}

export { NotificationsBell, UserMenu, RuntimeBadge };
