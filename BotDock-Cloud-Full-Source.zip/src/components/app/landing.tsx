"use client";

/**
 * Public landing page: hero, features, how-it-works, real pricing (from the
 * plans API), docs, footer. Fully responsive; sticky footer via mt-auto.
 */

import { useEffect, useState } from "react";
import Link from "next/link";
import { Bot, Boxes, Cpu, FileCode2, GaugeCircle, Github, HardDrive, Layers, Menu, Rocket, ScrollText, ShieldCheck, Terminal, X, Zap, Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Sheet, SheetContent, SheetTrigger, SheetTitle } from "@/components/ui/sheet";
import { api, type PublicPlan, formatUsdLabel } from "./plan-utils";
import { navigate, useApp } from "./store";

const FEATURES = [
  { icon: Bot, title: "Deploy any Telegram bot", body: "Python, Node.js and Bun runtimes with automatic dependency installation from requirements.txt or package.json." },
  { icon: ShieldCheck, title: "Isolated by design", body: "Every bot runs in its own sandboxed process with CPU, memory and disk limits — never inside the web app." },
  { icon: Terminal, title: "Real logs, real status", body: "Build logs, runtime logs, memory and CPU are measured from the live process. No fake green dots." },
  { icon: FileCode2, title: "File manager & editor", body: "Browse, edit, upload and download project files right from the dashboard, safely jailed to your bot." },
  { icon: Github, title: "Deploy from GitHub", body: "Import a repository and branch with a personal access token; rebuild any commit in one click." },
  { icon: GaugeCircle, title: "Free during launch", body: "Create and manage bots without fixed plan caps — isolated processes with real resource protection, free during launch, no payment required." },
];

const STEPS = [
  { n: "1", title: "Create", body: "Start from a template, upload an archive, or import from GitHub." },
  { n: "2", title: "Configure", body: "Set env vars (encrypted at rest), pick the runtime, tweak the start command." },
  { n: "3", title: "Deploy", body: "BotDock installs dependencies, builds and starts your bot in an isolated process." },
  { n: "4", title: "Operate", body: "Watch live logs and metrics, stop/restart/redeploy, and manage files any time." },
];

function Logo({ size = "md" }: { size?: "md" | "lg" }) {
  return (
    <span className="flex items-center gap-2">
      <span className={`grid ${size === "lg" ? "h-10 w-10" : "h-8 w-8"} place-items-center rounded-xl bg-emerald-500/15 ring-1 ring-emerald-500/30`}>
        <Bot className={`${size === "lg" ? "h-5 w-5" : "h-4 w-4"} text-emerald-500`} />
      </span>
      <span className={`font-bold tracking-tight ${size === "lg" ? "text-xl" : ""}`}>
        BotDock <span className="text-emerald-500">Cloud</span>
      </span>
    </span>
  );
}

function Nav({ onSignin }: { onSignin: () => void }) {
  const [open, setOpen] = useState(false);
  const links = [
    { href: "#features", label: "Features" },
    { href: "#how", label: "How it works" },
    { href: "#pricing", label: "Pricing" },
    { href: "#docs", label: "Docs" },
  ];
  return (
    <header className="sticky top-0 z-40 border-b border-border/60 bg-background/80 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-4 px-4 sm:px-6">
        <Link href="/" aria-label="BotDock Cloud home">
          <Logo />
        </Link>
        <nav className="hidden items-center gap-6 md:flex" aria-label="Main">
          {links.map((l) => (
            <a key={l.href} href={l.href} className="text-sm text-muted-foreground transition-colors hover:text-foreground">
              {l.label}
            </a>
          ))}
        </nav>
        <div className="hidden items-center gap-2 md:flex">
          <Button variant="ghost" onClick={onSignin}>Sign in</Button>
          <Button className="bg-emerald-600 hover:bg-emerald-500" onClick={onSignin}>
            Get started
          </Button>
        </div>
        <Sheet open={open} onOpenChange={setOpen}>
          <SheetTrigger asChild className="md:hidden">
            <Button variant="ghost" size="icon" aria-label="Open menu">
              {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
          </SheetTrigger>
          <SheetContent side="right" className="w-72">
            <SheetTitle className="sr-only">Navigation</SheetTitle>
            <div className="mt-6 flex flex-col gap-1">
              {links.map((l) => (
                <a key={l.href} href={l.href} onClick={() => setOpen(false)} className="rounded-lg px-3 py-2 text-sm hover:bg-muted">
                  {l.label}
                </a>
              ))}
              <div className="my-3 h-px bg-border" />
              <Button onClick={() => { setOpen(false); onSignin(); }} className="bg-emerald-600 hover:bg-emerald-500">Get started</Button>
              <Button variant="outline" onClick={() => { setOpen(false); onSignin(); }}>Sign in</Button>
            </div>
          </SheetContent>
        </Sheet>
      </div>
    </header>
  );
}

function Pricing({ onSignup }: { onSignup: () => void }) {
  const [plans, setPlans] = useState<PublicPlan[] | null>(null);
  const [note, setNote] = useState<string | null>(null);

  useEffect(() => {
    api<{ plans: PublicPlan[]; note: string | null }>("/api/plans")
      .then((d) => {
        setPlans(d.plans.filter((p) => p.isActive));
        setNote(d.note);
      })
      .catch(() => setPlans([]));
  }, []);

  return (
    <div>
      <div className={`grid gap-4 ${plans && plans.length > 1 ? "md:grid-cols-2 xl:grid-cols-4" : "mx-auto max-w-xl"}`}>
        {(plans ?? []).map((p) => (
          <Card key={p.id} className={p.id === "free" ? "border-emerald-500/40 ring-1 ring-emerald-500/30" : ""}>
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-base">{p.name}</CardTitle>
                {p.id === "free" ? <Badge className="bg-emerald-500/15 text-emerald-500 hover:bg-emerald-500/15">Free during launch</Badge> : null}
              </div>
              <p className="text-2xl font-bold">
                {formatUsdLabel(p.priceMonthly)}
                {p.priceMonthly > 0 ? <span className="text-sm font-normal text-muted-foreground">/mo</span> : null}
              </p>
              <p className="min-h-10 text-xs text-muted-foreground">{p.description}</p>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-sm">
                {p.features.map((f) => (
                  <li key={f} className="flex items-start gap-2">
                    <Zap className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-500" />
                    <span>{f}</span>
                  </li>
                ))}
              </ul>
              <Button
                className={`mt-5 w-full ${p.id === "free" ? "bg-emerald-600 hover:bg-emerald-500" : ""}`}
                variant={p.id === "free" ? "default" : "outline"}
                onClick={onSignup}
              >
                {p.priceMonthly === 0 ? "Start free" : "Contact us"}
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
      {note ? <p className="mt-4 text-center text-xs text-muted-foreground">{note}</p> : null}
    </div>
  );
}

export function Landing() {
  const { refreshMe } = useApp();
  const [hasArchive, setHasArchive] = useState(false);

  useEffect(() => {
    fetch("/api/download?file=botdock-cloud.zip", { method: "HEAD" })
      .then((r) => setHasArchive(r.ok))
      .catch(() => setHasArchive(false));
  }, []);

  const goAuth = async (target: string) => {
    const me = await refreshMe();
    navigate(me ? "/dashboard" : target);
  };

  return (
    <div className="flex min-h-screen flex-col bg-background text-foreground">
      <Nav onSignin={() => void goAuth("/login")} />

      <main className="flex-1">
        {/* Hero */}
        <section className="relative overflow-hidden">
          <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(60%_40%_at_50%_0%,rgba(16,185,129,0.12),transparent)]" aria-hidden />
          <div className="mx-auto grid max-w-6xl gap-10 px-4 py-16 sm:px-6 sm:py-24 lg:grid-cols-2 lg:items-center">
            <div>
              <Badge variant="outline" className="mb-4 border-emerald-500/40 text-emerald-500">
                <Rocket className="mr-1 h-3.5 w-3.5" /> Hosting for Telegram bots & automations
              </Badge>
              <h1 className="text-3xl font-extrabold leading-tight tracking-tight sm:text-5xl">
                Ship your bots to the cloud.
                <span className="block text-emerald-500">Keep every process honest.</span>
              </h1>
              <p className="mt-4 max-w-xl text-base text-muted-foreground sm:text-lg">
                BotDock Cloud runs your Python, Node.js and Bun bots in isolated, resource-protected
                processes with real logs, real metrics — and free hosting during launch.
              </p>
              <div className="mt-8 flex flex-wrap gap-3">
                <Button size="lg" className="bg-emerald-600 hover:bg-emerald-500" onClick={() => void goAuth("/register")}>
                  Create free account
                </Button>
                <Button size="lg" variant="outline" onClick={() => void goAuth("/login")}>
                  Sign in
                </Button>
              </div>
              <dl className="mt-10 grid max-w-md grid-cols-3 gap-4 text-center">
                {[
                  { icon: Layers, k: "3 runtimes", v: "Python · Node · Bun" },
                  { icon: Cpu, k: "Isolated", v: "per-bot limits" },
                  { icon: ScrollText, k: "Real logs", v: "build + runtime" },
                ].map((s) => (
                  <div key={s.k} className="rounded-xl border bg-card/60 p-3">
                    <s.icon className="mx-auto h-4 w-4 text-emerald-500" />
                    <dt className="mt-1 text-xs font-semibold">{s.k}</dt>
                    <dd className="text-[11px] text-muted-foreground">{s.v}</dd>
                  </div>
                ))}
              </dl>
            </div>

            {/* Terminal mock */}
            <div className="relative">
              <div className="overflow-hidden rounded-2xl border border-border bg-zinc-950 shadow-2xl">
                <div className="flex items-center gap-1.5 border-b border-zinc-800 px-4 py-3">
                  <span className="h-3 w-3 rounded-full bg-red-500/80" />
                  <span className="h-3 w-3 rounded-full bg-amber-500/80" />
                  <span className="h-3 w-3 rounded-full bg-emerald-500/80" />
                  <span className="ml-3 font-mono text-xs text-zinc-500">botdock — deploy</span>
                </div>
                <pre className="overflow-x-auto p-4 font-mono text-[12px] leading-6 text-zinc-300 sm:text-[13px]">
{`$ botdock deploy my-telegram-bot
✓ runtime PYTHON detected
✓ installing dependencies (requirements.txt)
✓ build completed
✓ process started (pid 4211, limits applied)
● state: RUNNING — logs streaming…
`}
                </pre>
              </div>
              <div className="absolute -bottom-4 left-6 rounded-lg border border-emerald-500/30 bg-card px-3 py-2 text-xs shadow-lg">
                <span className="mr-2 inline-block h-2 w-2 animate-pulse rounded-full bg-emerald-500" />
                status measured from the live process — never fabricated
              </div>
            </div>
          </div>
        </section>

        {/* Features */}
        <section id="features" className="border-t border-border/60 bg-muted/20">
          <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6">
            <h2 className="text-2xl font-bold tracking-tight sm:text-3xl">Everything a bot operator needs</h2>
            <p className="mt-2 max-w-2xl text-muted-foreground">Built as a real hosting platform — control plane, isolated runtime workers, and data you can trust.</p>
            <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {FEATURES.map((f) => (
                <Card key={f.title} className="transition-colors hover:border-emerald-500/40">
                  <CardContent className="pt-6">
                    <f.icon className="h-6 w-6 text-emerald-500" />
                    <h3 className="mt-3 font-semibold">{f.title}</h3>
                    <p className="mt-1.5 text-sm text-muted-foreground">{f.body}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* How it works */}
        <section id="how" className="border-t border-border/60">
          <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6">
            <h2 className="text-2xl font-bold tracking-tight sm:text-3xl">From repo to running bot in minutes</h2>
            <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
              {STEPS.map((s) => (
                <div key={s.n} className="relative rounded-xl border bg-card p-5">
                  <span className="absolute -top-3 left-5 grid h-7 w-7 place-items-center rounded-full bg-emerald-600 text-xs font-bold text-white">{s.n}</span>
                  <h3 className="mt-2 font-semibold">{s.title}</h3>
                  <p className="mt-1.5 text-sm text-muted-foreground">{s.body}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Pricing */}
        <section id="pricing" className="border-t border-border/60 bg-muted/20">
          <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6">
            <h2 className="text-2xl font-bold tracking-tight sm:text-3xl">Free during launch</h2>
            <p className="mt-2 max-w-2xl text-muted-foreground">
              Every account gets the free hosting plan automatically — no payment method, no subscription, no checkout.
              Bots run with real, system-wide resource protection. What you see is what you get.
            </p>
            <div className="mt-10">
              <Pricing onSignup={() => void goAuth("/register")} />
            </div>
          </div>
        </section>

        {/* Docs */}
        <section id="docs" className="border-t border-border/60">
          <div className="mx-auto grid max-w-6xl gap-8 px-4 py-16 sm:px-6 lg:grid-cols-2">
            <div>
              <h2 className="text-2xl font-bold tracking-tight sm:text-3xl">Developer docs</h2>
              <p className="mt-2 text-muted-foreground">
                BotDock detects your project&apos;s runtime and dependencies automatically. Bring a
                <code className="mx-1 rounded bg-muted px-1.5 py-0.5 font-mono text-xs">requirements.txt</code> or
                <code className="mx-1 rounded bg-muted px-1.5 py-0.5 font-mono text-xs">package.json</code>, pick an entry file,
                and deploy.
              </p>
              <ul className="mt-6 space-y-3 text-sm">
                <li className="flex gap-2"><HardDrive className="mt-0.5 h-4 w-4 shrink-0 text-emerald-500" /> Start command auto-detected: main.py, bot.py, index.js or package.json scripts.start</li>
                <li className="flex gap-2"><Boxes className="mt-0.5 h-4 w-4 shrink-0 text-emerald-500" /> Env vars are encrypted at rest and injected at process start — never shown again</li>
                <li className="flex gap-2"><ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-emerald-500" /> Your code never runs inside the platform process; limits are enforced by the runtime worker</li>
              </ul>
              {hasArchive ? (
                <div className="mt-6 flex flex-wrap gap-2">
                  <Button asChild variant="outline" size="sm">
                    <a href="/api/download?file=botdock-cloud.zip"><Download className="mr-2 h-4 w-4" /> Download source (.zip)</a>
                  </Button>
                  <Button asChild variant="outline" size="sm">
                    <a href="/api/download?file=botdock-cloud.tar.gz"><Download className="mr-2 h-4 w-4" /> Download source (.tar.gz)</a>
                  </Button>
                </div>
              ) : null}
            </div>
            <Card className="overflow-hidden">
              <div className="border-b bg-muted/40 px-4 py-2 font-mono text-xs text-muted-foreground">python-telegram-bot example</div>
              <pre className="overflow-x-auto p-4 font-mono text-[12px] leading-6 text-zinc-300">
{`# main.py — set BOT_TOKEN in Env settings
from telegram.ext import Application, MessageHandler, filters

async def echo(update, context):
    await update.message.reply_text(update.message.text)

app = Application.builder().token(TOKEN).build()
app.add_handler(MessageHandler(filters.TEXT, echo))
app.run_polling()`}
              </pre>
            </Card>
          </div>
        </section>
      </main>

      {/* Sticky footer */}
      <footer className="mt-auto border-t border-border/60 bg-muted/20">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-4 px-4 py-8 sm:flex-row sm:px-6">
          <div className="flex items-center gap-6">
            <Logo />
            <span className="text-xs text-muted-foreground">© {new Date().getFullYear()} BotDock Cloud</span>
          </div>
          <nav className="flex flex-wrap items-center justify-center gap-x-4 gap-y-2 text-xs text-muted-foreground" aria-label="Footer">
            <a href="#features" className="hover:text-foreground">Features</a>
            <a href="#pricing" className="hover:text-foreground">Pricing</a>
            <Link href="/docs" className="hover:text-foreground">Docs</Link>
            <Link href="/support" className="hover:text-foreground">Support</Link>
            <Link href="/status" className="hover:text-foreground">Status</Link>
            <Link href="/security" className="hover:text-foreground">Security</Link>
            <Link href="/terms" className="hover:text-foreground">Terms</Link>
            <Link href="/privacy" className="hover:text-foreground">Privacy</Link>
            <Link href="/aup" className="hover:text-foreground">AUP</Link>
            <button onClick={() => void goAuth("/login")} className="hover:text-foreground">Sign in</button>
          </nav>
        </div>
      </footer>
    </div>
  );
}
