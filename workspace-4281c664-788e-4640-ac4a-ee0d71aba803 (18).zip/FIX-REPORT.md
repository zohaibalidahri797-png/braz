# FIX-REPORT — BotDock Cloud / Cloudflare deployment failure

**Deliverable:** `BotDock-Cloudflare-Fixed.zip` · **Date:** 2026-10-28 · **Scope:** deployment repair only — zero application-code, API, auth, schema, or feature changes.

---

## 1. Confirmed root cause

The failed Cloudflare build ran **only**:

```
Executing user deploy command: npx wrangler deploy
npm warn exec The following package was not found and will be installed: wrangler@4.154.0
[ERROR] Could not detect a directory containing static files (e.g. html, css and js) for the project
```

Two independent problems, both confirmed by inspection **and by local reproduction**:

### Cause 1 — No build command was configured (confirmed)

The log shows no build or install output: `npx` had to download wrangler itself
(`node_modules` absent), tool detection was empty, and no `.open-next/` output
was ever produced. A fresh clone contains neither `node_modules` nor the
OpenNext build output (`.open-next/` is deliberately never committed), so a
bare `npx wrangler deploy` can never deploy this application.

### Cause 2 — No `wrangler.jsonc` in the directory wrangler executed in (confirmed by error fingerprint)

Reproduced locally with wrangler (the exact version Cloudflare fetched, 4.154.0):

| Scenario | Error produced |
|---|---|
| `wrangler.jsonc` present, no build output | `The entry-point file at ".open-next/worker.js" was not found.` |
| **no `wrangler.jsonc` in cwd** | `Could not detect a directory containing static files (e.g. html, css and js) for the project` ← **your exact error** |

The repository **does** track `wrangler.jsonc` at the top level (verified in
git). Therefore the clone Cloudflare built was not the full repository. Most
likely: the GitHub repo received a partial/manual upload, or the Cloudflare
project's **Root directory** is not the repo root. (If the root had been
`public/` — which contains HTML files — wrangler would have deployed the static
site instead of erroring, so it is neither the full repo nor `public/`.)

**What this project is:** a full-stack Next.js 16 app (App Router + REST API +
Prisma + auth). It deploys as a **Cloudflare Worker with static assets** via
`@opennextjs/cloudflare` — never as a static/Pages site. This was NOT changed.

---

## 2. Files changed (and why each change was necessary)

| File | Change | Why |
|---|---|---|
| `package.json` | added `"engines": { "node": ">=20.9.0" }` | States the real Node requirement (Next.js 16) and lets the Cloudflare build image pin a modern Node ("Detected the following tools" was empty in the failed log). No behavior change locally. |
| `docs/DEPLOYMENT.md` | rewrote the "Continuous deployment (GitHub)" section with the exact Workers Builds settings + failure diagnosis | The correct settings existed but were too brief; the new section explains every piece of the build command and both confirmed causes of this exact error. |
| `README.md` | added "Deploying from GitHub with Cloudflare Workers Builds" with the exact settings table | Anyone connecting the repo sees the required configuration immediately. |
| `FIX-REPORT.md` | new (this file) | Required deployment documentation. |
| `scripts/package-release.sh` | emits `BotDock-Cloudflare-Fixed.zip` (byte-identical copy of the validated archive) + requires `FIX-REPORT.md` as an essential file | The required deliverable name, produced only from a validated archive. |
| `src/app/api/download/route.ts` | added `BotDock-Cloudflare-Fixed.zip` to the download allowlist | Makes the deliverable downloadable through the app's `/api/download` endpoint (served byte-identical, sha256-verified). |

**Not changed:** all application code, API routes, auth, Prisma schema and
migrations, bot runtime service, environment variable names, UI, `wrangler.jsonc`,
`open-next.config.ts`, `next.config.ts`, CI workflow, and every test.

**Repair during verification (sandbox damage, not related to the deployment
error):** the working tree had lost `src/app/api/bots/upload/route.ts` and
`src/app/api/bots/[id]/files/upload/route.ts` (sandbox reset artifacts that had
been swept into a previous commit). Both were restored from git history
(`d6d42cc`) — they implement the zip/tar.gz bot-upload feature and are required
for the E2E battery to pass. No logic was altered; the files are byte-identical
to the last verified state.

---

## 3. Exact Cloudflare dashboard settings (Workers Builds)

Workers & Pages → your Worker → **Settings → Build → Edit build configuration**:

| Setting | Value |
|---|---|
| Root directory | `/` (repo root — default) |
| **Build command** | `npm install --no-audit --no-fund && npx prisma generate && npx opennextjs-cloudflare build && node scripts/cf-clean.mjs` |
| **Deploy command** | `node scripts/cf-verify.mjs && npx opennextjs-cloudflare deploy` |
| Build watch paths | default |
| Build variables | **none required** (verified: build succeeds with zero env vars; `cf-clean` guarantees no build-time value reaches the bundle) |

Why every piece exists (do not trim):

- `npm install` — makes the build self-sufficient regardless of whether the
  build image auto-installed dependencies.
- `npx prisma generate` — the Prisma client is generated into `node_modules`
  (not committed). Modern npm skips postinstall scripts by default; verified
  that without this step the client is not generated.
- `npx opennextjs-cloudflare build` — the real build (`next build` →
  `.open-next/worker.js` + `.open-next/assets/`). This is the step the failed
  deployment never ran.
- `node scripts/cf-clean.mjs` — security scrub: removes `.env`/`db/`/logs that
  standalone builds copy into the bundle and strips build-time env values from
  `.open-next/cloudflare/next-env.mjs`.
- `node scripts/cf-verify.mjs` — pre-deploy gate: blocks deploy on missing
  output, wrong wiring, stale build (BUILD_ID mismatch), or leaked secrets.
- `npx opennextjs-cloudflare deploy` — adapter-driven deploy (safer than bare
  `npx wrangler deploy`, which is what failed).

**Minimal variant (works, weaker):** Build `npx opennextjs-cloudflare build &&
node scripts/cf-clean.mjs` · Deploy `npx wrangler deploy` — succeeds once
`wrangler.jsonc` is present in the repo, but loses the pre-deploy gate.

### After the build goes green (still required)

Secrets are Worker-side, never repository variables (`wrangler secret put` or
dashboard Variables & Secrets — same names, see `docs/DEPLOYMENT.md` §4):
`APP_SECRET`, `DATABASE_URL` (remote libSQL/Turso — Workers cannot open local
SQLite files), `LIBSQL_AUTH_TOKEN`, `RUNTIME_SERVICE_URL`, `RUNTIME_API_KEY`,
`RUNTIME_EMBEDDED=false`, optional OAuth/email keys, `ADMIN_BOOTSTRAP_TOKEN`.

---

## 4. Verification performed (all real, reproducible)

### Cold-clone simulation of the exact dashboard commands (the decisive test)

Staged a fresh copy of the project **without `.env`** (mirroring the Cloudflare
build environment) and ran the exact build command above, then the deploy gate,
then wrangler resolution:

1. `npm install --no-audit --no-fund` — PASS (note: modern npm skips dependency
   postinstall scripts — proving `npx prisma generate` must be explicit)
2. `npx prisma generate` — PASS
3. `npx opennextjs-cloudflare build` — **PASS with zero environment variables**
   (`Worker saved in .open-next/worker.js`)
4. `node scripts/cf-clean.mjs` — PASS (removed leaked `download/`, scrubbed
   `next-env.mjs`)
5. `node scripts/cf-verify.mjs` — **8/8 gates PASS**
6. `npx wrangler deploy --dry-run` — **PASS: 67 asset files, Total Upload
   7918.67 KiB, ASSETS binding resolved** (wrangler 4.154.0 — the exact version
   from the failed Cloudflare log; `--dry-run` uploads nothing)

### Root-cause reproduction

`wrangler deploy` without `wrangler.jsonc` → reproduces the user's exact error
string (see table above). With the config present but unbuilt → the distinct
entry-point error. This distinguishes the two failure modes conclusively.

### Full regression battery (main tree, after the fix)

| Check | Result |
|---|---|
| `bunx tsc --noEmit` | **0 errors** |
| `bun run lint` | **clean** |
| `bun test tests/` | **33/33 pass** |
| `bun run cf:build` (bun path) | PASS (cf-clean removed 7 items) |
| `bun run cf:verify` | **8/8 gates PASS** |
| `tests/worker-route-matrix.sh` (workerd) | **12/12 assertions** |
| `MATRIX_NO_APP_URL=1` variant | **12/12 assertions** |
| `tests/full-e2e.sh` | **70/70 PASS, 0 FAIL** (5 BLOCKED are credential-limited: real OAuth handshake, real Resend delivery, real Turso DB, real CF-account deploy, no-APP_SECRET startup drill — all pre-existing and honestly labeled) |

### Known test-blockers (need user credentials, not code)

Real OAuth linking, real email delivery, a real Turso/libSQL database, and an
actual deploy to a Cloudflare account could not be exercised from this
environment. The build/deploy pipeline itself is verified up to the `--dry-run`
boundary; the final upload requires your Cloudflare credentials.

---

## 5. Remaining external requirements (unchanged architecture)

- **Production database:** remote libSQL/Turso (or Postgres+Hyperdrive) —
  Workers cannot open local SQLite files. Apply migrations with
  `bun run db:migrate:deploy`.
- **Bot runtime:** Cloudflare Workers CANNOT host persistent bot processes.
  The separate runtime service (`mini-services/bot-runtime`) must run on a
  small always-on Linux host — see `docs/RUNTIME-DEPLOYMENT.md`. This
  architecture is deliberate and preserved.
- **Secrets:** set post-deploy via `wrangler secret put` (list above).

## 6. How to apply this fix

1. Replace your GitHub repository contents with the contents of
   `BotDock-Cloudflare-Fixed.zip` (upload the FULL archive — verify
   `wrangler.jsonc` and `open-next.config.ts` appear at the TOP level of the
   repo's default branch), or push this repository as-is.
2. Apply the dashboard settings from §3 exactly.
3. Retry the deployment; the log must show install → `prisma generate` →
   `next build` → `cf-clean` → `cf-verify (RESULT: OK)` → deploy.
4. Add the Worker secrets (§3), then run the post-deploy checklist in
   `docs/DEPLOYMENT.md` §7 against your `*.workers.dev` host.
