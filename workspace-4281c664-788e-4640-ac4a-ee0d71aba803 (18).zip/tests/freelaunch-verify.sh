#!/bin/bash
# Free-launch functional verification (Phase F) — run against localhost:3000
set -u
BASE="http://localhost:3000"
J1="/tmp/fx-user1.jar"; J2="/tmp/fx-user2.jar"
PASS=0; FAIL=0
check() { # $1 name, $2 expected, $3 actual
  if [ "$2" = "$3" ]; then PASS=$((PASS+1)); echo "PASS  $1";
  else FAIL=$((FAIL+1)); echo "FAIL  $1  (expected: $2 | got: $3)"; fi
}
contains() { # $1 name, $2 needle, $3 haystack
  if echo "$3" | grep -q "$2"; then PASS=$((PASS+1)); echo "PASS  $1";
  else FAIL=$((FAIL+1)); echo "FAIL  $1  (missing: $2 in: $(echo "$3" | head -c 200))"; fi
}
notcontains() {
  if echo "$3" | grep -q "$2"; then FAIL=$((FAIL+1)); echo "FAIL  $1  (found unwanted: $2)"; else PASS=$((PASS+1)); echo "PASS  $1"; fi
}

EMAIL1="freeuser$RANDOM@botdock.test"
EMAIL2="freeuser$RANDOM@botdock.test"

echo "=== 1. Registration (email + password, no payment) ==="
R=$(curl -s -c "$J1" -X POST "$BASE/api/auth/register" -H "Content-Type: application/json" -H "Origin: $BASE" -d "{\"name\":\"Free Tester\",\"email\":\"$EMAIL1\",\"password\":\"freepass123\"}")
check "register returns ok" "true" "$(echo "$R" | grep -o '"ok":true' | head -1 | sed 's/"ok":true/true/')"
check "register requires no payment fields" "true" "$(echo "$R" | grep -oq 'payment\|card\|checkout' && echo false || echo true)"
DEVLINK=$(echo "$R" | grep -o '"/api/auth/verify-email?token=[^"]*"' | head -1 | tr -d '"')
[ -n "$DEVLINK" ] && echo "  (dev verification link obtained)"

echo "=== 2. Duplicate email ==="
CODE=$(curl -s -o /tmp/fx-dup.json -w "%{http_code}" -X POST "$BASE/api/auth/register" -H "Content-Type: application/json" -H "Origin: $BASE" -d "{\"name\":\"Dup\",\"email\":\"$EMAIL1\",\"password\":\"freepass123\"}")
check "duplicate email → 409" "409" "$CODE"

echo "=== 3. Email verification via dev link ==="
CODE=$(curl -s -o /tmp/fx-verify.json -w "%{http_code}" "$BASE$DEVLINK")
check "verify-email endpoint 200" "200" "$CODE"

echo "=== 4. Login + session ==="
CODE=$(curl -s -o /tmp/fx-login.json -w "%{http_code}" -c "$J1" -X POST "$BASE/api/auth/login" -H "Content-Type: application/json" -H "Origin: $BASE" -d "{\"email\":\"$EMAIL1\",\"password\":\"freepass123\"}")
check "login 200" "200" "$CODE"
ME=$(curl -s -b "$J1" "$BASE/api/auth/me")
check "session persists (me works)" "true" "$(echo "$ME" | grep -oq '"email"' && echo true || echo false)"

echo "=== 5. Auth config honesty (OAuth unconfigured) ==="
CFG=$(curl -s "$BASE/api/auth/config")
contains "config reports google=false" '"google":false' "$CFG"
contains "config reports githubOAuth=false" '"githubOAuth":false' "$CFG"
contains "config reports emailConfigured=false" '"emailConfigured":false' "$CFG"

echo "=== 6. OAuth start without credentials → honest 501 ==="
CODE=$(curl -s -o /tmp/fx-oauth.json -w "%{http_code}" "$BASE/api/auth/oauth/google")
check "google oauth start → 501" "501" "$CODE"
contains "501 explains missing credentials" "GOOGLE_CLIENT_ID" "$(cat /tmp/fx-oauth.json)"

echo "=== 7. Paid checkout inactive ==="
CODE=$(curl -s -o /tmp/fx-sub.json -w "%{http_code}" -b "$J1" -X POST "$BASE/api/subscription" -H "Content-Type: application/json" -H "Origin: $BASE" -d '{"planId":"pro"}')
check "POST /api/subscription → 501 (free-only)" "501" "$CODE"
CODE=$(curl -s -o /tmp/fx-wh.json -w "%{http_code}" -b "$J1" -X POST "$BASE/api/billing/webhook" -H "Content-Type: application/json" -H "Origin: $BASE" -d '{}')
check "POST /api/billing/webhook → 501 (disabled)" "501" "$CODE"

echo "=== 8. Plans API: free-only, no old quota copy ==="
PL=$(curl -s "$BASE/api/plans")
contains "plans freeOnly:true" '"freeOnly":true' "$PL"
notcontains "no '3 hosted bots' in plans" "3 hosted bots" "$PL"
notcontains "no '256 MB memory per bot' in plans" "256 MB memory per bot" "$PL"
notcontains "no '200 MB storage' in plans" "200 MB storage" "$PL"
notcontains "no '10 deployments/day' in plans" "10 deployments/day" "$PL"
contains "launch copy present" "Free during launch" "$PL"

echo "=== 9. Usage API: genuine measurements, no plan caps ==="
US=$(curl -s -b "$J1" "$BASE/api/usage")
notcontains "no deploymentsLimit field" "deploymentsLimit" "$US"
notcontains "no storageLimitMb field" "storageLimitMb" "$US"
contains "has resourcePolicy" "resourcePolicy" "$US"
contains "has capacityNote" "capacityNote" "$US"

echo "=== 10. Create FIVE bots (old limit was 3) ==="
IDS=()
for i in 1 2 3 4 5; do
  CODE=$(curl -s -o /tmp/fx-bot$i.json -w "%{http_code}" -b "$J1" -X POST "$BASE/api/bots" -H "Content-Type: application/json" -H "Origin: $BASE" -d "{\"name\":\"quota-test-$i\",\"runtime\":\"BUN\",\"sourceType\":\"TEMPLATE\",\"templateId\":\"bun-keepalive\"}")
  check "bot $i created (201)" "201" "$CODE"
  IDS+=("$(grep -o '"id":"[^"]*"' /tmp/fx-bot$i.json | head -1 | cut -d'"' -f4)")
done
echo "  bot ids: ${IDS[*]}"

echo "=== 11. Deploy + lifecycle on bot 1 (BUN keepalive) ==="
B1="${IDS[0]}"
CODE=$(curl -s -o /tmp/fx-deploy1.json -w "%{http_code}" -b "$J1" -X POST "$BASE/api/bots/$B1/action" -H "Content-Type: application/json" -H "Origin: $BASE" -d '{"action":"deploy"}')
check "deploy #1 accepted (200)" "200" "$CODE"
contains "deploy #1 reports RUNNING" '"state":"RUNNING"' "$(cat /tmp/fx-deploy1.json)"
sleep 2

echo "=== 12. Redeploy without daily-quota block (old quota: 10/day) ==="
for i in 2 3 4; do
  Bi="${IDS[$((i-1))]}"
  R=$(curl -s -b "$J1" -X POST "$BASE/api/bots/$Bi/action" -H "Content-Type: application/json" -H "Origin: $BASE" -d '{"action":"deploy"}')
  if echo "$R" | grep -q '"state":"RUNNING"'; then PASS=$((PASS+1)); echo "PASS  deploy #$i → RUNNING (no quota block)";
  else FAIL=$((FAIL+1)); echo "FAIL  deploy #$i → $(echo "$R" | head -c 200)"; fi
  sleep 2
done
R=$(curl -s -b "$J1" -X POST "$BASE/api/bots/$B1/action" -H "Content-Type: application/json" -H "Origin: $BASE" -d '{"action":"deploy"}')
if echo "$R" | grep -q '"state":"RUNNING"'; then PASS=$((PASS+1)); echo "PASS  redeploy same bot → RUNNING (no quota block)"; else FAIL=$((FAIL+1)); echo "FAIL  redeploy: $(echo "$R" | head -c 200)"; fi

echo "=== 13. Stop / start / restart / logs ==="
R=$(curl -s -b "$J1" -X POST "$BASE/api/bots/$B1/action" -H "Content-Type: application/json" -H "Origin: $BASE" -d '{"action":"stop"}')
check "stop → STOPPED" '"state":"STOPPED"' "$(echo "$R" | grep -o '"state":"STOPPED"' | head -1)"
R=$(curl -s -b "$J1" -X POST "$BASE/api/bots/$B1/action" -H "Content-Type: application/json" -H "Origin: $BASE" -d '{"action":"start"}')
check "start → RUNNING" '"state":"RUNNING"' "$(echo "$R" | grep -o '"state":"RUNNING"' | head -1)"
R=$(curl -s -b "$J1" -X POST "$BASE/api/bots/$B1/action" -H "Content-Type: application/json" -H "Origin: $BASE" -d '{"action":"restart"}')
check "restart → RUNNING" '"state":"RUNNING"' "$(echo "$R" | grep -o '"state":"RUNNING"' | head -1)"
LG=$(curl -s -b "$J1" "$BASE/api/bots/$B1/logs?tail=20")
contains "logs returned with real entries" '"lines"' "$LG"

echo "=== 14. Env vars + files (no plan gates) ==="
CODE=$(curl -s -o /tmp/fx-env.json -w "%{http_code}" -b "$J1" -X PUT "$BASE/api/bots/$B1/env" -H "Content-Type: application/json" -H "Origin: $BASE" -d '{"key":"TEST_VAR","value":"hello","isSecret":true}')
check "env var save (no plan gate)" "200" "$CODE"
CODE=$(curl -s -o /tmp/fx-files.json -w "%{http_code}" -b "$J1" "$BASE/api/bots/$B1/files")
check "files list (no plan gate)" "200" "$CODE"

echo "=== 15. Ownership isolation (user 2 cannot touch user 1 bots) ==="
curl -s -c /tmp/fx-u2reg.json -X POST "$BASE/api/auth/register" -H "Content-Type: application/json" -H "Origin: $BASE" -d "{\"name\":\"Other User\",\"email\":\"$EMAIL2\",\"password\":\"otherpass123\"}" > /dev/null
CODE=$(curl -s -o /tmp/fx-u2login.json -w "%{http_code}" -c "$J2" -X POST "$BASE/api/auth/login" -H "Content-Type: application/json" -H "Origin: $BASE" -d "{\"email\":\"$EMAIL2\",\"password\":\"otherpass123\"}")
check "user 2 login 200" "200" "$CODE"
CODE=$(curl -s -o /tmp/fx-iso.json -w "%{http_code}" -b "$J2" "$BASE/api/bots/$B1")
check "other user GET bot → 404" "404" "$CODE"
CODE=$(curl -s -o /tmp/fx-iso2.json -w "%{http_code}" -b "$J2" -X POST "$BASE/api/bots/$B1/action" -H "Content-Type: application/json" -H "Origin: $BASE" -d '{"action":"stop"}')
check "other user POST action → 404" "404" "$CODE"
CODE=$(curl -s -o /tmp/fx-iso3.json -w "%{http_code}" -b "$J2" "$BASE/api/bots/$B1/logs")
check "other user GET logs → 404" "404" "$CODE"

echo "=== 16. Cleanup test bots ==="
for Bi in "${IDS[@]}"; do
  CODE=$(curl -s -o /dev/null -w "%{http_code}" -b "$J1" -X DELETE "$BASE/api/bots/$Bi")
  check "delete bot $Bi (200)" "200" "$CODE"
done

echo ""
echo "=========================================="
echo "RESULT: PASS=$PASS FAIL=$FAIL"
