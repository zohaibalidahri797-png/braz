/// <reference types="bun-types" />
/**
 * Runtime configuration tests — development vs external-runtime setups.
 * Run with: bun test tests/runtime-config.test.ts
 *
 * Covers the contract documented in docs/DEPLOYMENT.md and .env.example:
 *  - Development default: http://127.0.0.1:<RUNTIME_SERVICE_PORT>
 *  - RUNTIME_SERVICE_URL is honored verbatim when valid
 *  - Invalid/misconfigured values are reported, never silently replaced by localhost
 *  - Public production endpoints must use HTTPS
 *  - RUNTIME_EMBEDDED=false disables the embedded spawn
 */
import { describe, expect, test } from "bun:test";
import { isRuntimeEmbedded, resolveRuntimeUrl, type RuntimeEnvLike } from "../src/lib/runtime-config";

const DEV: RuntimeEnvLike = { NODE_ENV: "development" };
const PROD: RuntimeEnvLike = { NODE_ENV: "production" };

describe("resolveRuntimeUrl — development", () => {
  test("defaults to localhost with the default port", () => {
    const r = resolveRuntimeUrl(DEV);
    expect(r.url).toBe("http://127.0.0.1:3030");
    expect(r.source).toBe("default-local");
    expect(r.invalid).toBe(false);
  });

  test("honors RUNTIME_SERVICE_PORT for the localhost default", () => {
    const r = resolveRuntimeUrl({ NODE_ENV: "development", RUNTIME_SERVICE_PORT: "4040" });
    expect(r.url).toBe("http://127.0.0.1:4040");
  });

  test("falls back to 3030 for a malformed port", () => {
    const r = resolveRuntimeUrl({ NODE_ENV: "development", RUNTIME_SERVICE_PORT: "not-a-port" });
    expect(r.url).toBe("http://127.0.0.1:3030");
  });

  test("RUNTIME_SERVICE_URL is used verbatim when valid (localhost)", () => {
    const r = resolveRuntimeUrl({
      NODE_ENV: "development",
      RUNTIME_SERVICE_URL: "http://127.0.0.1:3030",
    });
    expect(r.url).toBe("http://127.0.0.1:3030");
    expect(r.source).toBe("configured");
    expect(r.invalid).toBe(false);
  });

  test("private-network http URLs are accepted in development", () => {
    const r = resolveRuntimeUrl({
      NODE_ENV: "development",
      RUNTIME_SERVICE_URL: "http://192.168.1.10:3030",
    });
    expect(r.url).toBe("http://192.168.1.10:3030");
    expect(r.invalid).toBe(false);
  });
});

describe("resolveRuntimeUrl — external runtime (production)", () => {
  test("https public URL is accepted and normalized (no trailing slash/path)", () => {
    const r = resolveRuntimeUrl({
      NODE_ENV: "production",
      RUNTIME_SERVICE_URL: "https://runtime.botdock.example.com/",
    });
    expect(r.url).toBe("https://runtime.botdock.example.com");
    expect(r.source).toBe("configured");
    expect(r.invalid).toBe(false);
  });

  test("plain http public URL is REJECTED in production", () => {
    const r = resolveRuntimeUrl({
      NODE_ENV: "production",
      RUNTIME_SERVICE_URL: "http://runtime.botdock.example.com",
    });
    expect(r.url).toBe("");
    expect(r.invalid).toBe(true);
    expect(r.reason).toMatch(/HTTPS/i);
  });

  test("http to loopback is still allowed in production (same-host embedded)", () => {
    const r = resolveRuntimeUrl({
      NODE_ENV: "production",
      RUNTIME_SERVICE_URL: "http://127.0.0.1:3030",
    });
    expect(r.url).toBe("http://127.0.0.1:3030");
    expect(r.invalid).toBe(false);
  });

  test("http to private ranges is allowed in production (private network)", () => {
    const r = resolveRuntimeUrl({
      NODE_ENV: "production",
      RUNTIME_SERVICE_URL: "http://10.0.0.5:3030",
    });
    expect(r.url).toBe("http://10.0.0.5:3030");
    expect(r.invalid).toBe(false);
  });

  test("localhost is NEVER substituted for an invalid external URL", () => {
    const r = resolveRuntimeUrl({
      NODE_ENV: "production",
      RUNTIME_SERVICE_URL: "not a url at all",
    });
    expect(r.url).toBe("");
    expect(r.source).toBe("configured");
    expect(r.invalid).toBe(true);
    expect(r.reason).toContain("not a valid URL");
  });

  test("unsupported protocols are rejected", () => {
    const r = resolveRuntimeUrl({
      NODE_ENV: "production",
      RUNTIME_SERVICE_URL: "ftp://runtime.botdock.example.com",
    });
    expect(r.invalid).toBe(true);
    expect(r.reason).toMatch(/http or https/i);
  });
});

describe("isRuntimeEmbedded", () => {
  test("defaults to embedded (development auto-spawn)", () => {
    expect(isRuntimeEmbedded({})).toBe(true);
    expect(isRuntimeEmbedded({ RUNTIME_EMBEDDED: "true" })).toBe(true);
  });

  test("RUNTIME_EMBEDDED=false disables embedded spawn (Cloudflare Workers)", () => {
    expect(isRuntimeEmbedded({ RUNTIME_EMBEDDED: "false" })).toBe(false);
    // Anything other than exactly "false" keeps embedded semantics.
    expect(isRuntimeEmbedded({ RUNTIME_EMBEDDED: "0" })).toBe(true);
  });
});
