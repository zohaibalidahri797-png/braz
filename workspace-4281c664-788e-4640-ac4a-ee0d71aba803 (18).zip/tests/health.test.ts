/**
 * Unit tests for the /api/health report builder (src/lib/platform-health.ts).
 *
 * The builder is PURE — probes (DB ping, runtime ping) are injected — so every
 * branch (healthy / unconfigured / unreachable / error) is covered here
 * without touching a real database or the runtime service. The live endpoint
 * itself is additionally verified end-to-end via curl in tests/full-e2e.sh.
 */
import { describe, expect, test } from "bun:test";
import {
  appSecretStatus,
  appUrlStatus,
  buildHealthReport,
  emailProviderStatus,
  oauthProviderStatus,
  type HealthProbeInput,
} from "../src/lib/platform-health";

const healthyProbes: HealthProbeInput = {
  dbOk: true,
  runtimePing: { ok: true, version: "1.0.0", uptimeSec: 42, activeBots: 0 },
  runtimeEmbedded: true,
  runtimeUrlSource: "default-local",
};

const cleanEnv = {
  APP_SECRET: "x".repeat(64),
  APP_URL: "https://botdock.example.com",
  DATABASE_URL: "libsql://db.turso.io",
  GOOGLE_CLIENT_ID: "gid",
  GOOGLE_CLIENT_SECRET: "gsec",
  GITHUB_CLIENT_ID: "hid",
  GITHUB_CLIENT_SECRET: "hsec",
  RESEND_API_KEY: "re_123",
  EMAIL_FROM: "BotDock <no-reply@example.com>",
  NODE_ENV: "production",
};

describe("config detection helpers", () => {
  test("oauthProviderStatus requires BOTH id and secret", () => {
    expect(oauthProviderStatus({ GOOGLE_CLIENT_ID: "a", GOOGLE_CLIENT_SECRET: "b" })).toEqual({
      google: true,
      github: false,
    });
    expect(oauthProviderStatus({ GOOGLE_CLIENT_ID: "a" }).google).toBe(false); // secret missing
    expect(oauthProviderStatus({}).google).toBe(false);
  });

  test("emailProviderStatus distinguishes resend from none", () => {
    expect(emailProviderStatus({ RESEND_API_KEY: "re_x" }).provider).toBe("resend");
    expect(emailProviderStatus({}).provider).toBe("none");
    expect(emailProviderStatus({ EMAIL_FROM: "a@b.c" }).fromConfigured).toBe(true);
    expect(emailProviderStatus({}).fromConfigured).toBe(false);
  });

  test("appSecretStatus enforces the 32-char minimum without throwing", () => {
    expect(appSecretStatus({}).configured).toBe(false);
    expect(appSecretStatus({ APP_SECRET: "short" }).valid).toBe(false);
    expect(appSecretStatus({ APP_SECRET: "x".repeat(32) }).valid).toBe(true);
  });

  test("appUrlStatus reports https correctness", () => {
    expect(appUrlStatus({ APP_URL: "https://x.dev" })).toEqual({
      configured: true,
      url: "https://x.dev",
      https: true,
    });
    expect(appUrlStatus({ APP_URL: "http://localhost:3000" }).https).toBe(false);
    expect(appUrlStatus({}).configured).toBe(false);
  });
});

describe("buildHealthReport", () => {
  test("fully configured deployment → every component healthy", () => {
    const r = buildHealthReport(healthyProbes, cleanEnv);
    expect(r.ok).toBe(true);
    expect(r.degraded).toBe(false);
    expect(r.app.status).toBe("healthy");
    expect(r.database.status).toBe("healthy");
    expect(r.database.transport).toBe("libsql-remote");
    expect(r.auth.status).toBe("healthy");
    expect(r.email.status).toBe("healthy");
    expect(r.runtime.status).toBe("healthy");
    expect(r.runtime.version).toBe("1.0.0");
  });

  test("missing APP_SECRET → app+auth unconfigured, never 'healthy'", () => {
    const r = buildHealthReport(healthyProbes, { ...cleanEnv, APP_SECRET: "" });
    expect(r.app.status).toBe("unconfigured");
    expect(r.app.appSecretConfigured).toBe(false);
    expect(r.auth.status).toBe("unconfigured");
    // A missing secret must NOT mark unrelated components unhealthy:
    expect(r.database.status).toBe("healthy");
    expect(r.email.status).toBe("healthy");
  });

  test("database down → database unreachable, ok=false, auth degraded", () => {
    const r = buildHealthReport({ ...healthyProbes, dbOk: false }, cleanEnv);
    expect(r.database.status).toBe("unreachable");
    expect(r.ok).toBe(false);
    expect(r.degraded).toBe(true);
    expect(r.auth.status).toBe("unreachable");
  });

  test("runtime down → runtime unreachable while core stays ok", () => {
    const r = buildHealthReport(
      { ...healthyProbes, runtimePing: { ok: false } },
      cleanEnv,
    );
    expect(r.runtime.status).toBe("unreachable");
    expect(r.runtime.ok).toBe(false);
    expect(r.ok).toBe(true); // core (app+db) still healthy
    expect(r.degraded).toBe(true);
  });

  test("invalid runtime configuration → runtime error status with reason withheld", () => {
    const r = buildHealthReport(
      { ...healthyProbes, runtimeConfigError: "RUNTIME_SERVICE_URL is not a valid URL: \"ftp://x\"" },
      cleanEnv,
    );
    expect(r.runtime.status).toBe("error");
  });

  test("email unconfigured → email unconfigured (NOT unhealthy)", () => {
    const r = buildHealthReport(healthyProbes, { ...cleanEnv, RESEND_API_KEY: "" });
    expect(r.email.status).toBe("unconfigured");
    expect(r.email.provider).toBe("none");
    expect(r.ok).toBe(true);
  });

  test("oauth providers unconfigured → booleans false, auth still healthy", () => {
    const r = buildHealthReport(healthyProbes, {
      ...cleanEnv,
      GOOGLE_CLIENT_ID: "",
      GOOGLE_CLIENT_SECRET: "",
      GITHUB_CLIENT_ID: "",
      GITHUB_CLIENT_SECRET: "",
    });
    expect(r.auth.googleConfigured).toBe(false);
    expect(r.auth.githubConfigured).toBe(false);
    expect(r.auth.status).toBe("healthy");
  });

  test("SECRETS ARE NEVER INCLUDED in any part of the report", () => {
    const r = buildHealthReport(healthyProbes, cleanEnv);
    const json = JSON.stringify(r);
    expect(json).not.toContain(cleanEnv.APP_SECRET);
    expect(json).not.toContain("gsec");
    expect(json).not.toContain("hsec");
    expect(json).not.toContain("re_123");
    expect(JSON.stringify(r.app)).not.toContain("APP_SECRET");
  });

  test("local sqlite database reports sqlite-local transport", () => {
    const r = buildHealthReport(healthyProbes, {
      ...cleanEnv,
      DATABASE_URL: "file:./db/custom.db",
      NODE_ENV: "development",
    });
    expect(r.database.transport).toBe("sqlite-local");
    expect(r.app.nodeEnv).toBe("development");
  });
});
