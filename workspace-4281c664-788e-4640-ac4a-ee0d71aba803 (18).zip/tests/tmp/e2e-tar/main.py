print("py ok")
