/**
 * MOCKED provider tests for src/lib/email.ts.
 *
 * These tests stub the Resend REST API (global fetch) and the database layer,
 * so NO real HTTP request is made and NO real API key is used. They exist to
 * prove the HONEST error behavior required of the email provider integration:
 *
 *   1. no RESEND_API_KEY          → delivered:false, provider "none",
 *                                    EmailLog row status SKIPPED (never a
 *                                    fake "sent")
 *   2. Resend returns 401         → delivered:false, error surfaced
 *                                    (`resend_http_401…`), FAILED row recorded
 *   3. Resend returns 500         → same honest failure path
 *   4. network error (fetch throws) → delivered:false, FAILED row, no throw
 *   5. Resend returns 200         → delivered:true, provider "resend", SENT row
 *   6. devLinksEnabled() gating   → dev link disclosure only when
 *                                    DEV_SHOW_EMAIL_LINKS=true AND no provider
 *
 * Live Resend delivery itself is BLOCKED on a real RESEND_API_KEY (see
 * docs/SETUP.md) and is therefore intentionally NOT claimed here.
 */
import { describe, expect, test, mock, afterAll } from "bun:test";

// Stub the DB layer BEFORE importing the module under test (email.ts writes
// EmailLog rows on every path; the stub records the calls for assertions).
const emailLogRows: Record<string, unknown>[] = [];
mock.module("@/lib/db", () => ({
  db: {
    emailLog: {
      create: async (args: { data: Record<string, unknown> }) => {
        emailLogRows.push(args.data);
        return {};
      },
    },
  },
}));

const { sendEmail, emailProviderConfigured, devLinksEnabled, verificationEmail, passwordResetEmail } =
  await import("../src/lib/email");

const KEY = "re_test_key_NOT_A_REAL_KEY_1234567890";
let originalFetch: typeof globalThis.fetch;

function stubResend(status: number, body: string): void {
  globalThis.fetch = (async () =>
    new Response(body, { status, headers: { "content-type": "application/json" } })) as unknown as typeof fetch;
}

const input = {
  to: "user@example.com",
  subject: "Test subject",
  text: "hello",
  html: "<p>hello</p>",
  template: "test",
};

afterAll(() => {
  globalThis.fetch = originalFetch;
  delete process.env.RESEND_API_KEY;
  delete process.env.DEV_SHOW_EMAIL_LINKS;
  delete process.env.EMAIL_FROM;
});
originalFetch = globalThis.fetch;

describe("email provider (MOCKED Resend API)", () => {
  test("1. no API key → honest SKIP, never a fake delivery", async () => {
    delete process.env.RESEND_API_KEY;
    const before = emailLogRows.length;
    expect(emailProviderConfigured()).toBe(false);
    const r = await sendEmail(input);
    expect(r.delivered).toBe(false);
    expect(r.provider).toBe("none");
    expect(r.error).toBeUndefined();
    const row = emailLogRows[before] as Record<string, unknown>;
    expect(row.status).toBe("SKIPPED");
    expect(row.provider).toBe("none");
  });

  test("2. Resend 401 → delivered:false with resend_http_401 error + FAILED row", async () => {
    process.env.RESEND_API_KEY = KEY;
    expect(emailProviderConfigured()).toBe(true);
    stubResend(401, JSON.stringify({ message: "Invalid API key" }));
    const before = emailLogRows.length;
    const r = await sendEmail(input);
    expect(r.delivered).toBe(false);
    expect(r.provider).toBe("resend");
    expect(r.error).toContain("resend_http_401");
    expect(r.error).toContain("Invalid API key");
    const row = emailLogRows[before] as Record<string, unknown>;
    expect(row.status).toBe("FAILED");
    expect(row.provider).toBe("resend");
    expect(String(row.error)).toContain("resend_http_401");
  });

  test("3. Resend 500 → honest failure, no exception escapes", async () => {
    stubResend(500, "upstream exploded");
    const r = await sendEmail(input);
    expect(r.delivered).toBe(false);
    expect(r.error).toContain("resend_http_500");
  });

  test("4. network error (fetch throws) → delivered:false, FAILED row, no throw", async () => {
    globalThis.fetch = (async () => {
      throw new Error("ECONNREFUSED (mocked)");
    }) as unknown as typeof fetch;
    const before = emailLogRows.length;
    const r = await sendEmail(input);
    expect(r.delivered).toBe(false);
    expect(r.error).toContain("ECONNREFUSED");
    const row = emailLogRows[before] as Record<string, unknown>;
    expect(row.status).toBe("FAILED");
  });

  test("5. Resend 200 → delivered:true, provider resend, SENT row", async () => {
    stubResend(200, JSON.stringify({ id: "mock-email-id" }));
    const before = emailLogRows.length;
    const r = await sendEmail(input);
    expect(r.delivered).toBe(true);
    expect(r.provider).toBe("resend");
    expect(r.error).toBeUndefined();
    const row = emailLogRows[before] as Record<string, unknown>;
    expect(row.status).toBe("SENT");
  });

  test("6. dev link disclosure only in dev mode without a provider", () => {
    delete process.env.RESEND_API_KEY;
    process.env.DEV_SHOW_EMAIL_LINKS = "true";
    expect(devLinksEnabled()).toBe(true); // dev convenience, no provider
    process.env.RESEND_API_KEY = KEY;
    expect(devLinksEnabled()).toBe(false); // provider exists → never disclose
    process.env.DEV_SHOW_EMAIL_LINKS = "false";
    delete process.env.RESEND_API_KEY;
    expect(devLinksEnabled()).toBe(false); // explicitly disabled
  });

  test("7. email templates embed the correct action links", () => {
    process.env.APP_URL = "https://botdock.example.com";
    const v = verificationEmail("Ada", "tok-verify");
    expect(v.subject).toContain("Verify");
    expect(v.text).toContain("https://botdock.example.com/api/auth/verify-email?token=tok-verify");
    const p = passwordResetEmail("Ada", "tok-reset");
    expect(p.text).toContain("https://botdock.example.com/#/reset-password?token=tok-reset");
    delete process.env.APP_URL;
  });
});
