#!/usr/bin/env bash
# Wrangler-dev (workerd) route-resolution matrix — proves which routes resolve
# in the SAME runtime Cloudflare Workers uses. Self-contained: launches the
# worker, polls readiness, runs the matrix, cleans up.
set -u
cd /home/z/my-project

PORT=8787
BASE="http://127.0.0.1:$PORT"
LOG=/tmp/wrangler-dev-test.log
: > "$LOG"

# Local preview loads the project .env (production Workers do NOT — they use
# dashboard vars/secrets). MATRIX_NO_APP_URL=1 temporarily strips APP_URL to
# exercise the request-origin fallback in the OAuth callback.
ENVBAK=/tmp/env.bak.$$
if [ "${MATRIX_NO_APP_URL:-0}" = "1" ] && [ -f .env ]; then
  cp .env "$ENVBAK"
  rg -v '^APP_URL=' .env > /tmp/env.noappurl && mv /tmp/env.noappurl .env
  echo "(matrix mode: APP_URL stripped from .env for this run)"
fi
restore_env() {
  [ -f "$ENVBAK" ] && mv "$ENVBAK" .env
  kill -- -"$WPID" 2>/dev/null; pkill -f "wrangler dev --port $PORT" 2>/dev/null
}

# Launch detached (survives reaping within this call)
setsid bunx wrangler dev --port "$PORT" >"$LOG" 2>&1 &
WPID=$!
trap restore_env EXIT

echo "waiting for worker readiness..."
READY=0
for i in $(seq 1 90); do
  if curl -s -o /dev/null -w "" "$BASE/api/health" 2>/dev/null; then
    code=$(curl -s -o /dev/null -w "%{http_code}" "$BASE/api/health" || true)
    [ "$code" != "000" ] && [ -n "$code" ] && READY=1 && break
  fi
  sleep 1
done
if [ "$READY" != "1" ]; then
  echo "WORKER DID NOT BECOME READY — last log lines:"
  tail -30 "$LOG"
  exit 2
fi
echo "worker ready after ${i}s"

probe() { # name, path, curl args...
  local name="$1" path="$2"; shift 2
  local out
  out=$(curl -sS -o /tmp/body.out -D /tmp/hdr.out "$@" "$BASE$path" 2>&1)
  local code
  code=$(head -1 /tmp/hdr.out | tr -d '\r' | awk '{print $2}')
  local loc
  loc=$(rg -i '^location:' /tmp/hdr.out | head -1 | tr -d '\r' | cut -d' ' -f2-)
  echo "── $name → $path"
  echo "   status: ${code:-none}${loc:+   location: $loc}"
  head -c 400 /tmp/body.out | tr '\n' ' ' | sed 's/  */ /g'
  echo ""
}

probe "GET /"                     "/"
probe "GET /login"                "/login"
probe "GET /register"             "/register"
probe "GET /pricing"              "/pricing"
probe "GET /api"                  "/api"
probe "GET /api/health"           "/api/health"
probe "GET /api/auth/config"      "/api/auth/config"
probe "GET /api/auth/me"          "/api/auth/me"
probe "GET /api/auth/oauth/google"          "/api/auth/oauth/google"
probe "GET /api/auth/oauth/google/callback" "/api/auth/oauth/google/callback"
probe "POST /api/auth/register"   "/api/auth/register" -X POST -H 'content-type: application/json' -d '{"email":"probe@example.com","password":"Probe12345!","name":"Probe"}'
probe "POST /api/auth/login"      "/api/auth/login"    -X POST -H 'content-type: application/json' -d '{"email":"probe@example.com","password":"Probe12345!"}'
probe "GET /nonexistent-page"     "/nonexistent-page"

echo ""
echo "── ASSERTIONS (regression gates)"
PASS=0; FAILCT=0
passc() { echo "   ✔ $1"; PASS=$((PASS+1)); }
failc() { echo "   ✘ $1"; FAILCT=$((FAILCT+1)); }
# Quote-safe helpers — NO eval (JSON bodies break eval re-parsing).
assert_has()    { local n="$1" b="$2" p="$3"; if printf '%s' "$b" | grep -qF -- "$p"; then passc "$n"; else failc "$n"; fi; }
assert_lacks()  { local n="$1" b="$2" p="$3"; if printf '%s' "$b" | grep -qF -- "$p"; then failc "$n"; else passc "$n"; fi; }
assert_regex()  { local n="$1" b="$2" p="$3"; if printf '%s' "$b" | grep -qE -- "$p"; then passc "$n"; else failc "$n"; fi; }
assert_prefix() { local n="$1" v="$2" p="$3"; case "$v" in "$p"*) passc "$n";; *) failc "$n (got: $v)";; esac; }

# A1: /login resolves as a 307 redirect to the hash view
code=$(curl -sS -o /dev/null -w "%{http_code}" "$BASE/login")
[ "$code" = "307" ] && passc "A1 /login → 307" || failc "A1 /login → 307 (got $code)"

# A2: callback without state bounces to the CONFIGURED APP_URL when set,
#     else the request's own origin (never some hardcoded third host).
#     Regression guard for the redirectBase fix in the callback route.
# NOTE: .env values may be quoted ("http://…" or http://…) depending on the
# operator — normalize like dotenv does before comparing (the app itself uses
# Next's dotenv parser, which strips quotes; this harness must match that).
APP_URL_CFG=$(rg -o '^APP_URL="?([^"#]*)"?\s*(#.*)?$' -r '$1' .env 2>/dev/null | head -1 | tr -d '"' || true)
loc=$(curl -sS -o /dev/null -w "%{redirect_url}" "$BASE/api/auth/oauth/google/callback")
if [ -n "$APP_URL_CFG" ]; then
  assert_prefix "A2 callback → configured APP_URL bounce" "$loc" "$APP_URL_CFG"
else
  # Fallback invariant: the bounce targets the host the user is actually on
  # (the worker's own origin — workerd may normalize 127.0.0.1 → localhost),
  # NEVER the old hardcoded http://localhost:3000 default.
  case "$loc" in
    http://localhost:3000*) failc "A2 callback → same-origin fallback bounce (STILL hardcoded localhost:3000: $loc)";;
    *":$PORT/"*) passc "A2 callback → same-origin fallback bounce ($loc)";;
    *) failc "A2 callback → same-origin fallback bounce (unexpected host: $loc)";;
  esac
fi
assert_has "A3 callback carries oauth_missing_params" "$loc" "error=oauth_missing_params"

# A4: unconfigured OAuth provider = honest 501 (NOT a fake success)
body=$(curl -sS "$BASE/api/auth/oauth/google")
assert_has "A4 oauth start → oauth_not_configured 501" "$body" "oauth_not_configured"

# A5/A6: unreachable DB in workerd (file: SQLite impossible) = honest
#     503 database_unavailable JSON. NOTE register validates input (zod)
#     BEFORE touching the DB, so A6 must send a fully valid payload.
body=$(curl -sS -X POST -H 'content-type: application/json' -d '{"email":"a@b.co","password":"x"}' "$BASE/api/auth/login")
assert_has "A5 /api/auth/login → database_unavailable 503" "$body" "database_unavailable"
body=$(curl -sS -X POST -H 'content-type: application/json' -d '{"email":"probe@example.com","password":"Probe12345!","name":"Probe"}' "$BASE/api/auth/register")
assert_has "A6 /api/auth/register → database_unavailable 503" "$body" "database_unavailable"

# A7-A10: per-component independence in the health report — a down database
#     must not leak into other components' statuses, and nothing may claim
#     health it did not actually probe.
body=$(curl -sS "$BASE/api/health")
assert_has  "A7 health: database=unreachable (live probe, workerd cannot open file: SQLite)" "$body" '"database":{"status":"unreachable"'
assert_lacks "A8 health: app NOT unreachable just because DB is (independent)" "$body" '"app":{"status":"unreachable"'
assert_lacks "A9 health: auth NOT healthy while DB is down (no fake health)" "$body" '"auth":{"status":"healthy"'
assert_has  "A10 health: email honestly unconfigured without a provider" "$body" '"email":{"status":"unconfigured"'
assert_regex "A11 health: runtime probed live (healthy OR unreachable, never inferred)" "$body" '"runtime":\{"status":"(healthy|unreachable)"'
assert_lacks "A12 health: no secret values in payload" "$body" "$(rg -o '^APP_SECRET=(.*)$' -r '$1' .env 2>/dev/null | head -1)"

echo ""
echo "ASSERTIONS: $PASS passed, $FAILCT failed"
if [ "$FAILCT" -gt 0 ]; then exit 3; fi

echo ""
echo "── static frontend served by the Worker (public/ → .open-next/assets)"
for p in /index.html /assets/css/style.css /assets/js/api.js /404.html; do
  code=$(curl -sS -o /dev/null -w "%{http_code}" "$BASE$p")
  echo "   $p → $code"
done
LAND=$(curl -sS "$BASE/index.html" || true)
case "$LAND" in
  *"BotDock Cloud"*) echo "   /index.html contains the site shell ✓" ;;
  *) echo "   WARNING: /index.html did not contain expected markup" ;;
esac

echo ""
echo "── wrangler log tail (errors only)"
rg -i "error|exception|fail" "$LOG" | grep -v "GET\|POST\|200\|304" | head -10 || echo "(no errors in log)"
restore_env
trap - EXIT
exit 0
