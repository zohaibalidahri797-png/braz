# BotDock Cloud

A professional cloud hosting platform for Telegram bots and automation apps — Python, Node.js and Bun runtimes, isolated processes, real logs and metrics, and an honest free tier.

## What is in this repository

| Component | Path | What it does |
|---|---|---|
| Web application | `src/` (Next.js 16 App Router) | Landing page, auth (email/password + Google/GitHub OAuth), dashboard, bot manager, file manager, notifications, admin panel, broadcasts |
| Bot runtime service | `mini-services/bot-runtime/` (Bun) | Executes user bots as isolated processes (rlimits + sanitized env + process groups), captures logs, samples real CPU/RSS from `/proc`, owns ALL bot file storage (workspaces, archive extraction, staging) |
| Database schema | `prisma/schema.prisma` | Users, sessions, OAuth accounts, verification tokens, bots, deployments, plans, subscriptions, payments, usage, notifications, broadcasts, audit log, settings |
| Docs | `docs/` | Setup, deployment (Cloudflare), bot-runtime deployment, architecture |
| Release packaging | `scripts/package-release.sh` | Builds `botdock-cloud.zip` and `botdock-cloud.tar.gz` with validation |

## Quick start (development) — step by step

Requirements: **Bun 1.1+** ([bun.sh](https://bun.sh)), **Python 3.10+** on PATH (for Python bots), **Node 20+** (for Node bots), and a `tar` binary (present on Linux/macOS).

```bash
# 1. Install dependencies
bun install

# 2. Create your config
cp .env.example .env
```

3. Open `.env` in an editor. At minimum, set the two generated secrets:

```bash
# generate a value for each, e.g.:  openssl rand -hex 32
APP_SECRET="<paste generated value>"
RUNTIME_API_KEY="<paste a different generated value>"
```

Leave everything else at defaults for local development. The important variables:

| Variable | Meaning |
|---|---|
| `DATABASE_URL` | SQLite file for development (`file:./db/custom.db`); Turso/libSQL in production |
| `APP_SECRET` | Signs session JWTs, encrypts env vars & GitHub tokens at rest — **keep it stable**, changing it invalidates sessions and encrypted values |
| `APP_URL` | Public base URL (OAuth callbacks + email links). Local default `http://localhost:3000` |
| `RUNTIME_API_KEY` | Shared secret between web app and bot runtime — must match on both sides |
| `GOOGLE_CLIENT_ID` / `GOOGLE_CLIENT_SECRET` | optional — enables "Sign in with Google" (see `docs/SETUP.md`) |
| `RESEND_API_KEY` | optional — enables real verification/password-reset emails (see `docs/SETUP.md`) |

```bash
# 4. Create the database
bun run db:push

# 5. Start the web app (port 3000)
bun run dev
```

The bot runtime service **auto-starts** on `127.0.0.1:3030` (a supervisor inside the web app spawns and monitors it). To run it standalone instead:

```bash
cd mini-services/bot-runtime
RUNTIME_API_KEY="<same value as .env>" RUNTIME_DATA_DIR=../../bot-data bun run dev
```

6. Open `http://localhost:3000`, register an account — **the first account automatically becomes an administrator** (in production you must set `ADMIN_BOOTSTRAP_TOKEN` instead; see `docs/SETUP.md`).

## What works out of the box (no external accounts needed)

- Email + password registration, login, logout, session management
- Create bots from templates, **upload archives (`.zip`, `.tar`, `.tar.gz`, `.tgz` ≤ 20MB)**, full file manager (list/edit/upload/download/delete)
- Deploy → dependency install (pip / bun) → start, with real logs, memory/CPU metrics, crash detection, start/stop/restart
- Admin panel, notifications, broadcasts (in-app), audit log
- Honest 501 errors for unconfigured integrations (Google/GitHub OAuth, email) that name the exact missing environment variables

What needs external configuration: Google sign-in, real outgoing email (Resend), GitHub repository import (user-supplied PAT), Stripe billing (dormant by default). Step-by-step instructions for each are in `docs/SETUP.md`.

## Running your first bot

1. Sign in → **New bot** → pick the *Python keep-alive* template → **Create**.
2. Open the bot → **Deploy**. The workspace is staged, dependencies install, the process starts.
3. Watch the **Logs** tab — heartbeat lines appear live. **Files** tab to browse/edit; **Env vars** tab to add secrets (encrypted at rest).
4. **Stop / Restart / Start** control the process; delete removes everything including stored files.

To host your own Telegram bot: upload a `.zip` of your project (with `requirements.txt` for Python or `package.json` for Node) and deploy. A Telegram bot token goes in the bot's **Env vars** (`TELEGRAM_BOT_TOKEN=...`), never in code. Example `main.py`:

```python
import os, time, telebot  # requirements.txt: pyTelegramBotAPI
bot = telebot.TeleBot(os.environ["TELEGRAM_BOT_TOKEN"])

@bot.message_handler(commands=["start"])
def start(m): bot.reply_to(m, "Hello from BotDock Cloud!")

bot.infinity_polling()
```

## Development scripts

| Command | What it does |
|---|---|
| `bun run dev` | web app on :3000 (runtime auto-spawns on :3030) |
| `bun run lint` | ESLint |
| `bunx tsc --noEmit` | TypeScript check |
| `bun test tests/` | unit tests |
| `bun run build` / `bun start` | production build / serve (Node host) |
| `bun run cf:build` / `cf:preview` / `cf:deploy` | Cloudflare Workers build / preview / deploy (OpenNext) |
| `bun run db:push` / `db:migrate:deploy` | schema push / production migrations |

## Feature map

- **Accounts**: email+password with bcrypt, email verification (Resend or honest "not configured" mode), password reset, Google & GitHub OAuth (state-validated, verified-email-only linking), session list with revocation, brute-force rate limits.
- **Bots**: create from templates / archives / GitHub, deploy (dependency install → build → start), start/stop/restart, live logs (runtime + build), file manager with editor, encrypted env vars, deployment history, real memory/CPU/uptime from `/proc`.
- **Free-first**: every user gets the free plan; no checkout, no payment walls. Resource policy is a finite system-wide per-bot limit (memory/CPU/disk via ulimits), not a product quota.
- **Admin**: user management (verify/suspend/promote), plan editor, platform settings, broadcast composer with per-recipient delivery tracking, platform-wide deployments, audit log.
- **Security**: httpOnly JWT-wrapped DB-backed sessions, origin checks on mutations, zod validation everywhere, path-traversal & zip-slip & zip-bomb & symlink protection, secret encryption at rest (AES-256-GCM), audit logging with redaction, shared-secret runtime API.

## Documentation

- `docs/SETUP.md` — environment variables, OAuth (exact callback URLs), email, Telegram, payments
- `docs/DEPLOYMENT.md` — Cloudflare Workers deployment (OpenNext) + production database
- `docs/RUNTIME-DEPLOYMENT.md` — deploying the bot runtime service (the part that actually runs bots) + full endpoint list
- `docs/ARCHITECTURE.md` — components, data flow, security model, known limits

## Deploying from GitHub with Cloudflare Workers Builds

This repository is a **full-stack Next.js app** — deploy it as a Cloudflare
**Worker** (OpenNext), never as a static/Pages site. If you connect the repo
in the Cloudflare dashboard, set **exactly**:

| Setting | Value |
|---|---|
| Root directory | `/` (repo root) |
| Build command | `npm install --no-audit --no-fund && npx prisma generate && npx opennextjs-cloudflare build && node scripts/cf-clean.mjs` |
| Deploy command | `node scripts/cf-verify.mjs && npx opennextjs-cloudflare deploy` |

A deploy command alone (`npx wrangler deploy` with no build command) fails by
design: fresh clones contain neither `node_modules` nor the OpenNext build
output (`.open-next/` is never committed), and without `wrangler.jsonc` at the
deploy root wrangler reports `Could not detect a directory containing static
files`. Verify `wrangler.jsonc` and `open-next.config.ts` are present at the
TOP level of your GitHub repo, then apply the settings above. Full walkthrough
(including the database and secrets): `docs/DEPLOYMENT.md`; failure
diagnosis: `docs/DEPLOYMENT.md` §8 and `FIX-REPORT.md`.

## Honest limitations (disclosed up front)

- Development uses SQLite and the runtime runs as a supervised child of the web app (`RUNTIME_EMBEDDED=true`). Production swaps SQLite for a managed database and runs the runtime as its own service/VM — see the docs.
- Without Docker, bot isolation is process-level (rlimits, env scrubbing, process groups) — good for development, **not** a container security boundary. Production runtimes should run bots in containers/VMs.
- Cloudflare Workers host the web app + control plane only; Workers **cannot** host persistent bot processes. The runtime service is a deliberate, documented separation (deploy it on any small Linux VM/host — free-tier options exist but a truly free 24/7 arbitrary-code runtime is not guaranteed by any provider; we do not pretend otherwise).
- GitHub auto-redeploy on push (webhooks) is not implemented; imports are on-demand via a user-supplied PAT.
