"use client";

/**
 * Global client state (Zustand): auth session, hash router, UI prefs.
 * Hash routing keeps the whole platform on the single `/` route this
 * environment exposes; routes look like #/bots/<id>?tab=files.
 */

import { create } from "zustand";
import { api, type Me } from "./api";

export interface Route {
  path: string; // e.g. "/bots/abc?tab=files" → path "/bots/abc", query {tab:files}
  segments: string[];
  query: Record<string, string>;
}

export function parseHash(): Route {
  const raw = window.location.hash.replace(/^#/, "") || "/";
  const [pathPart, queryPart] = raw.split("?");
  const segments = pathPart.split("/").filter(Boolean);
  const query: Record<string, string> = {};
  if (queryPart) {
    for (const [k, v] of new URLSearchParams(queryPart).entries()) query[k] = v;
  }
  return { path: "/" + segments.join("/"), segments, query };
}

export function navigate(to: string): void {
  window.location.hash = to.startsWith("#") ? to.slice(1) : to;
}

interface AppState {
  route: Route;
  me: Me | null;
  authChecked: boolean;
  refreshRoute: () => void;
  refreshMe: () => Promise<Me | null>;
  logout: () => Promise<void>;
  sidebarOpen: boolean;
  setSidebarOpen: (open: boolean) => void;
}

export const useApp = create<AppState>((set, get) => ({
  route: { path: "/", segments: [], query: {} },
  me: null,
  authChecked: false,
  sidebarOpen: false,
  refreshRoute: () => set({ route: parseHash() }),
  refreshMe: async () => {
    try {
      const me = await api<Me>("/api/auth/me");
      set({ me, authChecked: true });
      return me;
    } catch {
      set({ me: null, authChecked: true });
      return null;
    }
  },
  logout: async () => {
    await api("/api/auth/logout", { method: "POST" }).catch(() => undefined);
    set({ me: null });
    get().refreshRoute();
    navigate("/");
  },
  setSidebarOpen: (open) => set({ sidebarOpen: open }),
}));
