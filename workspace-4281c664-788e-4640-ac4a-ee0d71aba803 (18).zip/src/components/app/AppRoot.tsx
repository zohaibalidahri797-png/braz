"use client";

/**
 * AppRoot — the SPA router for the single `/` route. Maps hash routes to
 * views, bootstraps the session, and provides theme + query context.
 */

import { useEffect, useState } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { ThemeProvider } from "next-themes";
import { Loader2 } from "lucide-react";
import { useApp } from "./store";
import { Landing } from "./landing";
import { LoginView, RegisterView, ForgotPasswordView, ResetPasswordView, VerifyEmailView } from "./auth";
import { AppShell } from "./shell";
import { DashboardOverview, BotsList, BillingView, AccountSettings, SupportView } from "./dashboard";
import { BotDetail } from "./bot-detail";
import { AdminPanel } from "./admin";

function Router() {
  const { route, me, authChecked, refreshMe, refreshRoute } = useApp();

  useEffect(() => {
    refreshRoute();
    const onHash = () => refreshRoute();
    window.addEventListener("hashchange", onHash);
    return () => window.removeEventListener("hashchange", onHash);
  }, [refreshRoute, refreshMe]);

  useEffect(() => {
    void refreshMe();
  }, [refreshMe]);

  if (!authChecked) {
    return (
      <div className="grid min-h-screen place-items-center bg-background">
        <Loader2 className="h-6 w-6 animate-spin text-violet-400" />
      </div>
    );
  }

  const seg0 = route.segments[0] ?? "";
  const publicAuthRoutes = ["login", "register", "forgot-password", "reset-password", "verify"];

  // Public auth views (redirect to dashboard if already signed in)
  if (publicAuthRoutes.includes(seg0)) {
    if (me && (seg0 === "login" || seg0 === "register")) {
      return <RedirectTo hash="/dashboard" />;
    }
    if (seg0 === "login") return <LoginView />;
    if (seg0 === "register") return <RegisterView />;
    if (seg0 === "forgot-password") return <ForgotPasswordView />;
    if (seg0 === "verify") return <VerifyEmailView />;
    return <ResetPasswordView />;
  }

  // Landing for anonymous users
  if (!me) return <Landing />;

  // Authenticated area
  if (seg0 === "bots" && route.segments[1]) {
    return (
      <AppShell>
        <BotDetail botId={route.segments[1]} initialTab={route.query.tab} />
      </AppShell>
    );
  }

  let view = <DashboardOverview />;
  if (seg0 === "bots") view = <BotsList />;
  else if (seg0 === "billing") view = <BillingView />;
  else if (seg0 === "settings") view = <AccountSettings />;
  else if (seg0 === "support") view = <SupportView />;
  else if (seg0 === "admin") view = me.user.role === "ADMIN" ? <AdminPanel /> : <NotFound />;
  else if (seg0 !== "dashboard" && seg0 !== "") view = <NotFound />;

  return <AppShell>{view}</AppShell>;
}

function RedirectTo({ hash }: { hash: string }) {
  useEffect(() => {
    window.location.hash = hash;
  }, [hash]);
  return (
    <div className="grid min-h-screen place-items-center bg-background">
      <Loader2 className="h-6 w-6 animate-spin text-violet-400" />
    </div>
  );
}

function NotFound() {
  return (
    <div className="grid place-items-center py-24 text-center">
      <p className="text-4xl font-bold text-muted-foreground/40">404</p>
      <p className="mt-2 text-sm text-muted-foreground">This page does not exist.</p>
      <button className="mt-4 text-sm font-medium text-violet-300 hover:underline" onClick={() => (window.location.hash = "/dashboard")}>
        Back to dashboard
      </button>
    </div>
  );
}

export function AppRoot() {
  const [queryClient] = useState(
    () =>
      new QueryClient({
        defaultOptions: { queries: { retry: 1, refetchOnWindowFocus: false } },
      }),
  );

  return (
    <ThemeProvider attribute="class" defaultTheme="dark" enableSystem={false} disableTransitionOnChange>
      <QueryClientProvider client={queryClient}>
        <Router />
      </QueryClientProvider>
    </ThemeProvider>
  );
}
