"use client";

/**
 * Bot detail: live status card + tabbed manager (Files, Logs, Deployments,
 * Env vars, Settings). All data comes from the API which proxies the runtime
 * service; nothing here is simulated.
 */

import { useCallback, useEffect, useRef, useState } from "react";
import {
  ArrowLeft,
  Cog,
  File as FileIcon,
  FilePlus2,
  FolderPlus,
  History,
  KeyRound,
  Loader2,
  Play,
  RefreshCw,
  RotateCcw,
  Save,
  ScrollText,
  Square,
  Terminal,
  Trash2,
  Upload,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { api, errorMessage, formatBytes, formatUptime, timeAgo, type BotDetailResponse, type Deployment, type LogLine } from "./api";
import { navigate } from "./store";
import { ErrorNote, InfoNote, LoadingBlock, StatusBadge } from "./ui-bits";
import { cn } from "@/lib/utils";

interface FileEntry {
  path: string;
  type: "file" | "dir";
  size: number;
  modifiedAt: string;
}

export function BotDetail({ botId, initialTab }: { botId: string; initialTab?: string }) {
  const [data, setData] = useState<BotDetailResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busyAction, setBusyAction] = useState<string | null>(null);
  const [actionMsg, setActionMsg] = useState<{ kind: "ok" | "err" | "info"; text: string } | null>(null);
  const [tab, setTab] = useState(initialTab ?? "overview");

  const load = useCallback(() => {
    api<BotDetailResponse>(`/api/bots/${botId}`)
      .then(setData)
      .catch((e) => setError(errorMessage(e)));
  }, [botId]);

  useEffect(load, [load]);

  // Live status: poll adaptively so the status strip and process metrics stay
  // real without manual reloads — fast while building/deploying or running
  // (metrics change), slow for idle bots, and paused while the tab is hidden.
  const botStatus = data?.bot.status;
  const runtimeState = data?.runtime?.state;
  useEffect(() => {
    const busy = botStatus !== undefined && ["BUILDING", "DEPLOYING", "DELETING"].includes(botStatus);
    const running = runtimeState === "RUNNING";
    const intervalMs = busy ? 3000 : running ? 5000 : 15000;
    const tick = () => {
      if (document.visibilityState === "hidden") return; // no background churn
      load();
    };
    const id = setInterval(tick, intervalMs);
    const onVisible = () => {
      if (document.visibilityState === "visible") load();
    };
    document.addEventListener("visibilitychange", onVisible);
    return () => {
      clearInterval(id);
      document.removeEventListener("visibilitychange", onVisible);
    };
  }, [load, botStatus, runtimeState]);

  const doAction = async (action: "deploy" | "start" | "stop" | "restart") => {
    setBusyAction(action);
    setActionMsg(null);
    try {
      const res = await api<{ ok?: boolean; error?: string; detail?: string; number?: number }>(`/api/bots/${botId}/action`, { method: "POST", json: { action } });
      if (res.ok) {
        setActionMsg({ kind: "ok", text: `${action} succeeded.` });
      } else if (res.error === "email_verification_required" || res.error === "runtime_unavailable") {
        setActionMsg({ kind: "err", text: res.detail ?? res.error });
      } else {
        setActionMsg({ kind: "info", text: `${action} failed: ${res.detail ?? res.error ?? "unknown error"} — check the logs tab.` });
      }
    } catch (e) {
      const err = e as { detail?: string; error?: string; code?: string };
      if (err.code && err.code !== "http_500") {
        setActionMsg({ kind: "info", text: `${action} failed: ${err.detail ?? err.error} — check the logs tab.` });
      } else {
        setActionMsg({ kind: "err", text: errorMessage(e) });
      }
    } finally {
      setBusyAction(null);
      load();
    }
  };

  const deleteBot = async () => {
    await api(`/api/bots/${botId}`, { method: "DELETE" }).catch((e) => {
      setActionMsg({ kind: "err", text: errorMessage(e) });
      return null;
    });
    navigate("/bots");
  };

  if (error) {
    return (
      <div className="space-y-4">
        <Button variant="ghost" onClick={() => navigate("/bots")}><ArrowLeft className="mr-2 h-4 w-4" /> Back to bots</Button>
        <ErrorNote message={error} />
      </div>
    );
  }
  if (!data) return <LoadingBlock rows={4} />;

  const { bot, runtime } = data;
  const isBusy = ["BUILDING", "DEPLOYING", "DELETING"].includes(bot.status);
  const canStart = runtime?.state === "STOPPED" || runtime?.state === "FAILED" || (bot.currentDeploymentId && ["STOPPED", "FAILED", "CREATED"].includes(bot.status));

  return (
    <div className="space-y-6">
      <div>
        <Button variant="ghost" size="sm" onClick={() => navigate("/bots")} className="mb-2 -ml-2">
          <ArrowLeft className="mr-1.5 h-4 w-4" /> My bots
        </Button>
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h1 className="flex items-center gap-3 text-xl font-bold sm:text-2xl">
              {bot.name} <StatusBadge status={bot.status} pulse />
            </h1>
            <p className="mt-1 text-sm text-muted-foreground">
              {bot.runtime} · {bot.sourceType.toLowerCase() === "template" ? `template: ${bot.sourceRef}` : bot.sourceRef || bot.sourceType.toLowerCase()} · created {timeAgo(bot.createdAt)}
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button size="sm" onClick={() => doAction("deploy")} disabled={busyAction !== null || isBusy || !data.runtimeReachable}>
              {busyAction === "deploy" ? <Loader2 className="mr-1.5 h-4 w-4 animate-spin" /> : <Rocket2 />}
              Deploy
            </Button>
            <Button size="sm" variant="outline" onClick={() => doAction("start")} disabled={busyAction !== null || isBusy || !canStart || !data.runtimeReachable}>
              {busyAction === "start" ? <Loader2 className="mr-1.5 h-4 w-4 animate-spin" /> : <Play className="h-4 w-4" />}
              Start
            </Button>
            <Button size="sm" variant="outline" onClick={() => doAction("stop")} disabled={busyAction !== null || runtime?.state !== "RUNNING"}>
              {busyAction === "stop" ? <Loader2 className="mr-1.5 h-4 w-4 animate-spin" /> : <Square className="h-4 w-4" />}
              Stop
            </Button>
            <Button size="sm" variant="outline" onClick={() => doAction("restart")} disabled={busyAction !== null || runtime?.state !== "RUNNING"}>
              {busyAction === "restart" ? <Loader2 className="mr-1.5 h-4 w-4 animate-spin" /> : <RotateCcw className="h-4 w-4" />}
              Restart
            </Button>
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button size="sm" variant="destructive" disabled={isBusy} aria-label={`Delete bot ${bot.name}`} title="Delete bot"><Trash2 className="h-4 w-4" /></Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Delete “{bot.name}”?</AlertDialogTitle>
                  <AlertDialogDescription>
                    This stops the process, removes the deployed files and the workspace, and deletes all deployments and logs. This cannot be undone.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction className="bg-red-600 hover:bg-red-500" onClick={deleteBot}>Delete bot</AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        </div>
      </div>

      {actionMsg ? (
        actionMsg.kind === "ok" ? <InfoNote>{actionMsg.text}</InfoNote> : actionMsg.kind === "err" ? <ErrorNote message={actionMsg.text} /> : <InfoNote>{actionMsg.text}</InfoNote>
      ) : null}
      {!data.runtimeReachable ? <ErrorNote message="The bot runtime service is offline — deploy/start/stop are unavailable until it returns. The dashboard remains usable." /> : null}

      {/* Live status strip — real values from the runtime process metrics */}
      <Card>
        <CardContent className="grid grid-cols-2 gap-4 py-4 sm:grid-cols-3 lg:grid-cols-6">
          <LiveStat label="Process state" value={runtime?.state ?? (data.runtimeReachable ? "NOT_DEPLOYED" : "UNKNOWN")} />
          <LiveStat label="Memory" value={runtime ? (typeof runtime.memoryMb === "number" ? `${runtime.memoryMb} MB` : "unknown") : "—"} />
          <LiveStat label="CPU" value={runtime?.cpuPercent !== null && runtime?.cpuPercent !== undefined ? `${runtime.cpuPercent}%` : "—"} />
          <LiveStat label="Uptime" value={formatUptime(runtime?.uptimeSec ?? null)} />
          <LiveStat label="Restarts" value={String(runtime?.restarts ?? 0)} />
          <LiveStat label="Workspace" value={formatBytes(data.workspaceBytes)} />
        </CardContent>
      </Card>
      {runtime?.lastExitSignal ? (
        <p className="text-xs text-muted-foreground">
          Last exit: code {runtime.lastExitCode ?? "—"} {runtime.lastExitSignal ? `signal ${runtime.lastExitSignal}` : ""}
        </p>
      ) : null}

      <Tabs value={tab} onValueChange={setTab}>
        <TabsList className="flex-wrap">
          <TabsTrigger value="overview"><Cog className="mr-1.5 h-3.5 w-3.5" />Overview</TabsTrigger>
          <TabsTrigger value="files"><FileIcon className="mr-1.5 h-3.5 w-3.5" />Files</TabsTrigger>
          <TabsTrigger value="logs"><ScrollText className="mr-1.5 h-3.5 w-3.5" />Logs</TabsTrigger>
          <TabsTrigger value="deployments"><History className="mr-1.5 h-3.5 w-3.5" />Deployments</TabsTrigger>
          <TabsTrigger value="env"><KeyRound className="mr-1.5 h-3.5 w-3.5" />Env vars</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="mt-4"><OverviewTab data={data} onSaved={load} /></TabsContent>
        <TabsContent value="files" className="mt-4"><FilesTab botId={botId} /></TabsContent>
        <TabsContent value="logs" className="mt-4"><LogsTab botId={botId} deployments={data.deployments} /></TabsContent>
        <TabsContent value="deployments" className="mt-4"><DeploymentsTab botId={botId} deployments={data.deployments} /></TabsContent>
        <TabsContent value="env" className="mt-4"><EnvTab botId={botId} onChanged={load} /></TabsContent>
      </Tabs>
    </div>
  );
}

function Rocket2() {
  return <Play className="h-4 w-4 rotate-90" />;
}

function LiveStat({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <p className="text-[11px] font-medium uppercase tracking-wide text-muted-foreground">{label}</p>
      <p className="mt-0.5 font-mono text-sm font-semibold tabular-nums">{value}</p>
    </div>
  );
}

function OverviewTab({ data, onSaved }: { data: BotDetailResponse; onSaved: () => void }) {
  const [name, setName] = useState(data.bot.name);
  const [description, setDescription] = useState(data.bot.description);
  const [startCommand, setStartCommand] = useState(data.bot.startCommand);
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);

  const save = async () => {
    setSaving(true);
    setMsg(null);
    try {
      await api(`/api/bots/${data.bot.id}`, { method: "PATCH", json: { name, description, startCommand } });
      setMsg("Saved. Re-deploy to apply the new start command.");
      onSaved();
    } catch (e) {
      setMsg(errorMessage(e));
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <Card>
        <CardHeader className="pb-3"><CardTitle className="text-sm">Configuration</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          {msg ? <InfoNote>{msg}</InfoNote> : null}
          <div className="space-y-1.5">
            <Label htmlFor="cfg-name">Name</Label>
            <Input id="cfg-name" value={name} onChange={(e) => setName(e.target.value)} maxLength={50} />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="cfg-desc">Description</Label>
            <Input id="cfg-desc" value={description} onChange={(e) => setDescription(e.target.value)} maxLength={300} />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="cfg-cmd">Start command</Label>
            <Input id="cfg-cmd" className="font-mono text-xs" value={startCommand} onChange={(e) => setStartCommand(e.target.value)} placeholder="Auto-detected when empty" />
            <p className="text-xs text-muted-foreground">Detected order: Python main.py/bot.py · Node index.js/bot.js or package.json start · Bun main.ts or package.json start.</p>
          </div>
          <Button onClick={save} disabled={saving}>{saving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />} Save changes</Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-3"><CardTitle className="text-sm">Runtime snapshot</CardTitle></CardHeader>
        <CardContent className="space-y-2 font-mono text-xs">
          {data.runtime ? (
            <>
              <KV k="state" v={data.runtime.state} />
              <KV k="pid" v={String(data.runtime.pid ?? "—")} />
              <KV k="deployment" v={data.runtime.deploymentId ?? "—"} />
              <KV k="last exit code" v={String(data.runtime.lastExitCode ?? "—")} />
              <KV k="last exit signal" v={data.runtime.lastExitSignal ?? "—"} />
              <KV k="restarts" v={String(data.runtime.restarts)} />
              <KV k="runtime service" v={data.runtimeReachable ? "reachable" : `unreachable (${data.runtimeError})`} />
            </>
          ) : (
            <p className="text-muted-foreground">No live process data. Deploy the bot to create a runtime process.</p>
          )}
          <p className="pt-2 text-[11px] text-muted-foreground">
            Values are sampled from /proc on the runtime host every 5 seconds. Unknown values are shown as such — nothing is invented.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}

function KV({ k, v }: { k: string; v: string }) {
  return (
    <div className="flex justify-between gap-4 border-b border-border/40 pb-1.5 last:border-0">
      <span className="text-muted-foreground">{k}</span>
      <span className="truncate font-semibold">{v}</span>
    </div>
  );
}

// ── Files tab ───────────────────────────────────────────────────────────────

function FilesTab({ botId }: { botId: string }) {
  const [cwd, setCwd] = useState("");
  const [entries, setEntries] = useState<FileEntry[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState<{ path: string; content: string; binary?: boolean } | null>(null);
  const [saveBusy, setSaveBusy] = useState(false);
  const [newName, setNewName] = useState("");
  const [mkdirOpen, setMkdirOpen] = useState(false);
  const [uploading, setUploading] = useState(false);
  const uploadRef = useRef<HTMLInputElement>(null);

  const load = useCallback((dir: string) => {
    setLoading(true);
    setError(null);
    api<{ entries: FileEntry[] }>(`/api/bots/${botId}/files?path=${encodeURIComponent(dir)}`)
      .then((d) => setEntries(d.entries))
      .catch((e) => setError(errorMessage(e)))
      .finally(() => setLoading(false));
  }, [botId]);

  useEffect(() => { load(cwd); }, [cwd, load]);

  const openFile = async (path: string) => {
    setError(null);
    try {
      const d = await api<{ file: { path: string; content: string; binary: boolean; size: number } }>(`/api/bots/${botId}/files?path=${encodeURIComponent(path)}&read=1`);
      setEditing({ path, content: d.file.content, binary: d.file.binary });
    } catch (e) {
      setError(errorMessage(e));
    }
  };

  const saveFile = async () => {
    if (!editing) return;
    setSaveBusy(true);
    try {
      await api(`/api/bots/${botId}/files`, { method: "PUT", json: { path: editing.path, content: editing.content } });
      setEditing(null);
      load(cwd);
    } catch (e) {
      setError(errorMessage(e));
    } finally {
      setSaveBusy(false);
    }
  };

  const createDir = async () => {
    try {
      await api(`/api/bots/${botId}/files`, { method: "POST", json: { path: cwd ? `${cwd}/${newName}` : newName } });
      setMkdirOpen(false);
      setNewName("");
      load(cwd);
    } catch (e) {
      setError(errorMessage(e));
    }
  };

  const createFile = async () => {
    try {
      await api(`/api/bots/${botId}/files`, { method: "PUT", json: { path: cwd ? `${cwd}/${newName}` : newName, content: "" } });
      setMkdirOpen(false);
      setNewName("");
      load(cwd);
    } catch (e) {
      setError(errorMessage(e));
    }
  };

  const remove = async (path: string) => {
    try {
      await api(`/api/bots/${botId}/files?path=${encodeURIComponent(path)}`, { method: "DELETE" });
      load(cwd);
    } catch (e) {
      setError(errorMessage(e));
    }
  };

  const upload = async (file: File) => {
    setUploading(true);
    setError(null);
    try {
      const form = new FormData();
      form.set("file", file);
      form.set("path", cwd);
      await api(`/api/bots/${botId}/files/upload`, { method: "POST", body: form });
      load(cwd);
    } catch (e) {
      setError(errorMessage(e));
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2">
        <div className="flex flex-1 items-center gap-1 font-mono text-xs text-muted-foreground">
          <button className="hover:text-foreground" onClick={() => setCwd("")}>workspace</button>
          {cwd.split("/").filter(Boolean).map((seg, i, arr) => (
            <span key={i} className="flex items-center gap-1">
              / <button className="hover:text-foreground" onClick={() => setCwd(arr.slice(0, i + 1).join("/"))}>{seg}</button>
            </span>
          ))}
        </div>
        <Input ref={uploadRef} type="file" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) void upload(f); e.target.value = ""; }} />
        <Button size="sm" variant="outline" onClick={() => uploadRef.current?.click()} disabled={uploading}>
          {uploading ? <Loader2 className="mr-1.5 h-3.5 w-3.5 animate-spin" /> : <Upload className="h-3.5 w-3.5" />} Upload
        </Button>
        <Dialog open={mkdirOpen} onOpenChange={setMkdirOpen}>
          <DialogTrigger asChild>
            <Button size="sm" variant="outline"><FolderPlus className="h-3.5 w-3.5" /></Button>
          </DialogTrigger>
          <DialogContent className="max-w-sm">
            <DialogHeader>
              <DialogTitle>New file or folder</DialogTitle>
              <DialogDescription>Inside {cwd || "workspace root"}</DialogDescription>
            </DialogHeader>
            <Input value={newName} onChange={(e) => setNewName(e.target.value)} placeholder="main.py or utils/" />
            <div className="flex justify-end gap-2">
              <Button variant="outline" size="sm" onClick={createDir} disabled={!newName}><FolderPlus className="mr-1.5 h-3.5 w-3.5" />Folder</Button>
              <Button size="sm" onClick={createFile} disabled={!newName}><FilePlus2 className="mr-1.5 h-3.5 w-3.5" />File</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {error ? <ErrorNote message={error} /> : null}

      <div className="overflow-hidden rounded-xl border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Name</TableHead>
              <TableHead className="hidden sm:table-cell">Size</TableHead>
              <TableHead className="hidden md:table-cell">Modified</TableHead>
              <TableHead className="w-24 text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              <TableRow><TableCell colSpan={4} className="py-8 text-center text-sm text-muted-foreground"><Loader2 className="mx-auto h-4 w-4 animate-spin" /></TableCell></TableRow>
            ) : entries.length === 0 ? (
              <TableRow><TableCell colSpan={4} className="py-8 text-center text-sm text-muted-foreground">Empty directory</TableCell></TableRow>
            ) : (
              entries.map((e) => (
                <TableRow key={e.path}>
                  <TableCell>
                    <button
                      className="flex items-center gap-2 text-left font-mono text-xs hover:text-cyan-300"
                      onClick={() => (e.type === "dir" ? setCwd(e.path) : openFile(e.path))}
                    >
                      {e.type === "dir" ? <FolderPlus className="h-3.5 w-3.5 text-muted-foreground" /> : <FileIcon className="h-3.5 w-3.5 text-muted-foreground" />}
                      {e.path.split("/").pop()}
                    </button>
                  </TableCell>
                  <TableCell className="hidden text-xs tabular-nums text-muted-foreground sm:table-cell">{e.type === "file" ? formatBytes(e.size) : "—"}</TableCell>
                  <TableCell className="hidden text-xs text-muted-foreground md:table-cell">{timeAgo(e.modifiedAt)}</TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-1">
                      {e.type === "file" ? (
                        <>
                          <Button size="sm" variant="ghost" className="h-7 w-7 p-0" title="Edit" onClick={() => openFile(e.path)}><FileIcon className="h-3.5 w-3.5" /></Button>
                          <a href={`/api/bots/${botId}/files/download?path=${encodeURIComponent(e.path)}`} title="Download" className="inline-flex h-7 w-7 items-center justify-center rounded-md hover:bg-muted"><Download2 className="h-3.5 w-3.5" /></a>
                        </>
                      ) : null}
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button size="sm" variant="ghost" className="h-7 w-7 p-0 text-red-400" title="Delete"><Trash2 className="h-3.5 w-3.5" /></Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader><AlertDialogTitle>Delete {e.path.split("/").pop()}?</AlertDialogTitle>
                            <AlertDialogDescription>{e.type === "dir" ? "The folder and everything inside it will be removed." : "The file will be removed from the workspace."}</AlertDialogDescription></AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction className="bg-red-600 hover:bg-red-500" onClick={() => remove(e.path)}>Delete</AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

      <Dialog open={editing !== null} onOpenChange={(open) => !open && setEditing(null)}>
        <DialogContent className="max-h-[85vh] max-w-3xl overflow-hidden">
          <DialogHeader>
            <DialogTitle className="font-mono text-sm">{editing?.path}</DialogTitle>
            <DialogDescription>Edits apply to the workspace — redeploy to run them.</DialogDescription>
          </DialogHeader>
          {editing?.binary ? (
            <InfoNote>Binary file — use download/upload instead of the editor.</InfoNote>
          ) : (
            <TextareaEditor value={editing?.content ?? ""} onChange={(v) => setEditing((prev) => (prev ? { ...prev, content: v } : prev))} />
          )}
          {error ? <ErrorNote message={error} /> : null}
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setEditing(null)}>Cancel</Button>
            <Button onClick={saveFile} disabled={saveBusy || editing?.binary}>
              {saveBusy ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />} Save
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function Download2({ className }: { className?: string }) {
  return <FileIcon className={className} />;
}

function TextareaEditor({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  return (
    <ScrollArea className="h-[50vh] rounded-lg border">
      <textarea
        className="h-full min-h-[50vh] w-full resize-none bg-zinc-950 p-4 font-mono text-[12px] leading-6 text-zinc-200 outline-none"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        spellCheck={false}
        aria-label="File editor"
      />
    </ScrollArea>
  );
}

// ── Logs tab ────────────────────────────────────────────────────────────────

function LogsTab({ botId, deployments }: { botId: string; deployments: Deployment[] }) {
  const [lines, setLines] = useState<LogLine[]>([]);
  const [kind, setKind] = useState<"runtime" | "build">("runtime");
  const [buildId, setBuildId] = useState<string | null>(null);
  const [note, setNote] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const autoRef = useRef<HTMLDivElement>(null);

  const load = useCallback(() => {
    setLoading(true);
    const qs = kind === "build" && buildId ? `?build=${buildId}&tail=500` : "?tail=500";
    api<{ lines: LogLine[]; note?: string; runtimeUnavailable?: boolean }>(`/api/bots/${botId}/logs${qs}`)
      .then((d) => {
        setLines(d.lines);
        setNote(d.note ?? null);
      })
      .catch((e) => setError(errorMessage(e)))
      .finally(() => setLoading(false));
  }, [botId, kind, buildId]);

  useEffect(() => {
    const t = setTimeout(load, 0);
    return () => clearTimeout(t);
  }, [load]);
  useEffect(() => {
    const t = setInterval(() => { if (kind === "runtime") load(); }, 5000);
    return () => clearInterval(t);
  }, [kind, load]);

  useEffect(() => {
    autoRef.current?.scrollIntoView({ block: "end" });
  }, [lines]);

  const lastDeployment = deployments[0];

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center gap-2">
        <Tabs value={kind} onValueChange={(v) => { setKind(v as "runtime" | "build"); }}>
          <TabsList>
            <TabsTrigger value="runtime"><Terminal className="mr-1.5 h-3.5 w-3.5" />Runtime</TabsTrigger>
            <TabsTrigger value="build"><History className="mr-1.5 h-3.5 w-3.5" />Build</TabsTrigger>
          </TabsList>
        </Tabs>
        {kind === "build" && deployments.length > 0 ? (
          <select
            className="rounded-md border bg-background px-2 py-1.5 text-xs"
            value={buildId ?? lastDeployment?.id ?? ""}
            onChange={(e) => setBuildId(e.target.value)}
            aria-label="Deployment build log"
          >
            {deployments.slice(0, 10).map((d) => (
              <option key={d.id} value={d.id}>#{d.number} — {d.status}</option>
            ))}
          </select>
        ) : null}
        <Button size="sm" variant="ghost" onClick={load}><RefreshCw className="h-3.5 w-3.5" /></Button>
        {kind === "runtime" ? <Badge variant="outline" className="text-[10px]">auto-refresh 5s</Badge> : null}
      </div>

      {error ? <ErrorNote message={error} /> : null}
      {note ? <InfoNote>{note}</InfoNote> : null}

      <div className="overflow-hidden rounded-xl border border-zinc-800 bg-zinc-950">
        <ScrollArea className="h-[55vh]">
          <div ref={autoRef} className="p-4 font-mono text-[12px] leading-6">
            {loading && lines.length === 0 ? (
              <p className="text-zinc-500">loading…</p>
            ) : lines.length === 0 ? (
              <p className="text-zinc-500">No log lines yet. {kind === "runtime" ? "Deploy and start the bot to produce runtime logs." : "Pick a deployment to see its build log."}</p>
            ) : (
              lines.map((l, i) => (
                <div key={i} className={cn("whitespace-pre-wrap break-words",
                  l.stream === "err" ? "text-red-400" : l.stream === "system" ? "text-sky-400" : "text-zinc-300")}>
                  {l.ts ? <span className="mr-2 text-zinc-600">{new Date(l.ts).toLocaleTimeString()}</span> : null}
                  {l.text}
                </div>
              ))
            )}
          </div>
        </ScrollArea>
      </div>
    </div>
  );
}

// ── Deployments tab ─────────────────────────────────────────────────────────

function DeploymentsTab({ botId, deployments }: { botId: string; deployments: Deployment[] }) {
  return (
    <div className="overflow-hidden rounded-xl border">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>#</TableHead>
            <TableHead>Status</TableHead>
            <TableHead className="hidden sm:table-cell">Source</TableHead>
            <TableHead>Created</TableHead>
            <TableHead className="hidden lg:table-cell">Finished</TableHead>
            <TableHead>Error</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {deployments.length === 0 ? (
            <TableRow><TableCell colSpan={6} className="py-8 text-center text-sm text-muted-foreground">No deployments yet.</TableCell></TableRow>
          ) : (
            deployments.map((d) => (
              <TableRow key={d.id}>
                <TableCell className="font-mono text-xs">#{d.number}</TableCell>
                <TableCell><StatusBadge status={d.status} /></TableCell>
                <TableCell className="hidden text-xs text-muted-foreground sm:table-cell">{d.sourceType.toLowerCase()}{d.sourceRef ? ` · ${d.sourceRef}` : ""}</TableCell>
                <TableCell className="text-xs">{timeAgo(d.createdAt)}</TableCell>
                <TableCell className="hidden text-xs text-muted-foreground lg:table-cell">{d.finishedAt ? timeAgo(d.finishedAt) : "—"}</TableCell>
                <TableCell className="max-w-40 truncate text-xs text-red-400" title={d.error ?? undefined}>{d.error ?? "—"}</TableCell>
              </TableRow>
            ))
          )}
        </TableBody>
      </Table>
      <p className="border-t px-4 py-2 text-[11px] text-muted-foreground">
        Build logs for each deployment are on the Logs → Build tab. Bot: {botId}
      </p>
    </div>
  );
}

// ── Env vars tab ────────────────────────────────────────────────────────────

interface EnvRow {
  key: string;
  isSecret: boolean;
  preview: string;
  updatedAt: string;
}

function EnvTab({ botId, onChanged }: { botId: string; onChanged: () => void }) {
  const [vars, setVars] = useState<EnvRow[]>([]);
  const [note, setNote] = useState<string | null>(null);
  const [key, setKey] = useState("");
  const [value, setValue] = useState("");
  const [isSecret, setIsSecret] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(() => {
    api<{ vars: EnvRow[]; note: string }>(`/api/bots/${botId}/env`)
      .then((d) => {
        setVars(d.vars);
        setNote(d.note);
      })
      .catch((e) => setError(errorMessage(e)));
  }, [botId]);

  useEffect(load, [load]);

  const save = async () => {
    setBusy(true);
    setError(null);
    try {
      await api(`/api/bots/${botId}/env`, { method: "PUT", json: { key, value, isSecret } });
      setKey("");
      setValue("");
      load();
      onChanged();
    } catch (e) {
      setError(errorMessage(e));
    } finally {
      setBusy(false);
    }
  };

  const remove = async (k: string) => {
    await api(`/api/bots/${botId}/env?key=${encodeURIComponent(k)}`, { method: "DELETE" }).catch((e) => setError(errorMessage(e)));
    load();
  };

  return (
    <div className="space-y-4">
      {note ? <InfoNote>{note}</InfoNote> : null}
      {error ? <ErrorNote message={error} /> : null}

      <Card>
        <CardHeader className="pb-3"><CardTitle className="text-sm">Add / update a variable</CardTitle></CardHeader>
        <CardContent className="space-y-3">
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label htmlFor="env-key">Name</Label>
              <Input id="env-key" className="font-mono text-xs" value={key} onChange={(e) => setKey(e.target.value)} placeholder="BOT_TOKEN" />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="env-val">Value</Label>
              <Input id="env-val" className="font-mono text-xs" type="password" value={value} onChange={(e) => setValue(e.target.value)} placeholder="123456:ABC-DEF…" />
            </div>
          </div>
          <label className="flex items-center gap-2 text-xs text-muted-foreground">
            <input type="checkbox" checked={isSecret} onChange={(e) => setIsSecret(e.target.checked)} className="h-3.5 w-3.5 accent-violet-600" />
            Mark as secret (masked in the UI, encrypted at rest)
          </label>
          <Button onClick={save} disabled={busy || !/^[A-Za-z_][A-Za-z0-9_]*$/.test(key)} size="sm">
            {busy ? <Loader2 className="mr-2 h-3.5 w-3.5 animate-spin" /> : <KeyRound className="mr-2 h-3.5 w-3.5" />} Save variable
          </Button>
        </CardContent>
      </Card>

      <div className="overflow-hidden rounded-xl border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Name</TableHead>
              <TableHead>Value</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {vars.length === 0 ? (
              <TableRow><TableCell colSpan={3} className="py-6 text-center text-sm text-muted-foreground">No environment variables.</TableCell></TableRow>
            ) : (
              vars.map((v) => (
                <TableRow key={v.key}>
                  <TableCell className="font-mono text-xs font-medium">{v.key}</TableCell>
                  <TableCell className="text-xs text-muted-foreground">{v.isSecret ? "•••••••• (secret — write-only)" : v.preview}</TableCell>
                  <TableCell className="text-right">
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button size="sm" variant="ghost" className="h-7 w-7 p-0 text-red-400"><Trash2 className="h-3.5 w-3.5" /></Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>Delete {v.key}?</AlertDialogTitle>
                          <AlertDialogDescription>The variable is removed from future deployments. Running processes keep it until they restart.</AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Cancel</AlertDialogCancel>
                          <AlertDialogAction className="bg-red-600 hover:bg-red-500" onClick={() => remove(v.key)}>Delete</AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
