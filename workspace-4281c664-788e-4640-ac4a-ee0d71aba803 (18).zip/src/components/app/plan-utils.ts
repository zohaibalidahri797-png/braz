"use client";

/** Small helpers shared by landing/pricing/billing. */
export { api } from "./api";
export type { PublicPlan, PlanLimits } from "./api";

export function formatUsdLabel(cents: number): string {
  if (cents === 0) return "Free";
  return `$${(cents / 100).toFixed(cents % 100 === 0 ? 0 : 2)}`;
}
