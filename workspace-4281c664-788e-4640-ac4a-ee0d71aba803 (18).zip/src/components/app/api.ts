/**
 * Typed API client for the BotDock SPA. All requests are same-origin relative
 * fetches with cookies. Errors normalize to { status, error, detail }.
 */

export interface ApiError extends Error {
  status: number;
  code: string;
  detail?: string;
  data?: Record<string, unknown>;
}

export async function api<T = Record<string, unknown>>(
  path: string,
  init?: RequestInit & { json?: unknown },
): Promise<T> {
  const { json, ...rest } = init ?? {};
  const res = await fetch(path, {
    ...rest,
    headers: {
      ...(json !== undefined ? { "Content-Type": "application/json" } : {}),
      ...(rest.headers as Record<string, string> | undefined),
    } as HeadersInit,
    body: json !== undefined ? JSON.stringify(json) : rest.body,
    credentials: "same-origin",
    cache: "no-store",
  });

  let data: Record<string, unknown> = {};
  try {
    data = (await res.json()) as Record<string, unknown>;
  } catch {
    // non-JSON response
  }

  if (!res.ok) {
    const err = new Error(String(data.error ?? `http_${res.status}`)) as ApiError;
    err.status = res.status;
    err.code = String(data.error ?? `http_${res.status}`);
    err.detail = typeof data.detail === "string" ? data.detail : undefined;
    err.data = data;
    throw err;
  }
  return data as T;
}

export function errorMessage(err: unknown): string {
  if (err && typeof err === "object" && "detail" in err && typeof (err as ApiError).detail === "string") {
    return String((err as ApiError).detail);
  }
  if (err instanceof Error) {
    const pretty: Record<string, string> = {
      authentication_required: "Please sign in first.",
      admin_required: "Administrator access required.",
      runtime_unavailable: "The bot runtime service is offline.",
      invalid_credentials: "Incorrect email or password.",
    };
    return pretty[err.message] ?? err.message.replaceAll("_", " ");
  }
  return String(err);
}

// ── Shared types (mirror the API) ────────────────────────────────────────────

export interface PlanLimits {
  maxBots: number;
  memoryMbPerBot: number;
  cpuPercent: number;
  diskMbPerBot: number;
  storageTotalMb: number;
  deploymentsPerDay: number;
  logRetentionDays: number;
  runtimes: string[];
  allowedFeatures: { githubImport: boolean; fileEditor: boolean; envVars: boolean; prioritySupport: boolean };
}

export interface Me {
  user: { id: string; email: string; name: string | null; role: string; status: string; emailVerified: boolean; image: string | null };
  plan: { id: string; name: string; priceLabel: string; status: string; limits: PlanLimits };
  emailConfigured?: boolean;
  unreadNotifications: number;
}

export interface BotSummary {
  id: string;
  name: string;
  description: string;
  runtime: string;
  status: string;
  runtimeStatus: string | null;
  runtimeReachable: boolean;
  memoryMb: number | "unknown" | null;
  uptimeSec: number | null;
  sourceType: string;
  sourceRef: string;
  currentDeploymentId: string | null;
  lastDeployedAt: string | null;
  createdAt: string;
}

export interface BotsResponse {
  bots: BotSummary[];
  plan: { id: string; name: string; limits: PlanLimits };
  usage: { botsUsed: number };
  runtimeReachable: boolean;
  runtimeNote: string | null;
}

export interface RuntimeSnapshot {
  botId: string;
  state: string;
  pid: number | null;
  startedAt: number | null;
  uptimeSec: number | null;
  memoryMb: number | "unknown";
  cpuPercent: number | null;
  lastExitCode: number | null;
  lastExitSignal: string | null;
  restarts: number;
  deploymentId: string | null;
  runtime: string | null;
  startCommand: string;
}

export interface BotDetailResponse {
  bot: {
    id: string;
    name: string;
    description: string;
    runtime: string;
    status: string;
    startCommand: string;
    sourceType: string;
    sourceRef: string;
    currentDeploymentId: string | null;
    lastDeployedAt: string | null;
    lastStartedAt: string | null;
    createdAt: string;
    updatedAt: string;
  };
  deployments: Deployment[];
  runtime: RuntimeSnapshot | null;
  runtimeReachable: boolean;
  runtimeError: string | null;
  workspaceBytes: number;
  limits: PlanLimits;
}

export interface Deployment {
  id: string;
  number: number;
  status: string;
  sourceType: string;
  sourceRef: string;
  error: string | null;
  triggeredBy: string | null;
  createdAt: string;
  startedAt: string | null;
  finishedAt: string | null;
}

export interface LogLine {
  ts: number;
  stream: "out" | "err" | "system";
  text: string;
}

export interface PublicPlan {
  id: string;
  name: string;
  description: string;
  priceMonthly: number;
  priceYearly: number;
  isActive: boolean;
  features: string[];
  limits: PlanLimits;
}

export interface UsageResponse {
  botsTotal: number;
  botsRunning: number;
  botsStopped: number;
  botsFailed: number;
  statusCounts: Record<string, number>;
  plan: { planId: string; planName: string; status: string; billingCycle: string; provider: string; limits: PlanLimits; features: string[]; priceMonthly: number };
  deploymentsToday: number;
  storageBytes: number;
  /** System-wide per-bot resource policy (infrastructure, not a plan quota). */
  resourcePolicy: { memoryMbPerBot: number; cpuPercent: number; diskMbPerBot: number };
  capacityNote: string;
  bots: Array<{ id: string; name: string; status: string; runtime: string }>;
  recentDeployments: Array<{ id: string; botName: string; number: number; status: string; createdAt: string; finishedAt: string | null }>;
  recentNotifications: NotificationRow[];
  deployCount30d: number;
}

export interface NotificationRow {
  id: string;
  title: string;
  body: string;
  level: string;
  category: string;
  link: string | null;
  readAt: string | null;
  createdAt: string;
}

export function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  if (bytes < 1024 * 1024 * 1024) return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
  return `${(bytes / 1024 / 1024 / 1024).toFixed(2)} GB`;
}

export function timeAgo(iso: string | number | null | undefined): string {
  if (!iso) return "—";
  const t = typeof iso === "number" ? iso : new Date(iso).getTime();
  const diff = Date.now() - t;
  if (diff < 45_000) return "just now";
  const m = Math.floor(diff / 60_000);
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  const d = Math.floor(h / 24);
  if (d < 30) return `${d}d ago`;
  return new Date(t).toLocaleDateString();
}

export function formatUptime(sec: number | null | undefined): string {
  if (sec === null || sec === undefined) return "—";
  if (sec < 60) return `${sec}s`;
  const m = Math.floor(sec / 60);
  if (m < 60) return `${m}m ${sec % 60}s`;
  const h = Math.floor(m / 60);
  return `${h}h ${m % 60}m`;
}
