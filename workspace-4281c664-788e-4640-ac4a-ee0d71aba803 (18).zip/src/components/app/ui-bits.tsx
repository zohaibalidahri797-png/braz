"use client";

/** Shared UI bits: status badges, empty states, section headers, stat cards. */

import { cn } from "@/lib/utils";
import { Skeleton } from "@/components/ui/skeleton";
import type { AnchorHTMLAttributes, ReactNode } from "react";

const BOT_STATUS_STYLES: Record<string, string> = {
  RUNNING: "bg-emerald-500/15 text-emerald-400 border-emerald-500/30",
  STOPPED: "bg-zinc-500/15 text-zinc-400 border-zinc-500/30",
  CREATED: "bg-cyan-500/15 text-cyan-300 border-cyan-500/30",
  BUILDING: "bg-amber-500/15 text-amber-400 border-amber-500/30",
  DEPLOYING: "bg-violet-500/15 text-violet-300 border-violet-500/30",
  FAILED: "bg-red-500/15 text-red-400 border-red-500/30",
  DELETING: "bg-orange-500/15 text-orange-400 border-orange-500/30",
};

export function StatusBadge({ status, pulse }: { status: string; pulse?: boolean }) {
  const style = BOT_STATUS_STYLES[status] ?? "bg-zinc-500/15 text-zinc-400 border-zinc-500/30";
  return (
    <span className={cn("inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-xs font-medium", style)}>
      <span className={cn("h-1.5 w-1.5 rounded-full bg-current", pulse && status === "RUNNING" && "animate-pulse")} />
      {status}
    </span>
  );
}

export function RuntimeDot({ reachable }: { reachable: boolean }) {
  return (
    <span className={cn("inline-flex items-center gap-1.5 text-xs", reachable ? "text-cyan-300" : "text-red-400")}>
      <span className={cn("h-2 w-2 rounded-full", reachable ? "bg-cyan-400" : "bg-red-400")} />
      {reachable ? "Runtime online" : "Runtime offline"}
    </span>
  );
}

export function EmptyState({ icon, title, description, action }: { icon: ReactNode; title: string; description: string; action?: ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 rounded-xl border border-dashed border-border/60 bg-muted/20 px-6 py-14 text-center">
      <div className="rounded-full bg-muted p-3 text-muted-foreground">{icon}</div>
      <h3 className="text-base font-semibold">{title}</h3>
      <p className="max-w-md text-sm text-muted-foreground">{description}</p>
      {action}
    </div>
  );
}

export function PageHeader({ title, description, actions }: { title: ReactNode; description?: string; actions?: ReactNode }) {
  return (
    <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
      <div>
        <h1 className="text-xl font-bold tracking-tight sm:text-2xl">{title}</h1>
        {description ? <p className="mt-1 text-sm text-muted-foreground">{description}</p> : null}
      </div>
      {actions ? <div className="flex flex-wrap items-center gap-2">{actions}</div> : null}
    </div>
  );
}

export function StatCard({ label, value, sub, icon, tone }: { label: string; value: ReactNode; sub?: string; icon?: ReactNode; tone?: "default" | "success" | "warning" | "danger" }) {
  const toneRing =
    tone === "success"
      ? "ring-emerald-500/20"
      : tone === "warning"
        ? "ring-amber-500/20"
        : tone === "danger"
          ? "ring-red-500/20"
          : "ring-border";
  return (
    <div className={cn("rounded-xl border bg-card p-4 ring-1 ring-inset", toneRing)}>
      <div className="flex items-center justify-between gap-2">
        <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">{label}</p>
        {icon ? <span className="text-muted-foreground">{icon}</span> : null}
      </div>
      <p className="mt-2 text-2xl font-bold tabular-nums">{value}</p>
      {sub ? <p className="mt-1 text-xs text-muted-foreground">{sub}</p> : null}
    </div>
  );
}

export function LoadingBlock({ rows = 3 }: { rows?: number }) {
  return (
    <div className="space-y-3">
      {Array.from({ length: rows }).map((_, i) => (
        <Skeleton key={i} className="h-16 w-full rounded-xl" />
      ))}
    </div>
  );
}

export function ErrorNote({ message }: { message: string }) {
  return (
    <div className="rounded-lg border border-red-500/30 bg-red-500/10 px-4 py-3 text-sm text-red-400" role="alert">
      {message}
    </div>
  );
}

export function InfoNote({ children }: { children: ReactNode }) {
  return (
    <div className="rounded-lg border border-amber-500/30 bg-amber-500/10 px-4 py-3 text-sm text-amber-500" role="status">
      {children}
    </div>
  );
}

/**
 * HashLink — native anchor for in-app hash routes (e.g. #/register).
 *
 * Why not next/link? Next's <Link> intercepts hash-only clicks and performs a
 * History-API push (no `hashchange` event fires), so the SPA router in
 * AppRoot/store never learns the route changed — the URL updates but the view
 * silently stays on the old screen. A native anchor assigns location.hash,
 * which DOES fire `hashchange`, keeps middle-click/new-tab behavior, and
 * still receives an optional onClick (e.g. to close the mobile sidebar).
 */
export function HashLink({
  href,
  className,
  onClick,
  children,
  ...rest
}: {
  href: string;
  className?: string;
  onClick?: () => void;
  children: ReactNode;
} & Omit<AnchorHTMLAttributes<HTMLAnchorElement>, "href" | "onClick" | "children">) {
  return (
    <a href={href} className={className} onClick={onClick} {...rest}>
      {children}
    </a>
  );
}
