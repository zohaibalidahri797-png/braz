/**
 * Notifications: GET list (+unread count), POST mark read { ids?|all? }.
 */
import { ok, fail, requireUser, originCheck, readJson } from "@/lib/api";
import { db } from "@/lib/db";

export async function GET(req: Request) {
  const auth = await requireUser();
  if ("response" in auth) return auth.response;
  const url = new URL(req.url);
  const unreadOnly = url.searchParams.get("unread") === "1";
  const limit = Math.min(Number(url.searchParams.get("limit") ?? "50") || 50, 100);

  const [notifications, unread] = await Promise.all([
    db.notification.findMany({
      where: { userId: auth.user.id, ...(unreadOnly ? { readAt: null } : {}) },
      orderBy: { createdAt: "desc" },
      take: limit,
    }),
    db.notification.count({ where: { userId: auth.user.id, readAt: null } }),
  ]);
  return ok({ notifications, unread });
}

export async function POST(req: Request) {
  const csrf = originCheck(req);
  if (csrf) return csrf;
  const auth = await requireUser();
  if ("response" in auth) return auth.response;
  const body = await readJson<{ ids?: string[]; all?: boolean }>(req);
  if (body?.all) {
    await db.notification.updateMany({ where: { userId: auth.user.id, readAt: null }, data: { readAt: new Date() } });
    return ok({ ok: true });
  }
  if (Array.isArray(body?.ids) && body.ids.length > 0) {
    await db.notification.updateMany({
      where: { userId: auth.user.id, id: { in: body.ids.slice(0, 100) } },
      data: { readAt: new Date() },
    });
    return ok({ ok: true });
  }
  return fail(400, "nothing_to_mark");
}
