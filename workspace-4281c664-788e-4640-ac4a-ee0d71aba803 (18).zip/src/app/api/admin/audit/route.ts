/** GET /api/admin/audit — audit log with filters (admin only). */
import { ok, requireAdmin } from "@/lib/api";
import { db } from "@/lib/db";

export async function GET(req: Request) {
  const auth = await requireAdmin();
  if ("response" in auth) return auth.response;
  const url = new URL(req.url);
  const action = url.searchParams.get("action");
  const page = Math.max(1, Number(url.searchParams.get("page") ?? "1") || 1);
  const pageSize = 50;

  const where = action ? { action: { contains: action } } : {};
  const [total, logs] = await Promise.all([
    db.auditLog.count({ where }),
    db.auditLog.findMany({
      where,
      orderBy: { createdAt: "desc" },
      skip: (page - 1) * pageSize,
      take: pageSize,
    }),
  ]);
  return ok({ logs, total, page, pageSize, pages: Math.ceil(total / pageSize) });
}
