/**
 * Admin plan management: GET all plans (incl. non-public), PUT updates.
 * Limits are stored as JSON validated by planLimitsSchema.
 */
import { ok, fail, requireAdmin, originCheck, reqCtx, readJson } from "@/lib/api";
import { db } from "@/lib/db";
import { planUpdateSchema, zodErrorMessage } from "@/lib/validation";
import { audit } from "@/lib/audit";

export async function GET() {
  const auth = await requireAdmin();
  if ("response" in auth) return auth.response;
  const plans = await db.plan.findMany({ orderBy: { sortOrder: "asc" } });
  const subscriberCounts = await db.subscription.groupBy({ by: ["planId"], _count: { _all: true } });
  const counts = Object.fromEntries(subscriberCounts.map((s) => [s.planId, s._count._all]));
  return ok({
    plans: plans.map((p) => ({ ...p, limits: JSON.parse(p.limits || "{}"), features: JSON.parse(p.features || "[]"), subscribers: counts[p.id] ?? 0 })),
  });
}

export async function PUT(req: Request) {
  const csrf = originCheck(req);
  if (csrf) return csrf;
  const auth = await requireAdmin();
  if ("response" in auth) return auth.response;
  const { ip, userAgent } = reqCtx(req);

  const body = await readJson<Record<string, unknown>>(req);
  const parsed = planUpdateSchema.safeParse(body ?? {});
  if (!parsed.success) return fail(400, zodErrorMessage(parsed.error));
  const { id, limits, features, ...rest } = parsed.data;

  const existing = await db.plan.findUnique({ where: { id } });
  if (!existing) return fail(404, "plan_not_found");

  const updated = await db.plan.update({
    where: { id },
    data: {
      ...rest,
      ...(limits !== undefined ? { limits: JSON.stringify(limits) } : {}),
      ...(features !== undefined ? { features: JSON.stringify(features) } : {}),
    },
  });

  await audit({ actorId: auth.user.id, actorEmail: auth.user.email, action: "PLAN_UPDATE", targetType: "plan", targetId: id, detail: { changes: rest, limitsChanged: limits !== undefined }, ip, userAgent });
  return ok({ ok: true, plan: { ...updated, limits: JSON.parse(updated.limits), features: JSON.parse(updated.features) } });
}
