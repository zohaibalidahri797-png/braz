/**
 * Admin subscription management (MANUAL mode plan application).
 * POST { userId, planId } — sets the subscription directly. Audited.
 */
import { ok, fail, requireAdmin, originCheck, reqCtx, readJson } from "@/lib/api";
import { db } from "@/lib/db";
import { audit } from "@/lib/audit";
import { notify } from "@/lib/notify";
import { z } from "zod";

const schema = z.object({
  userId: z.string().trim().min(1).max(64),
  planId: z.string().trim().min(1).max(40),
});

export async function POST(req: Request) {
  const csrf = originCheck(req);
  if (csrf) return csrf;
  const auth = await requireAdmin();
  if ("response" in auth) return auth.response;
  const { ip, userAgent } = reqCtx(req);

  const body = await readJson<Record<string, unknown>>(req);
  const parsed = schema.safeParse(body ?? {});
  if (!parsed.success) return fail(400, "invalid_request", { detail: "userId and planId are required." });

  const [user, plan] = await Promise.all([
    db.user.findUnique({ where: { id: parsed.data.userId } }),
    db.plan.findUnique({ where: { id: parsed.data.planId } }),
  ]);
  if (!user) return fail(404, "user_not_found");
  if (!plan || !plan.isActive) return fail(404, "plan_not_found");

  await db.subscription.upsert({
    where: { userId: user.id },
    update: { planId: plan.id, status: "ACTIVE", provider: "MANUAL", billingCycle: plan.priceMonthly === 0 ? "NONE" : "MONTHLY", currentPeriodStart: new Date() },
    create: { userId: user.id, planId: plan.id, provider: "MANUAL" },
  });

  await audit({ actorId: auth.user.id, actorEmail: auth.user.email, action: "ADMIN_PLAN_APPLIED", targetType: "subscription", targetId: user.id, detail: { planId: plan.id }, ip, userAgent });
  await notify(user.id, {
    title: "Plan updated",
    body: `An administrator moved your account to the ${plan.name} plan.`,
    level: "SUCCESS",
    category: "BILLING",
  });

  return ok({ ok: true });
}
