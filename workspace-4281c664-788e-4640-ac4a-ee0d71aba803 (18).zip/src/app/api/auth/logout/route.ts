import { ok, originCheck, reqCtx } from "@/lib/api";
import { revokeCurrentSession, getSessionUser } from "@/lib/session";
import { audit } from "@/lib/audit";

export async function POST(req: Request) {
  const csrf = originCheck(req);
  if (csrf) return csrf;
  const user = await getSessionUser();
  await revokeCurrentSession();
  if (user) {
    const { ip, userAgent } = reqCtx(req);
    await audit({ actorId: user.id, actorEmail: user.email, action: "USER_LOGOUT", detail: {}, ip, userAgent });
  }
  return ok({ ok: true });
}
