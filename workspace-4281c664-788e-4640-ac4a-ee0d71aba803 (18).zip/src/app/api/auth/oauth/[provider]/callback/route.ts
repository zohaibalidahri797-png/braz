/**
 * OAuth 2.0 callback: GET /api/auth/oauth/{google|github}/callback
 *
 * Security policy implemented here:
 *  1. state cookie must match the query param (CSRF defense)
 *  2. code exchanged server-side (client secret never leaves the server)
 *  3. identity fetched and email verified status validated
 *  4. account linking ONLY when the provider reports the email as verified
 *     (Google: email_verified claim; GitHub: verified emails endpoint).
 *     Accounts registered with a password are NOT auto-linked on unverified
 *     emails — the user is told to sign in and link from settings.
 */
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { reqCtx } from "@/lib/api";
import { audit } from "@/lib/audit";
import { createSession } from "@/lib/session";
import { ensureSeed } from "@/lib/seed";

const OAUTH_COOKIE = "bd_oauth_state";

/**
 * Canonical app URL (used for the OAuth token-exchange redirect_uri, which
 * MUST match the authorize request and the provider-console allowlist).
 */
function appUrl(): string {
  return (process.env.APP_URL ?? "http://localhost:3000").replace(/\/$/, "");
}

/**
 * Base URL for USER-FACING redirects. Prefers the configured APP_URL; when it
 * is unset (a common first-deploy misconfiguration) it falls back to the host
 * the user is actually browsing, so an error bounce never strands them on
 * http://localhost:3000. Safe: these redirects carry only an error code —
 * never tokens or secrets — and provider allowlisting still governs the real
 * OAuth exchange, which always uses appUrl().
 */
function redirectBase(req: Request): string {
  const configured = process.env.APP_URL?.trim();
  if (configured) return configured.replace(/\/$/, "");
  try {
    return new URL(req.url).origin;
  } catch {
    return appUrl();
  }
}

function errorRedirect(req: Request, code: string, detail?: string): NextResponse {
  const params = new URLSearchParams({ error: code });
  if (detail) params.set("detail", detail.slice(0, 300));
  const res = NextResponse.redirect(`${redirectBase(req)}/#/login?${params.toString()}`, { status: 302 });
  res.cookies.delete(OAUTH_COOKIE);
  return res;
}

interface OAuthIdentity {
  providerAccountId: string;
  email: string;
  emailVerified: boolean;
  name: string | null;
  image: string | null;
}

async function googleIdentity(code: string, redirectUri: string): Promise<OAuthIdentity> {
  const tokenRes = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      code,
      client_id: process.env.GOOGLE_CLIENT_ID!,
      client_secret: process.env.GOOGLE_CLIENT_SECRET!,
      redirect_uri: redirectUri,
      grant_type: "authorization_code",
    }),
  });
  const token = (await tokenRes.json().catch(() => ({}))) as { access_token?: string; error?: string };
  if (!tokenRes.ok || !token.access_token) {
    throw new Error(`token_exchange_failed: ${token.error ?? tokenRes.status}`);
  }
  const infoRes = await fetch("https://openidconnect.googleapis.com/v1/userinfo", {
    headers: { Authorization: `Bearer ${token.access_token}` },
  });
  if (!infoRes.ok) throw new Error("userinfo_failed");
  const info = (await infoRes.json()) as {
    sub?: string;
    email?: string;
    email_verified?: boolean;
    name?: string;
    picture?: string;
  };
  if (!info.sub || !info.email) throw new Error("userinfo_missing_fields");
  return {
    providerAccountId: info.sub,
    email: info.email.toLowerCase(),
    emailVerified: info.email_verified === true,
    name: info.name ?? null,
    image: info.picture ?? null,
  };
}

async function githubIdentity(code: string): Promise<OAuthIdentity> {
  const tokenRes = await fetch("https://github.com/login/oauth/access_token", {
    method: "POST",
    headers: { "Content-Type": "application/json", Accept: "application/json" },
    body: JSON.stringify({
      code,
      client_id: process.env.GITHUB_CLIENT_ID!,
      client_secret: process.env.GITHUB_CLIENT_SECRET!,
    }),
  });
  const token = (await tokenRes.json().catch(() => ({}))) as { access_token?: string; error?: string };
  if (!tokenRes.ok || !token.access_token) {
    throw new Error(`token_exchange_failed: ${token.error ?? tokenRes.status}`);
  }
  const headers = { Authorization: `Bearer ${token.access_token}`, "User-Agent": "botdock-cloud", Accept: "application/vnd.github+json" };
  const userRes = await fetch("https://api.github.com/user", { headers });
  if (!userRes.ok) throw new Error("userinfo_failed");
  const user = (await userRes.json()) as { id?: number; login?: string; name?: string; avatar_url?: string; email?: string | null };

  // GitHub's /user email can be null — resolve the primary VERIFIED email.
  const emailsRes = await fetch("https://api.github.com/user/emails", { headers });
  let email: string | null = user.email ?? null;
  let emailVerified = false;
  if (emailsRes.ok) {
    const emails = (await emailsRes.json()) as { email: string; primary: boolean; verified: boolean }[];
    const primary = emails.find((e) => e.primary && e.verified) ?? emails.find((e) => e.verified);
    if (primary) {
      email = primary.email.toLowerCase();
      emailVerified = true;
    }
  }
  if (!user.id || !email) throw new Error("userinfo_missing_fields");
  return {
    providerAccountId: String(user.id),
    email,
    emailVerified,
    name: user.name ?? user.login ?? null,
    image: user.avatar_url ?? null,
  };
}

export async function GET(req: Request, { params }: { params: Promise<{ provider: string }> }) {
  const { provider } = await params;
  const { ip, userAgent } = reqCtx(req);
  const url = new URL(req.url);
  const code = url.searchParams.get("code");
  const state = url.searchParams.get("state");
  const oauthError = url.searchParams.get("error");

  if (provider !== "google" && provider !== "github") return errorRedirect(req, "unknown_provider");

  if (oauthError) return errorRedirect(req, "oauth_provider_error", oauthError);
  if (!code || !state) return errorRedirect(req, "oauth_missing_params");

  // 1. state validation
  const cookieState = req.headers
    .get("cookie")
    ?.split(";")
    .map((c) => c.trim())
    .find((c) => c.startsWith(`${OAUTH_COOKIE}=`))
    ?.split("=")
    .slice(1)
    .join("=");
  if (!cookieState || cookieState !== `${provider}:${state}`) {
    return errorRedirect(req, "oauth_state_mismatch", "The sign-in flow could not be verified (state mismatch). Start again.");
  }

  try {
    const redirectUri = `${appUrl()}/api/auth/oauth/${provider}/callback`;
    const identity =
      provider === "google" ? await googleIdentity(code, redirectUri) : await githubIdentity(code);

    // 2. existing link?
    const existingAccount = await db.oAuthAccount.findUnique({
      where: { provider_providerAccountId: { provider, providerAccountId: identity.providerAccountId } },
      include: { user: true },
    });

    if (existingAccount) {
      if (existingAccount.user.status === "BANNED" || existingAccount.user.status === "SUSPENDED") {
        return errorRedirect(req, "account_blocked", "This account is suspended or banned.");
      }
      await createSession({ userId: existingAccount.user.id, ip, userAgent });
      await audit({ actorId: existingAccount.user.id, actorEmail: identity.email, action: "OAUTH_LOGIN", detail: { provider }, ip, userAgent });
      const res = NextResponse.redirect(`${redirectBase(req)}/#/dashboard`, { status: 302 });
      res.cookies.delete(OAUTH_COOKIE);
      return res;
    }

    // 3. same email?
    const emailUser = await db.user.findUnique({ where: { email: identity.email } });
    if (emailUser) {
      if (!identity.emailVerified) {
        return errorRedirect(
          req,
          "oauth_email_unverified",
          `Your ${provider} email is not verified by the provider, so BotDock will not link it automatically. Sign in with your password, then connect ${provider} from Settings.`,
        );
      }
      // Verified email match → safe automatic link (provider attests ownership).
      await db.$transaction([
        db.oAuthAccount.create({ data: { userId: emailUser.id, provider, providerAccountId: identity.providerAccountId } }),
        ...(emailUser.emailVerified ? [] : [db.user.update({ where: { id: emailUser.id }, data: { emailVerified: new Date(), image: emailUser.image ?? identity.image } })]),
      ]);
      await audit({ actorId: emailUser.id, actorEmail: identity.email, action: "OAUTH_LINKED", detail: { provider }, ip, userAgent });
      await createSession({ userId: emailUser.id, ip, userAgent });
      const res = NextResponse.redirect(`${redirectBase(req)}/#/dashboard`, { status: 302 });
      res.cookies.delete(OAUTH_COOKIE);
      return res;
    }

    // 4. brand-new user
    await ensureSeed().catch(() => undefined);
    const user = await db.user.create({
      data: {
        email: identity.email,
        name: identity.name ?? identity.email.split("@")[0]!,
        image: identity.image,
        emailVerified: identity.emailVerified ? new Date() : null,
      },
    });
    await db.oAuthAccount.create({ data: { userId: user.id, provider, providerAccountId: identity.providerAccountId } });
    await db.subscription.create({ data: { userId: user.id, planId: "free", provider: "NONE" } }).catch(() => undefined);
    await audit({ actorId: user.id, actorEmail: identity.email, action: "USER_REGISTER_OAUTH", detail: { provider }, ip, userAgent });
    await createSession({ userId: user.id, ip, userAgent });
    const res = NextResponse.redirect(`${redirectBase(req)}/#/dashboard`, { status: 302 });
    res.cookies.delete(OAUTH_COOKIE);
    return res;
  } catch (err) {
    const detail = err instanceof Error ? err.message : String(err);
    await audit({ action: "OAUTH_FAILED", detail: { provider, reason: detail.slice(0, 200) }, ip, userAgent }).catch(() => undefined);
    return errorRedirect(req, "oauth_failed", detail);
  }
}
