import { db } from "@/lib/db";
import { ok, fail, reqCtx } from "@/lib/api";
import { sha256Hex } from "@/lib/crypto";
import { audit } from "@/lib/audit";
import { notify } from "@/lib/notify";

/**
 * GET /api/auth/verify-email?token=...
 * The link arrives by email (or via the dev-link disclosure). Consumes the
 * token exactly once and marks the user's email verified.
 */
export async function GET(req: Request) {
  const url = new URL(req.url);
  const token = url.searchParams.get("token") ?? "";
  const { ip, userAgent } = reqCtx(req);

  if (token.length < 32 || !/^[a-f0-9]+$/.test(token)) {
    return fail(400, "invalid_token", { detail: "This verification link is malformed." });
  }

  const row = await db.verificationToken.findUnique({ where: { tokenHash: sha256Hex(token) } });
  if (!row || row.type !== "EMAIL_VERIFY" || row.usedAt || row.expiresAt.getTime() < Date.now()) {
    return fail(400, "invalid_or_expired_token", { detail: "This verification link is invalid, already used, or expired. Request a new email from your dashboard." });
  }

  const user = await db.user.findUnique({ where: { email: row.email } });
  if (!user) return fail(400, "user_not_found", { detail: "The account for this link no longer exists." });

  await db.$transaction([
    db.verificationToken.update({ where: { id: row.id }, data: { usedAt: new Date() } }),
    db.user.update({ where: { id: user.id }, data: { emailVerified: new Date() } }),
  ]);

  await audit({ actorId: user.id, actorEmail: user.email, action: "EMAIL_VERIFIED", detail: {}, ip, userAgent });
  await notify(user.id, {
    title: "Email verified",
    body: "Your email address is verified. You can now deploy bots.",
    level: "SUCCESS",
    category: "SECURITY",
  });

  // HTML-friendly response for users arriving from their mail client.
  return new Response(
    `<!doctype html><html><head><meta charset="utf-8"><meta http-equiv="refresh" content="2;url=/#/dashboard"><title>Email verified</title></head><body style="font-family:system-ui;display:grid;place-items:center;min-height:100vh;margin:0;background:#0b1120;color:#e2e8f0"><div style="text-align:center"><h1 style="font-size:1.5rem">✅ Email verified</h1><p>Your BotDock Cloud account is now verified. Redirecting to your dashboard…</p><a href="/#/dashboard" style="color:#7dd3fc">Continue</a></div></body></html>`,
    { status: 200, headers: { "content-type": "text/html; charset=utf-8" } },
  );
}
