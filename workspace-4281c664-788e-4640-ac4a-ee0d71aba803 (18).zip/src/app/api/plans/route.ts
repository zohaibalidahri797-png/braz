/** GET /api/plans — public plan catalog with limits and prices. */
import { ok } from "@/lib/api";
import { db } from "@/lib/db";
import { ensureSeed } from "@/lib/seed";
import { parseLimits } from "@/lib/plans";
import { monetizationEnabled, FREE_LAUNCH_NOTE } from "@/lib/monetization";

export async function GET() {
  await ensureSeed().catch(() => undefined);
  const paid = monetizationEnabled();
  // Free-first launch: only zero-cost plans are public. Paid plan rows (if any
  // exist from before) stay in the DB for admins but are NOT offered to users.
  const plans = await db.plan.findMany({
    where: paid ? { isPublic: true } : { isPublic: true, priceMonthly: 0, priceYearly: 0 },
    orderBy: { sortOrder: "asc" },
  });
  return ok({
    plans: plans.map((p) => ({
      id: p.id,
      name: p.name,
      description: p.description,
      priceMonthly: p.priceMonthly,
      priceYearly: p.priceYearly,
      isActive: p.isActive,
      features: safeFeatures(p.features),
      limits: parseLimits(p.limits),
    })),
    paymentProvider: paid ? (process.env.STRIPE_SECRET_KEY ? "stripe" : "manual") : "none",
    freeOnly: !paid,
    note: paid
      ? process.env.STRIPE_SECRET_KEY
        ? null
        : "Online payments are not configured on this deployment. Plan changes are reviewed and applied by administrators (MANUAL mode)."
      : FREE_LAUNCH_NOTE,
  });
}

function safeFeatures(json: string): string[] {
  try {
    const v = JSON.parse(json);
    return Array.isArray(v) ? v.filter((x): x is string => typeof x === "string") : [];
  } catch {
    return [];
  }
}
