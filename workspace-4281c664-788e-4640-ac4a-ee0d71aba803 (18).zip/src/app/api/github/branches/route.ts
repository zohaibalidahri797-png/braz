/** GET /api/github/branches?repo=owner/name — branch list for a repo. */
import { ok, fail, requireUser } from "@/lib/api";
import { listBranches, latestCommit } from "@/lib/github";

export async function GET(req: Request) {
  const auth = await requireUser();
  if ("response" in auth) return auth.response;
  const repo = new URL(req.url).searchParams.get("repo") ?? "";
  try {
    const branches = await listBranches(auth.user.id, repo);
    const head = await latestCommit(auth.user.id, repo, branches[0] ?? "main");
    return ok({ branches, head: head ?? null });
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    if (msg === "no_github_token") return fail(400, "no_github_token");
    if (msg === "invalid_repo") return fail(400, "invalid_repo", { detail: "Repository must look like owner/name." });
    if (msg.startsWith("github_error_404")) return fail(404, "repo_not_found", { detail: "Repository not found (or the token has no access to it)." });
    return fail(502, "github_error", { detail: msg });
  }
}
