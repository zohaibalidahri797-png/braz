/**
 * POST /api/github/import { name, repo, branch, runtime, description?, startCommand? }
 * Creates a bot and imports the repository tarball into its workspace.
 * Requires a stored GitHub personal access token (Settings → GitHub).
 */
import { ok, fail, requireUser, originCheck, reqCtx, readJson } from "@/lib/api";
import { db } from "@/lib/db";
import { checkBotSafety } from "@/lib/plans";
import { downloadRepoTarball, latestCommit } from "@/lib/github";
import { uploadToWorkspace, FileOpError, RuntimeOfflineError } from "@/lib/bot-fs";
import { audit } from "@/lib/audit";
import { z } from "zod";
import { BOT_RUNTIMES } from "@/lib/validation";

const schema = z.object({
  name: z.string().trim().min(1).max(50).regex(/^[a-zA-Z0-9 _-]+$/),
  repo: z.string().trim().min(3).max(140),
  branch: z.string().trim().min(1).max(200),
  runtime: z.enum(BOT_RUNTIMES),
  description: z.string().trim().max(300).optional(),
  startCommand: z.string().trim().max(500).optional(),
});

export async function POST(req: Request) {
  const csrf = originCheck(req);
  if (csrf) return csrf;
  const auth = await requireUser();
  if ("response" in auth) return auth.response;
  const { ip, userAgent } = reqCtx(req);

  // GitHub import is available to everyone; the real gate is a stored token
  // (Settings → GitHub) — checked naturally when the repo is fetched.
  const safety = await checkBotSafety(auth.user.id);
  if (!safety.ok) return fail(403, safety.reason!, { detail: safety.detail });

  const body = await readJson<Record<string, unknown>>(req);
  const parsed = schema.safeParse(body ?? {});
  if (!parsed.success) return fail(400, "invalid_request", { detail: "name, repo, branch and runtime are required." });
  const input = parsed.data;

  const commit = await latestCommit(auth.user.id, input.repo, input.branch).catch(() => null);

  const bot = await db.bot.create({
    data: {
      userId: auth.user.id,
      name: input.name,
      description: input.description ?? `Imported from ${input.repo}@${input.branch}`,
      runtime: input.runtime,
      startCommand: input.startCommand ?? "",
      sourceType: "GITHUB",
      sourceRef: `${input.repo}@${input.branch}`,
      status: "CREATED",
    },
  });

  try {
    const tarball = await downloadRepoTarball(auth.user.id, input.repo, input.branch);
    // The runtime service extracts the tarball (zip-slip/symlink protection).
    const result = await uploadToWorkspace(bot.id, `${input.repo.replace("/", "-")}-${input.branch}.tar.gz`, tarball, "");
    await audit({ actorId: auth.user.id, actorEmail: auth.user.email, action: "BOT_CREATE_GITHUB", targetType: "bot", targetId: bot.id, detail: { repo: input.repo, branch: input.branch, sha: commit?.sha ?? null, files: result.kind === "archive" ? result.files : 1 }, ip, userAgent });
    return ok({ ok: true, bot: { id: bot.id, name: bot.name }, commit, extracted: result.kind === "archive" ? { files: result.files, bytes: result.bytes } : { files: 1, bytes: result.bytes } }, { status: 201 });
  } catch (err) {
    await db.bot.delete({ where: { id: bot.id } }).catch(() => undefined);
    const msg = err instanceof Error ? err.message : String(err);
    if (msg === "no_github_token") return fail(400, "no_github_token", { detail: "Add a GitHub token first (Settings → GitHub)." });
    if (msg.startsWith("github_error_404")) return fail(404, "repo_or_branch_not_found", { detail: "Repository or branch not found (or the token lacks access)." });
    if (err instanceof RuntimeOfflineError) return fail(503, "runtime_unavailable", { detail: "The bot runtime service is not reachable, so imports cannot be stored right now." });
    if (err instanceof FileOpError) return fail(400, "unsafe_archive", { detail: err.message });
    return fail(502, "import_failed", { detail: msg });
  }
}
