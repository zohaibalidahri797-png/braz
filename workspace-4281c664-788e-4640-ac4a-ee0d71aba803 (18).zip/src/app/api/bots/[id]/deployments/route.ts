/** GET /api/bots/:id/deployments — deployment history. */
import { ok, fail, requireUser } from "@/lib/api";
import { db } from "@/lib/db";

export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireUser();
  if ("response" in auth) return auth.response;
  const { id } = await params;
  if (!/^[a-zA-Z0-9_-]{1,64}$/.test(id)) return fail(400, "invalid_id");

  const bot = await db.bot.findUnique({ where: { id } });
  if (!bot || (bot.userId !== auth.user.id && auth.user.role !== "ADMIN")) return fail(404, "bot_not_found");

  const deployments = await db.deployment.findMany({
    where: { botId: id },
    orderBy: { number: "desc" },
    take: 30,
  });
  return ok({ deployments });
}
