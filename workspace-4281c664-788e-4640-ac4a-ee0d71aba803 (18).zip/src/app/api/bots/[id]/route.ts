import { db } from "@/lib/db";
import { ok, fail, requireUser, originCheck, reqCtx, readJson } from "@/lib/api";
import { botUpdateSchema, zodErrorMessage } from "@/lib/validation";
import { botWithRuntimeStatus, deleteBot } from "@/lib/bot-lifecycle";
import { audit } from "@/lib/audit";

/** GET /api/bots/:id — bot detail with live runtime status. */
export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireUser();
  if ("response" in auth) return auth.response;
  const { id } = await params;
  if (!/^[a-zA-Z0-9_-]{1,64}$/.test(id)) return fail(400, "invalid_id");

  const data = await botWithRuntimeStatus(id, auth.user.id, auth.user.role === "ADMIN");
  if (!data) return fail(404, "bot_not_found");
  return ok(data);
}

/** PATCH /api/bots/:id — update configuration. */
export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const csrf = originCheck(req);
  if (csrf) return csrf;
  const auth = await requireUser();
  if ("response" in auth) return auth.response;
  const { id } = await params;
  if (!/^[a-zA-Z0-9_-]{1,64}$/.test(id)) return fail(400, "invalid_id");
  const { ip, userAgent } = reqCtx(req);

  const bot = await db.bot.findUnique({ where: { id } });
  if (!bot || (bot.userId !== auth.user.id && auth.user.role !== "ADMIN")) return fail(404, "bot_not_found");

  const body = await readJson<Record<string, unknown>>(req);
  const parsed = botUpdateSchema.safeParse(body ?? {});
  if (!parsed.success) return fail(400, zodErrorMessage(parsed.error));

  const { name, description, runtime, startCommand } = parsed.data;
  const updated = await db.bot.update({
    where: { id },
    data: {
      ...(name !== undefined ? { name } : {}),
      ...(description !== undefined ? { description } : {}),
      ...(runtime !== undefined ? { runtime } : {}),
      ...(startCommand !== undefined ? { startCommand } : {}),
    },
  });

  await audit({ actorId: auth.user.id, actorEmail: auth.user.email, action: "BOT_UPDATE", targetType: "bot", targetId: id, detail: { name, description, runtime, startCommand }, ip, userAgent });
  return ok({ ok: true, bot: { id: updated.id, name: updated.name, runtime: updated.runtime, startCommand: updated.startCommand, description: updated.description } });
}

/** DELETE /api/bots/:id — full teardown (stop + undeploy + delete). */
export async function DELETE(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const csrf = originCheck(req);
  if (csrf) return csrf;
  const auth = await requireUser();
  if ("response" in auth) return auth.response;
  const { id } = await params;
  if (!/^[a-zA-Z0-9_-]{1,64}$/.test(id)) return fail(400, "invalid_id");
  const { ip, userAgent } = reqCtx(req);

  const result = await deleteBot(id, { actorId: auth.user.id, actorEmail: auth.user.email, ip, userAgent });
  if (!result.ok) return fail(result.status, result.error!, { detail: result.detail });
  return ok(result.data ?? { deleted: true });
}
