/**
 * Contract alias — POST /api/bots/:id/start
 * Canonical endpoint: POST /api/bots/:id/action { action: "start" }.
 * Same authorization, CSRF check, validation and audit trail.
 */
import { fail, originCheck, reqCtx, requireUser } from "@/lib/api";
import { startBot } from "@/lib/bot-lifecycle";

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const csrf = originCheck(req);
  if (csrf) return csrf;
  const auth = await requireUser();
  if ("response" in auth) return auth.response;
  const { id } = await params;
  if (!/^[a-zA-Z0-9_-]{1,64}$/.test(id)) return fail(400, "invalid_id");
  const { ip, userAgent } = reqCtx(req);
  const result = await startBot(id, { actorId: auth.user.id, actorEmail: auth.user.email, ip, userAgent });
  if (!result.ok) {
    return Response.json({ ok: false, error: result.error, detail: result.detail, ...(result.data ?? {}) }, { status: result.status });
  }
  return Response.json({ ok: true, ...(result.data ?? {}) }, { status: result.status });
}
