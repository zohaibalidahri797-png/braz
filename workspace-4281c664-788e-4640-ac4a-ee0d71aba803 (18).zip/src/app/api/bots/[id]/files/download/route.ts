/** GET /api/bots/:id/files/download?path=... — download a workspace file (proxied from the runtime). */
import { requireUser, fail } from "@/lib/api";
import { db } from "@/lib/db";
import { downloadFile, FileOpError, RuntimeOfflineError } from "@/lib/bot-fs";

export async function GET(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireUser();
  if ("response" in auth) return auth.response;
  const { id } = await params;
  if (!/^[a-zA-Z0-9_-]{1,64}$/.test(id)) return fail(400, "invalid_id");

  const bot = await db.bot.findUnique({ where: { id } });
  if (!bot || (bot.userId !== auth.user.id && auth.user.role !== "ADMIN")) return fail(404, "bot_not_found");

  const url = new URL(req.url);
  const relPath = url.searchParams.get("path") ?? "";
  if (!relPath) return fail(400, "path_required");

  try {
    const { data, filename } = await downloadFile(id, relPath);
    return new Response(data, {
      headers: {
        "content-type": "application/octet-stream",
        "content-disposition": `attachment; filename="${filename.replace(/[^\w.\-]/g, "_")}"`,
        "cache-control": "no-store",
      },
    });
  } catch (err) {
    if (err instanceof RuntimeOfflineError) {
      return fail(503, "runtime_unavailable", { detail: "The bot runtime service is not reachable." });
    }
    const msg = err instanceof FileOpError ? err.message : "download_failed";
    return fail(400, "download_failed", { detail: msg });
  }
}
