/**
 * POST /api/bots/upload — create a bot from an uploaded project archive.
 *
 * Multipart form fields:
 *   name         required, bot name
 *   runtime      required, PYTHON | NODE | BUN
 *   description  optional
 *   startCommand optional (auto-detected at deploy when empty)
 *   file         required, .zip / .tar / .tar.gz / .tgz (≤ 20MB)
 *
 * The archive is forwarded to the botdock-runtime service, which extracts it
 * with full zip-slip / symlink / bomb protection. On failure the bot row is
 * removed again — a half-created bot is never left behind.
 */
import { ok, fail, requireUser, originCheck, reqCtx } from "@/lib/api";
import { db } from "@/lib/db";
import { botCreateSchema, zodErrorMessage } from "@/lib/validation";
import { checkBotSafety, getEffectivePlan } from "@/lib/plans";
import { uploadToWorkspace, FileOpError, RuntimeOfflineError, MAX_ARCHIVE_BYTES } from "@/lib/bot-fs";
import { audit } from "@/lib/audit";
import { rateLimit } from "@/lib/rate-limit";
import { z } from "zod";

const MAX_REQUEST_BYTES = MAX_ARCHIVE_BYTES + 1024 * 1024; // archive + multipart overhead

const uploadSchema = botCreateSchema.omit({ sourceType: true, templateId: true });

export async function POST(req: Request) {
  const csrf = originCheck(req);
  if (csrf) return csrf;
  const auth = await requireUser();
  if ("response" in auth) return auth.response;
  const { ip, userAgent } = reqCtx(req);

  // Burst guard: uploads are heavier than JSON creates (extraction work).
  const rl = await rateLimit(`bot-upload:${auth.user.id}`, 20, 3600);
  if (!rl.ok) {
    return fail(429, "too_many_uploads", {
      detail: `Too many archive uploads from this account — try again in about ${Math.ceil(rl.retryAfterSec / 60)} minute(s).`,
    });
  }

  // Reject oversized bodies before buffering when the client declared the size.
  const declared = Number(req.headers.get("content-length") ?? "0");
  if (declared > MAX_REQUEST_BYTES) {
    return fail(413, "archive_too_large", { detail: "Archive exceeds the 20MB limit." });
  }

  let form: FormData;
  try {
    form = await req.formData();
  } catch {
    return fail(400, "invalid_form", { detail: "Expected a multipart form with a file field." });
  }

  const file = form.get("file");
  if (!(file instanceof File)) {
    return fail(400, "file_required", { detail: "Attach a .zip, .tar, .tar.gz or .tgz archive." });
  }
  if (file.size === 0) return fail(400, "empty_file", { detail: "The uploaded archive is empty." });
  if (file.size > MAX_ARCHIVE_BYTES) {
    return fail(413, "archive_too_large", { detail: "Archive exceeds the 20MB limit." });
  }

  const parsed = uploadSchema.safeParse({
    name: String(form.get("name") ?? ""),
    description: String(form.get("description") ?? ""),
    runtime: String(form.get("runtime") ?? ""),
    startCommand: String(form.get("startCommand") ?? ""),
  });
  if (!parsed.success) return fail(400, zodErrorMessage(parsed.error));
  const input = parsed.data;

  const plan = await getEffectivePlan(auth.user.id);
  if (!plan.limits.runtimes.includes(input.runtime)) {
    return fail(403, "runtime_not_enabled", {
      detail: `The ${input.runtime} runtime is not enabled on this deployment.`,
    });
  }
  const safety = await checkBotSafety(auth.user.id);
  if (!safety.ok) return fail(403, safety.reason!, { detail: safety.detail });

  const data = Buffer.from(await file.arrayBuffer());

  const bot = await db.bot.create({
    data: {
      userId: auth.user.id,
      name: input.name,
      description: input.description || `Uploaded ${file.name.slice(0, 100)}`,
      runtime: input.runtime,
      startCommand: input.startCommand,
      sourceType: "UPLOAD",
      sourceRef: file.name.slice(0, 200),
      status: "CREATED",
    },
  });

  try {
    // The runtime service extracts the archive with full zip-slip / symlink /
    // bomb protection (unsupported formats and corrupt archives are rejected
    // with a clear error there).
    const result = await uploadToWorkspace(bot.id, file.name, data, "");

    await audit({
      actorId: auth.user.id,
      actorEmail: auth.user.email,
      action: "BOT_CREATE_UPLOAD",
      targetType: "bot",
      targetId: bot.id,
      detail: { name: bot.name, runtime: bot.runtime, archive: file.name.slice(0, 100), kind: result.kind, files: result.kind === "archive" ? result.files : 1 },
      ip,
      userAgent,
    });
    return ok(
      { ok: true, bot: { id: bot.id, name: bot.name }, extracted: result.kind === "archive" ? { files: result.files, bytes: result.bytes } : { files: 1, bytes: result.bytes } },
      { status: 201 },
    );
  } catch (err) {
    // Roll back the bot row — never leave a half-created bot behind.
    await db.bot.delete({ where: { id: bot.id } }).catch(() => undefined);
    if (err instanceof RuntimeOfflineError) {
      return fail(503, "runtime_unavailable", {
        detail: "The bot runtime service is not reachable, so uploads cannot be stored right now. It may be starting — try again shortly.",
      });
    }
    if (err instanceof FileOpError) {
      return fail(400, "unsafe_archive", { detail: err.message });
    }
    const detail = err instanceof Error ? err.message : String(err);
    return fail(500, "extract_failed", { detail });
  }
}
