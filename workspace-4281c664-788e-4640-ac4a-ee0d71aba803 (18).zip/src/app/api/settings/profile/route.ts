/** PATCH /api/settings/profile { name } — update display name. */
import { ok, fail, requireUser, originCheck, readJson, reqCtx } from "@/lib/api";
import { z } from "zod";
import { audit } from "@/lib/audit";
import { db } from "@/lib/db";

const schema = z.object({ name: z.string().trim().min(1).max(80) });

export async function PATCH(req: Request) {
  const csrf = originCheck(req);
  if (csrf) return csrf;
  const auth = await requireUser();
  if ("response" in auth) return auth.response;
  const { ip, userAgent } = reqCtx(req);

  const body = await readJson<Record<string, unknown>>(req);
  const parsed = schema.safeParse(body ?? {});
  if (!parsed.success) return fail(400, "invalid_name", { detail: "Name must be 1–80 characters." });

  await db.user.update({ where: { id: auth.user.id }, data: { name: parsed.data.name } });
  await audit({ actorId: auth.user.id, actorEmail: auth.user.email, action: "PROFILE_UPDATE", detail: {}, ip, userAgent });
  return ok({ ok: true });
}
