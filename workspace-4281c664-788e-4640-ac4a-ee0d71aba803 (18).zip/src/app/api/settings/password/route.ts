/** POST /api/settings/password { currentPassword, newPassword } — change password. */
import { ok, fail, requireUser, originCheck, readJson, reqCtx } from "@/lib/api";
import { z } from "zod";
import { verifyPassword, hashPassword, passwordIssues } from "@/lib/password";
import { audit } from "@/lib/audit";
import { notify } from "@/lib/notify";
import { db } from "@/lib/db";

const schema = z.object({ currentPassword: z.string().min(1).max(128), newPassword: z.string().min(8).max(128) });

export async function POST(req: Request) {
  const csrf = originCheck(req);
  if (csrf) return csrf;
  const auth = await requireUser();
  if ("response" in auth) return auth.response;
  const { ip, userAgent } = reqCtx(req);

  const body = await readJson<Record<string, unknown>>(req);
  const parsed = schema.safeParse(body ?? {});
  if (!parsed.success) return fail(400, "invalid_input", { detail: "Current and new password are required (new: min 8 chars)." });

  const user = await db.user.findUnique({ where: { id: auth.user.id } });
  if (!user) return fail(404, "user_not_found");

  const valid = await verifyPassword(parsed.data.currentPassword, user.passwordHash);
  if (!valid) return fail(403, "wrong_password", { detail: "Your current password is incorrect." });

  const issues = passwordIssues(parsed.data.newPassword);
  if (issues.length > 0) return fail(400, "weak_password", { detail: `Password needs ${issues.join(", ")}.` });

  const passwordHash = await hashPassword(parsed.data.newPassword);
  await db.user.update({ where: { id: user.id }, data: { passwordHash } });

  // Keep the current session, revoke all others.
  const others = await db.session.findMany({ where: { userId: user.id, revokedAt: null }, select: { id: true } });
  const currentSessionId = others.length > 0 ? await findCurrentSessionId() : null;
  for (const s of others) {
    if (s.id !== currentSessionId) {
      await db.session.update({ where: { id: s.id }, data: { revokedAt: new Date() } }).catch(() => undefined);
    }
  }

  await audit({ actorId: user.id, actorEmail: user.email, action: "PASSWORD_CHANGED", detail: {}, ip, userAgent });
  await notify(user.id, {
    title: "Password changed",
    body: "Your password was changed from account settings. Other sessions were signed out.",
    level: "WARNING",
    category: "SECURITY",
  });
  return ok({ ok: true });
}

async function findCurrentSessionId(): Promise<string | null> {
  try {
    const { cookies } = await import("next/headers");
    const { jwtVerify } = await import("jose");
    const store = await cookies();
    const raw = store.get("bd_session")?.value;
    if (!raw) return null;
    const secret = process.env.APP_SECRET ?? "";
    const verified = await jwtVerify(raw, new TextEncoder().encode(secret));
    const payload = verified.payload as { sid?: string };
    return payload.sid ?? null;
  } catch {
    return null;
  }
}
