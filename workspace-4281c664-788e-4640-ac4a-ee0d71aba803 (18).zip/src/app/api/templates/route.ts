/** GET /api/templates — public bot template catalog (metadata only). */
import { ok } from "@/lib/api";
import { TEMPLATES } from "@/lib/templates";

export async function GET() {
  return ok({
    templates: TEMPLATES.map((t) => ({
      id: t.id,
      name: t.name,
      runtime: t.runtime,
      description: t.description,
    })),
  });
}
