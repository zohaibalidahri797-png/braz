import type { Metadata } from "next";
import Link from "next/link";
import { Zap } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { db } from "@/lib/db";
import { monetizationEnabled, FREE_LAUNCH_NOTE } from "@/lib/monetization";
import { PageH1, PageLead, PublicPage } from "@/content/public-pages";

export const dynamic = "force-dynamic"; // plans are DB-driven and admin-editable

export const metadata: Metadata = {
  title: "Pricing — Free during launch",
  description:
    "BotDock Cloud is free during launch: every account gets free bot hosting with no fixed plan caps and system-wide resource protection. No payment method, no subscription, no checkout.",
  alternates: { canonical: "/pricing" },
};

interface PlanRow {
  id: string;
  name: string;
  description: string;
  priceMonthly: number;
  features: string[];
}

function usdLabel(cents: number): string {
  return cents === 0 ? "$0" : `$${(cents / 100).toFixed(cents % 100 === 0 ? 0 : 2)}`;
}

async function getPlans(): Promise<{ plans: PlanRow[]; note: string | null }> {
  try {
    const paid = monetizationEnabled();
    // Free-first launch: only zero-cost plans are shown publicly.
    const rows = await db.plan.findMany({
      where: paid ? { isActive: true, isPublic: true } : { isActive: true, isPublic: true, priceMonthly: 0, priceYearly: 0 },
      orderBy: { sortOrder: "asc" },
    });
    return {
      plans: rows.map((p) => ({
        id: p.id,
        name: p.name,
        description: p.description,
        priceMonthly: p.priceMonthly,
        features: JSON.parse(p.features) as string[],
      })),
      note: null,
    };
  } catch {
    return { plans: [], note: "Plan data is temporarily unavailable. Please refresh in a moment." };
  }
}

export default async function PricingPage() {
  const { plans, note } = await getPlans();
  const freeOnly = !monetizationEnabled();

  return (
    <PublicPage>
      <div className="mx-auto max-w-5xl px-4 py-16 sm:px-6">
        <PageH1>{freeOnly ? "Free during launch" : "Simple, honest pricing"}</PageH1>
        <PageLead>
          {freeOnly
            ? "Every account gets the free hosting plan automatically — no payment method, no subscription, and no checkout. Every limit below is enforced server-side by the bot runtime."
            : "Every limit below is enforced server-side by the bot runtime — what you see is exactly what your plan gives you. Plans are managed by the administrators of this deployment and may change."}
        </PageLead>

        <div className={`mt-10 grid gap-4 ${freeOnly ? "mx-auto max-w-xl" : "md:grid-cols-2 xl:grid-cols-4"}`}>
          {plans.map((p) => (
            <Card key={p.id} className={p.id === "free" ? "border-violet-500/40 ring-1 ring-violet-500/30 shadow-[0_0_28px_rgba(139,92,246,0.1)]" : ""}>
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-base">{p.name}</CardTitle>
                  {p.id === "free" ? (
                    <Badge className="bg-violet-500/15 text-violet-300 hover:bg-violet-500/15">Free forever</Badge>
                  ) : null}
                </div>
                <p className="text-2xl font-bold">
                  {usdLabel(p.priceMonthly)}
                  {p.priceMonthly > 0 ? <span className="text-sm font-normal text-muted-foreground">/mo</span> : null}
                </p>
                <p className="min-h-10 text-xs text-muted-foreground">{p.description}</p>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm">
                  {p.features.map((f) => (
                    <li key={f} className="flex items-start gap-2">
                      <Zap className="mt-0.5 h-3.5 w-3.5 shrink-0 text-cyan-400" />
                      <span>{f}</span>
                    </li>
                  ))}
                </ul>
                <Button asChild
                  className={`mt-5 w-full ${p.id === "free" ? "shadow-[0_0_18px_rgba(139,92,246,0.3)]" : ""}`}
                  variant={p.id === "free" ? "default" : "outline"}
                >
                  <Link href="/register">{p.priceMonthly === 0 ? "Start free" : "Choose plan"}</Link>
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
        {note ? <p className="mt-4 text-center text-xs text-muted-foreground">{note}</p> : null}
        {freeOnly ? (
          <p className="mt-3 text-center text-xs text-muted-foreground">{FREE_LAUNCH_NOTE}</p>
        ) : null}

        <div className="mt-12 rounded-xl border bg-card/60 p-6 text-sm text-muted-foreground">
          <h2 className="text-base font-semibold text-foreground">{freeOnly ? "How the free plan works" : "How billing works"}</h2>
          <ul className="mt-3 list-disc space-y-1.5 pl-5">
            <li>No fixed plan caps: bot count, deployments and storage are not limited by plan records during the launch. Bots run with system-wide resource protection so one bot can never starve the others.</li>
            <li>Your real usage is shown in the dashboard under <span className="font-medium text-foreground">Plan &amp; usage</span>.</li>
            {freeOnly ? (
              <>
                <li>No payment provider is involved at launch: there is no checkout, no card input, and no invoices. Billing code exists in the codebase but stays disabled until monetization is explicitly enabled by the operators.</li>
                <li>Free bots share limited infrastructure and may be restarted under load — capacity is disclosed honestly instead of promising unlimited hosting.</li>
              </>
            ) : (
              <li>Payments (when Stripe is configured) are handled by Stripe Checkout; this deployment&apos;s billing history is visible in your dashboard.</li>
            )}
          </ul>
        </div>
      </div>
    </PublicPage>
  );
}
