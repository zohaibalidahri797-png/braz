import type { MetadataRoute } from "next";

const siteUrl = (process.env.APP_URL ?? "http://localhost:3000").replace(/\/$/, "");

export default function sitemap(): MetadataRoute.Sitemap {
  const now = new Date();
  return [
    { url: `${siteUrl}/`, lastModified: now, changeFrequency: "weekly", priority: 1 },
    { url: `${siteUrl}/features`, lastModified: now, changeFrequency: "monthly", priority: 0.8 },
    { url: `${siteUrl}/pricing`, lastModified: now, changeFrequency: "weekly", priority: 0.9 },
    { url: `${siteUrl}/docs`, lastModified: now, changeFrequency: "monthly", priority: 0.8 },
    { url: `${siteUrl}/support`, lastModified: now, changeFrequency: "monthly", priority: 0.6 },
    { url: `${siteUrl}/status`, lastModified: now, changeFrequency: "daily", priority: 0.5 },
    { url: `${siteUrl}/security`, lastModified: now, changeFrequency: "yearly", priority: 0.4 },
    { url: `${siteUrl}/aup`, lastModified: now, changeFrequency: "yearly", priority: 0.3 },
    { url: `${siteUrl}/terms`, lastModified: now, changeFrequency: "yearly", priority: 0.3 },
    { url: `${siteUrl}/privacy`, lastModified: now, changeFrequency: "yearly", priority: 0.3 },
  ];
}
