import { redirect } from "next/navigation";

/**
 * Real, directly navigable route for sign-in. The dashboard SPA keeps its
 * hash-based session state at `/#/login`; this page 307-redirects there so
 * `/login` always works — typed directly, refreshed, or linked from emails.
 */
export default function LoginPage() {
  redirect("/#/login");
}
