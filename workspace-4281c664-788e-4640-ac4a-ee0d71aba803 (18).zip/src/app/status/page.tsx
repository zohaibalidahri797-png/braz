import type { Metadata } from "next";
import Link from "next/link";
import { CheckCircle2, XCircle, HelpCircle } from "lucide-react";
import { PageH1, PageLead, PublicPage } from "@/content/public-pages";
import { dbHealthy } from "@/lib/api";
import { runtimeClient } from "@/lib/runtime-client";
import { isRuntimeEmbedded, resolveRuntimeUrl } from "@/lib/runtime-config";
import { ensureRuntime } from "@/lib/runtime-supervisor";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Service Status",
  description:
    "Live BotDock Cloud service status: web application, database and bot runtime availability, measured at page load. No invented uptime numbers.",
  alternates: { canonical: "/status" },
};

interface Row {
  name: string;
  ok: boolean | null; // null = unknown / not measured
  detail: string;
}

async function measure(): Promise<{ rows: Row[]; measuredAt: string }> {
  const rows: Row[] = [];
  const dbOk = await dbHealthy();

  // Database and runtime are reported INDEPENDENTLY — same logic as /api/health.
  let runtimeOk = false;
  let runtimeDetail = "Runtime service did not respond.";
  let runtimeExtra = "";
  try {
    const resolution = resolveRuntimeUrl();
    if (resolution.invalid) {
      runtimeDetail = `Runtime URL misconfigured (${resolution.reason}). Bot hosting is unavailable until the operator fixes RUNTIME_SERVICE_URL.`;
    } else {
      if (isRuntimeEmbedded()) await ensureRuntime();
      const h = await runtimeClient.health(2500);
      if (h.ok) {
        runtimeOk = true;
        runtimeDetail = "Accepting deploy and lifecycle requests.";
        const bits: string[] = [];
        if (typeof h.activeBots === "number") bits.push(`${h.activeBots} bot process${h.activeBots === 1 ? "" : "es"} active`);
        if (typeof h.uptimeSec === "number") bits.push(`service up ${Math.floor(h.uptimeSec / 60)} min`);
        if (bits.length) runtimeExtra = ` (${bits.join(", ")})`;
      }
    }
  } catch {
    runtimeOk = false;
  }

  rows.push({
    name: "Web application",
    ok: true,
    detail: "The dashboard, API and this status page are being served.",
  });
  rows.push({
    name: "Database",
    ok: dbOk,
    detail: dbOk
      ? "Connection verified with a live query at page load."
      : "The database did not respond. Sign-in, registration and bot data are affected until this recovers.",
  });
  rows.push({
    name: "Bot runtime",
    ok: dbOk ? runtimeOk : null,
    detail: dbOk ? runtimeDetail + runtimeExtra : "Not measured — the database is unreachable.",
  });

  return { rows, measuredAt: new Date().toISOString() };
}

function StatusIcon({ ok }: { ok: boolean | null }) {
  if (ok === true) return <CheckCircle2 className="h-5 w-5 text-emerald-500" aria-label="Operational" />;
  if (ok === false) return <XCircle className="h-5 w-5 text-red-500" aria-label="Not operational" />;
  return <HelpCircle className="h-5 w-5 text-muted-foreground" aria-label="Unknown" />;
}

export default async function StatusPage() {
  const { rows, measuredAt } = await measure();
  const allOk = rows.every((r) => r.ok === true);

  return (
    <PublicPage>
      <div className="mx-auto max-w-3xl px-4 py-16 sm:px-6">
        <PageH1>Service status</PageH1>
        <PageLead>
          Measured live at page load — {new Date(measuredAt).toUTCString()}. This page shows what the
          platform actually checked, not a target. Historical uptime percentages are deliberately
          not shown: they would require monitoring history this deployment does not collect.
        </PageLead>

        <div
          className={`mt-8 rounded-xl border p-5 ${
            allOk ? "border-emerald-500/40 bg-emerald-500/5" : "border-amber-500/40 bg-amber-500/5"
          }`}
          role="status"
        >
          <p className="font-semibold">{allOk ? "All systems operational" : "Some systems need attention"}</p>
          <p className="mt-1 text-sm text-muted-foreground">
            {allOk
              ? "Web, database and bot runtime all responded normally."
              : "One or more components did not respond as expected. Details below."}
          </p>
        </div>

        <ul className="mt-6 space-y-3">
          {rows.map((r) => (
            <li key={r.name} className="flex items-start gap-3 rounded-xl border bg-card/60 p-4">
              <span className="mt-0.5">
                <StatusIcon ok={r.ok} />
              </span>
              <div>
                <p className="font-medium">{r.name}</p>
                <p className="mt-0.5 text-sm text-muted-foreground">{r.detail}</p>
              </div>
            </li>
          ))}
        </ul>

        <p className="mt-8 text-sm text-muted-foreground">
          Prefer raw data? The same checks are available as JSON at{" "}
          <a href="/api/health" className="font-medium text-violet-400 hover:underline">/api/health</a>.
          If something is down,{" "}
          <Link href="/support" className="font-medium text-violet-400 hover:underline">contact support</Link>{" "}
          and include the component names above.
        </p>
      </div>
    </PublicPage>
  );
}
