import type { Metadata } from "next";
import Link from "next/link";
import { PageH1, PageLead, PublicPage } from "@/content/public-pages";

export const metadata: Metadata = {
  title: "Documentation",
  description:
    "BotDock Cloud documentation: prepare a bot, create it from a template/archive/GitHub, configure environment variables, deploy and operate it.",
  alternates: { canonical: "/docs" },
};

function Code({ children }: { children: React.ReactNode }) {
  return <code className="rounded bg-muted px-1.5 py-0.5 font-mono text-xs">{children}</code>;
}

export default function DocsPage() {
  return (
    <PublicPage>
      <div className="mx-auto max-w-3xl px-4 py-16 sm:px-6">
        <PageH1>Documentation</PageH1>
        <PageLead>
          Everything you need to go from a folder of code to a running, monitored bot.
        </PageLead>

        <nav className="mt-8 rounded-xl border bg-card/60 p-5 text-sm" aria-label="On this page">
          <p className="font-semibold">On this page</p>
          <ul className="mt-2 list-disc space-y-1 pl-5 text-muted-foreground">
            <li><a className="hover:text-foreground" href="#getting-started">0. Getting started in 4 steps</a></li>
            <li><a className="hover:text-foreground" href="#prepare">1. Prepare your bot</a></li>
            <li><a className="hover:text-foreground" href="#create">2. Create it on BotDock</a></li>
            <li><a className="hover:text-foreground" href="#env">3. Environment variables</a></li>
            <li><a className="hover:text-foreground" href="#deploy">4. Deploy &amp; operate</a></li>
            <li><a className="hover:text-foreground" href="#limits">5. Hosting policy (free launch)</a></li>
          </ul>
        </nav>

        <section id="getting-started" className="mt-12">
          <h2 className="text-xl font-bold">0. Getting started in 4 steps</h2>
          <ol className="mt-3 list-decimal space-y-1.5 pl-5 text-sm text-muted-foreground">
            <li><Link href="/register" className="text-violet-400 hover:underline">Create a free account</Link> and verify your email.</li>
            <li>In the dashboard, create a bot from a template, a .zip/.tar.gz archive, or a GitHub repository.</li>
            <li>Add your bot token under the bot&apos;s <em>Env</em> tab (e.g. <Code>BOT_TOKEN</Code>).</li>
            <li>Press <strong>Deploy</strong> and watch the build and runtime logs appear in real time.</li>
          </ol>
        </section>

        <section id="prepare" className="mt-12">
          <h2 className="text-xl font-bold">1. Prepare your bot</h2>
          <p className="mt-3 text-sm text-muted-foreground">
            Bring any long-running Telegram bot or automation. BotDock detects the runtime from your
            dependency manifest:
          </p>
          <ul className="mt-3 list-disc space-y-1.5 pl-5 text-sm text-muted-foreground">
            <li><Code>requirements.txt</Code> or <Code>pyproject.toml</Code> → Python (installed with pip into an isolated target)</li>
            <li><Code>package.json</Code> → Node.js or Bun (installed with the package manager)</li>
          </ul>
          <p className="mt-3 text-sm text-muted-foreground">
            The start command is auto-detected from <Code>main.py</Code>, <Code>bot.py</Code>, <Code>index.js</Code>,
            <Code>index.ts</Code> or the <Code>scripts.start</Code> field — and you can always override it.
          </p>
        </section>

        <section id="create" className="mt-12">
          <h2 className="text-xl font-bold">2. Create it on BotDock</h2>
          <p className="mt-3 text-sm text-muted-foreground">Three ways to bring code in:</p>
          <ul className="mt-3 list-disc space-y-1.5 pl-5 text-sm text-muted-foreground">
            <li><strong>Template</strong> — start from a ready-to-run example (echo bot, keep-alive service, webhook receiver…).</li>
            <li><strong>Archive upload</strong> — upload a <Code>.zip</Code> or <Code>.tar.gz</Code> of your project (path-traversal and size limits enforced).</li>
            <li><strong>GitHub import</strong> — connect a personal access token, pick a repository and branch. Included with your free account; the token is stored encrypted and never shown again.</li>
          </ul>
        </section>

        <section id="env" className="mt-12">
          <h2 className="text-xl font-bold">3. Environment variables</h2>
          <p className="mt-3 text-sm text-muted-foreground">
            Add secrets like <Code>BOT_TOKEN</Code> in your bot&apos;s Env tab. Values are encrypted at rest
            (AES-256-GCM) and injected into the process environment at start — they are never displayed
            again after saving. Changes apply on the next restart or redeploy.
          </p>
        </section>

        <section id="deploy" className="mt-12">
          <h2 className="text-xl font-bold">4. Deploy &amp; operate</h2>
          <p className="mt-3 text-sm text-muted-foreground">
            Deploying installs dependencies, stages the build atomically and starts your bot in an
            isolated process under the platform&apos;s system-wide resource protection. You get:
          </p>
          <ul className="mt-3 list-disc space-y-1.5 pl-5 text-sm text-muted-foreground">
            <li>Build logs per deployment and live runtime logs (ring buffer + downloadable)</li>
            <li>Live status: state, PID, uptime, memory and CPU measured from the process</li>
            <li>Start / stop / restart / redeploy controls and a full deployment history</li>
          </ul>
          <pre className="mt-4 overflow-x-auto rounded-xl border border-border bg-zinc-950 p-4 font-mono text-[12px] leading-6 text-zinc-300">{`$ botdock deploy my-telegram-bot
✓ runtime PYTHON detected
✓ installing dependencies (requirements.txt)
✓ build completed
✓ process started (pid 4211, limits applied)
● state: RUNNING — logs streaming…`}</pre>
        </section>

        <section id="limits" className="mt-12">
          <h2 className="text-xl font-bold">5. Hosting policy (free launch)</h2>
          <p className="mt-3 text-sm text-muted-foreground">
            BotDock Cloud is free during launch — no payment method, no subscription, no checkout. Create and manage
            as many bots as your work needs; there are no fixed plan caps on bot count, deployments, or storage.
            Every bot runs in an isolated process with system-wide resource protection (memory, CPU, disk) so one
            bot can never starve the others. Generous burst limits protect the service for everyone. If the host
            runs low on real capacity, you will see an honest capacity message — never an upgrade prompt.
          </p>
        </section>
      </div>
    </PublicPage>
  );
}
