import { redirect } from "next/navigation";

/**
 * Real, directly navigable route for registration. The dashboard SPA keeps
 * its hash-based session state at `/#/register`; this page 307-redirects
 * there so `/register` always works — typed directly, refreshed, or linked
 * from emails and the public pricing page.
 */
export default function RegisterPage() {
  redirect("/#/register");
}
