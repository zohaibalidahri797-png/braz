import type { Metadata } from "next";
import Link from "next/link";
import { BookOpen, LifeBuoy, Mail, ShieldQuestion } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { PageH1, PageLead, PublicPage } from "@/content/public-pages";

export const metadata: Metadata = {
  title: "Support",
  description:
    "Get help with BotDock Cloud: documentation, status and health endpoint, account and billing questions, and how to report a security issue.",
  alternates: { canonical: "/support" },
};

export default function SupportPage() {
  const supportEmail = "support@botdock.cloud";
  return (
    <PublicPage>
      <div className="mx-auto max-w-3xl px-4 py-16 sm:px-6">
        <PageH1>Support</PageH1>
        <PageLead>
          Fastest answers first: the documentation and your dashboard&apos;s status indicators resolve
          most issues. For everything else, reach us directly.
        </PageLead>

        <div className="mt-10 grid gap-4 sm:grid-cols-2">
          <Card>
            <CardContent className="pt-6">
              <BookOpen className="h-6 w-6 text-violet-400" />
              <h2 className="mt-3 font-semibold">Documentation</h2>
              <p className="mt-1.5 text-sm text-muted-foreground">
                Prepare, deploy and operate bots — including templates, archives and GitHub imports.
              </p>
              <Link href="/docs" className="mt-3 inline-block text-sm font-medium text-violet-400 hover:underline">
                Read the docs →
              </Link>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <LifeBuoy className="h-6 w-6 text-violet-400" />
              <h2 className="mt-3 font-semibold">Platform status</h2>
              <p className="mt-1.5 text-sm text-muted-foreground">
                The health endpoint reports database and bot-runtime availability independently —
                check it before reporting an outage.
              </p>
              <a href="/api/health" className="mt-3 inline-block text-sm font-medium text-violet-400 hover:underline">
                Open /api/health →
              </a>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <Mail className="h-6 w-6 text-violet-400" />
              <h2 className="mt-3 font-semibold">Email support</h2>
              <p className="mt-1.5 text-sm text-muted-foreground">
                Account, billing and deployment questions — free during launch, for every account.
              </p>
              <a href={`mailto:${supportEmail}`} className="mt-3 inline-block text-sm font-medium text-violet-400 hover:underline">
                {supportEmail}
              </a>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <ShieldQuestion className="h-6 w-6 text-violet-400" />
              <h2 className="mt-3 font-semibold">Security reports</h2>
              <p className="mt-1.5 text-sm text-muted-foreground">
                Found a vulnerability? Email <span className="font-mono text-xs">security@botdock.cloud</span> with
                details. We credit responsible disclosures.
              </p>
            </CardContent>
          </Card>
        </div>

        <div className="mt-12 rounded-xl border bg-card/60 p-6 text-sm text-muted-foreground">
          <h2 className="text-base font-semibold text-foreground">Signed in already?</h2>
          <p className="mt-2">
            The in-app <strong>Support</strong> page shows your account&apos;s runtime status, plan and
            recent deployments — include that information when contacting support for the fastest help.
          </p>
        </div>

        <div className="mt-12">
          <h2 className="text-xl font-bold text-foreground">Frequently asked questions</h2>
          <dl className="mt-4 space-y-5 text-sm">
            <div>
              <dt className="font-semibold text-foreground">Is BotDock Cloud really free?</dt>
              <dd className="mt-1 text-muted-foreground">
                Yes during launch — every account is placed on the free plan automatically, with no
                payment method and no checkout. There are no fixed caps on bot count, deployments or
                storage; what applies to everyone is the platform&apos;s system-wide resource
                protection and burst guards. See{" "}
                <Link href="/pricing" className="text-violet-400 hover:underline">pricing</Link>.
              </dd>
            </div>
            <div>
              <dt className="font-semibold text-foreground">Which runtimes can my bot use?</dt>
              <dd className="mt-1 text-muted-foreground">
                Python (<Code>requirements.txt</Code> / <Code>pyproject.toml</Code>), Node.js and Bun
                (<Code>package.json</Code>). Dependencies are installed automatically at deploy time.
                See <Link href="/features" className="text-violet-400 hover:underline">features</Link>.
              </dd>
            </div>
            <div>
              <dt className="font-semibold text-foreground">My bot shows stopped — what now?</dt>
              <dd className="mt-1 text-muted-foreground">
                Open the bot&apos;s Logs tab: exited processes are reported honestly, and build or
                startup errors show the real output. Fix the cause and press Start or Redeploy. If
                the whole runtime is down, check{" "}
                <Link href="/status" className="text-violet-400 hover:underline">status</Link>.
              </dd>
            </div>
            <div>
              <dt className="font-semibold text-foreground">Why is my deployment blocked until I verify my email?</dt>
              <dd className="mt-1 text-muted-foreground">
                Email verification keeps throwaway accounts out of shared infrastructure. Request a
                new verification email from your dashboard. If delivery is not configured on this
                deployment, the dashboard says so explicitly and an administrator can verify your
                account manually.
              </dd>
            </div>
            <div>
              <dt className="font-semibold text-foreground">How do I report abuse or a security issue?</dt>
              <dd className="mt-1 text-muted-foreground">
                Abuse: email <span className="font-mono">support@botdock.cloud</span>. Security
                issues: <span className="font-mono">security@botdock.cloud</span> per the{" "}
                <Link href="/security" className="text-violet-400 hover:underline">security page</Link>.
              </dd>
            </div>
          </dl>
        </div>
      </div>
    </PublicPage>
  );
}

function Code({ children }: { children: React.ReactNode }) {
  return <code className="rounded bg-muted px-1.5 py-0.5 font-mono text-xs">{children}</code>;
}
