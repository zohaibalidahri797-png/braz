import type { Metadata } from "next";
import { PageH1, PageLead, PublicPage } from "@/content/public-pages";

export const metadata: Metadata = {
  title: "Privacy Policy",
  description:
    "BotDock Cloud Privacy Policy: what data is collected, how it is stored and encrypted, and how it can be deleted.",
  alternates: { canonical: "/privacy" },
};

export default function PrivacyPage() {
  return (
    <PublicPage>
      <div className="mx-auto max-w-3xl px-4 py-16 sm:px-6">
        <PageH1>Privacy Policy</PageH1>
        <PageLead>Last updated: March 2026. This policy describes what BotDock Cloud stores and why.</PageLead>

        <div className="mt-10 space-y-8 text-sm text-muted-foreground">
          <section>
            <h2 className="text-base font-semibold text-foreground">Data we store</h2>
            <ul className="mt-2 list-disc space-y-1 pl-5">
              <li><strong>Account data</strong> — name, email, password hash (bcrypt), profile image if provided via OAuth.</li>
              <li><strong>Security data</strong> — session records (device, IP, user-agent), audit logs of security-relevant actions, verification tokens (stored as SHA-256 hashes).</li>
              <li><strong>Bot data</strong> — your uploaded source files, deployment logs, and environment variables.</li>
              <li><strong>Plan &amp; usage data</strong> — your hosting plan and resource usage counters. BotDock Cloud is free during launch: no payment details are collected, and no card data is ever processed or stored.</li>
            </ul>
          </section>
          <section>
            <h2 className="text-base font-semibold text-foreground">How secrets are protected</h2>
            <ul className="mt-2 list-disc space-y-1 pl-5">
              <li>Bot environment variables and GitHub tokens are encrypted at rest with AES-256-GCM.</li>
              <li>Secrets are never returned by the API after being saved and are redacted from logs.</li>
              <li>Passwords are hashed with bcrypt and cannot be recovered — only reset.</li>
            </ul>
          </section>
          <section>
            <h2 className="text-base font-semibold text-foreground">What we do not do</h2>
            <ul className="mt-2 list-disc space-y-1 pl-5">
              <li>We do not sell or share personal data with advertisers.</li>
              <li>We do not read the contents of your bot source files except where required to operate the service (dependency installation, debugging a support request you opened).</li>
              <li>We do not send marketing email without opt-in; operational email (verification, password reset, broadcasts you subscribe to) is sent only as needed.</li>
            </ul>
          </section>
          <section>
            <h2 className="text-base font-semibold text-foreground">Retention &amp; deletion</h2>
            <p className="mt-2">
              Deleting a bot removes its files, logs and env vars. Deleting your account removes your
              personal data; audit-log entries required for platform security are retained in
              minimized form. Log retention otherwise follows your plan.
            </p>
          </section>
          <section>
            <h2 className="text-base font-semibold text-foreground">Contact</h2>
            <p className="mt-2">
              Privacy questions: <span className="font-mono text-xs">privacy@botdock.cloud</span>
            </p>
          </section>
        </div>
      </div>
    </PublicPage>
  );
}
