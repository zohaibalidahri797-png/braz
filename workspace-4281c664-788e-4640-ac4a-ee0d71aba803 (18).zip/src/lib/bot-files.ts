/**
 * Bot project workspace file operations (server-only).
 *
 * Each bot has a persistent workspace at {RUNTIME_DATA_DIR}/workspace/{botId}/
 * where the file manager operates. On deploy, the workspace is copied to the
 * runtime's staging area. Security:
 *  - every path is resolved and must stay inside the bot workspace root
 *  - symlinks are refused (no escape hatches)
 *  - per-file write cap 512KB, upload archive cap 20MB, workspace quota
 *  - zip extraction validates every entry (no absolute paths, no "..", no
 *    symlink entries) before writing — prevents zip-slip
 *  - tar.gz validated by listing entries first, then extracted with safe flags
 */

import AdmZip from "adm-zip";
import { spawnSync } from "node:child_process";
import fs from "node:fs";
import path from "node:path";
import { runtimeDataDir } from "./runtime-config";

export const MAX_FILE_WRITE = 512 * 1024;
export const MAX_ARCHIVE_BYTES = 20 * 1024 * 1024;
const FORBIDDEN_BASENAMES = new Set([".env", ".env.local", ".bashrc", ".profile", ".ssh"]);

export function workspaceRoot(botId: string): string {
  if (!/^[a-zA-Z0-9_-]{1,64}$/.test(botId)) throw new Error("invalid bot id");
  return path.join(runtimeDataDir(), "workspace", botId);
}

export class PathError extends Error {}

/** Resolves a user-supplied relative path inside the workspace. Throws on escape. */
export function safeResolve(botId: string, relPath: string): string {
  const root = workspaceRoot(botId);
  const clean = relPath.replace(/^\/+/, "");
  if (clean.includes("\0")) throw new PathError("invalid path");
  const resolved = path.resolve(root, clean);
  const rootWithSep = root.endsWith(path.sep) ? root : root + path.sep;
  if (resolved !== root && !resolved.startsWith(rootWithSep)) {
    throw new PathError("path escapes the bot workspace");
  }
  const rel = path.relative(root, resolved);
  for (const seg of rel.split(path.sep)) {
    if (FORBIDDEN_BASENAMES.has(seg)) {
      throw new PathError(`"${seg}" is managed by the platform and cannot be used here`);
    }
  }
  return resolved;
}

function lstatSafe(p: string): fs.Stats | null {
  try {
    return fs.lstatSync(p);
  } catch {
    return null;
  }
}

export interface FileEntry {
  path: string;
  type: "file" | "dir";
  size: number;
  modifiedAt: string;
}

export function listFiles(botId: string, relDir = ""): FileEntry[] {
  const absDir = safeResolve(botId, relDir || ".");
  const st = lstatSafe(absDir);
  if (!st || !st.isDirectory()) throw new PathError("not a directory");
  const out: FileEntry[] = [];
  for (const name of fs.readdirSync(absDir)) {
    if (name === ".botdock-deps" || name === "node_modules") continue; // noise
    const abs = path.join(absDir, name);
    const s = lstatSafe(abs);
    if (!s) continue;
    if (s.isSymbolicLink()) continue; // never surface symlinks
    const rel = path.relative(workspaceRoot(botId), abs).split(path.sep).join("/");
    out.push({
      path: rel,
      type: s.isDirectory() ? "dir" : "file",
      size: s.size,
      modifiedAt: s.mtime.toISOString(),
    });
  }
  out.sort((a, b) => {
    if (a.type !== b.type) return a.type === "dir" ? -1 : 1;
    return a.path.localeCompare(b.path);
  });
  return out;
}

export function readFileContent(botId: string, relPath: string): { content: string; size: number; binary: boolean } {
  const abs = safeResolve(botId, relPath);
  const st = lstatSafe(abs);
  if (!st) throw new PathError("file not found");
  if (st.isSymbolicLink()) throw new PathError("symlinks are not supported");
  if (!st.isFile()) throw new PathError("not a file");
  if (st.size > MAX_FILE_WRITE) throw new PathError(`file exceeds the ${Math.round(MAX_FILE_WRITE / 1024)}KB viewer limit`);
  const buf = fs.readFileSync(abs);
  const binary = buf.includes(0);
  return { content: binary ? "" : buf.toString("utf8"), size: st.size, binary };
}

export function writeFileContent(botId: string, relPath: string, content: string): void {
  const abs = safeResolve(botId, relPath);
  const buf = Buffer.from(content, "utf8");
  if (buf.length > MAX_FILE_WRITE) throw new PathError(`file exceeds the ${Math.round(MAX_FILE_WRITE / 1024)}KB editor limit`);
  fs.mkdirSync(path.dirname(abs), { recursive: true });
  fs.writeFileSync(abs, buf);
}

export function makeDir(botId: string, relPath: string): void {
  const abs = safeResolve(botId, relPath);
  fs.mkdirSync(abs, { recursive: true });
}

export function deletePath(botId: string, relPath: string): void {
  const abs = safeResolve(botId, relPath);
  const st = lstatSafe(abs);
  if (!st) throw new PathError("not found");
  if (abs === workspaceRoot(botId)) throw new PathError("cannot delete workspace root");
  fs.rmSync(abs, { recursive: true, force: false });
}

export function workspaceUsageBytes(botId: string): number {
  const root = workspaceRoot(botId);
  let total = 0;
  const walk = (dir: string): void => {
    let entries: fs.Dirent[];
    try {
      entries = fs.readdirSync(dir, { withFileTypes: true });
    } catch {
      return;
    }
    for (const e of entries) {
      const p = path.join(dir, e.name);
      if (e.isSymbolicLink()) continue;
      if (e.isDirectory()) walk(p);
      else if (e.isFile()) {
        try {
          total += fs.statSync(p).size;
        } catch {
          // vanished mid-walk
        }
      }
    }
  };
  walk(root);
  return total;
}

// ── Archive extraction ───────────────────────────────────────────────────────

interface ArchiveEntry {
  name: string;
  size: number;
}

function validateEntries(entries: ArchiveEntry[]): { strip: number } {
  const prefixes = new Set<string>();
  for (const e of entries) {
    const norm = e.name.replace(/\\/g, "/");
    if (norm.startsWith("/") || norm.includes("../") || norm.endsWith("/..") || norm.includes("\0")) {
      throw new PathError(`unsafe archive entry: ${e.name.slice(0, 100)}`);
    }
    // detect single common top folder to strip (e.g. repo-main/)
    const parts = norm.split("/").filter(Boolean);
    if (parts.length > 1) prefixes.add(parts[0]!);
  }
  // strip exactly one top-level dir if all entries share it
  let strip = 0;
  if (prefixes.size === 1 && entries.every((e) => e.name.replace(/\\/g, "/").split("/").filter(Boolean).length > 1)) {
    strip = 1;
  }
  return { strip };
}

/** Extract a zip archive into the bot workspace. Validates every entry first. */
export function extractZipIntoWorkspace(botId: string, data: Buffer): { files: number; bytes: number } {
  if (data.length > MAX_ARCHIVE_BYTES) throw new PathError("archive exceeds the 20MB limit");
  const zip = new AdmZip(data);
  const infos = zip.getEntries().filter((e) => !e.isDirectory);
  const entries: ArchiveEntry[] = infos.map((e) => ({ name: e.entryName, size: e.header.size }));
  if (entries.length === 0) throw new PathError("archive is empty");
  if (entries.length > 2000) throw new PathError("archive contains too many entries (max 2000)");
  const total = entries.reduce((a, e) => a + e.size, 0);
  if (total > MAX_ARCHIVE_BYTES * 2) throw new PathError("archive expands beyond limits (zip bomb protection)");
  const { strip } = validateEntries(entries);

  const root = workspaceRoot(botId);
  fs.mkdirSync(root, { recursive: true });
  let files = 0;
  let bytes = 0;
  for (const e of infos) {
    const normParts = e.entryName.replace(/\\/g, "/").split("/").filter(Boolean);
    const targetParts = normParts.slice(strip);
    if (targetParts.length === 0) continue;
    if (FORBIDDEN_BASENAMES.has(targetParts[targetParts.length - 1]!)) continue; // skip platform-managed files
    const target = path.resolve(root, ...targetParts);
    if (target !== root && !target.startsWith(root + path.sep)) continue; // defensive
    fs.mkdirSync(path.dirname(target), { recursive: true });
    fs.writeFileSync(target, e.getData());
    files += 1;
    bytes += e.header.size;
  }
  return { files, bytes };
}

/** Extract a .tar.gz / .tgz via system tar with entry validation. */
export function extractTarGzIntoWorkspace(botId: string, data: Buffer): { files: number; bytes: number } {
  if (data.length > MAX_ARCHIVE_BYTES) throw new PathError("archive exceeds the 20MB limit");
  const tmp = `/tmp/botdock-tar-${botId}-${Date.now()}.tar.gz`;
  const root = workspaceRoot(botId);
  fs.mkdirSync(root, { recursive: true });
  fs.writeFileSync(tmp, data);
  try {
    // 1) list entries and validate (no absolute paths, no ..)
    const list = spawnSync("tar", ["-tzf", tmp], { timeout: 30_000, maxBuffer: 16 * 1024 * 1024 });
    if (list.status !== 0) throw new PathError("invalid or corrupted tar.gz archive");
    const names = list.stdout.toString("utf8").split("\n").filter((l) => l.trim().length > 0);
    if (names.length === 0) throw new PathError("archive is empty");
    if (names.length > 2000) throw new PathError("archive contains too many entries (max 2000)");
    const entries = names.map((n) => ({ name: n, size: 0 }));
    const { strip } = validateEntries(entries);

    // 2) extract to a temp dir with safe flags, then move into workspace
    const extractDir = `/tmp/botdock-tar-extract-${botId}-${Date.now()}`;
    fs.mkdirSync(extractDir, { recursive: true });
    const ex = spawnSync("tar", ["-xzf", tmp, "-C", extractDir, "--no-same-owner", "--no-same-permissions"], {
      timeout: 60_000,
      maxBuffer: 16 * 1024 * 1024,
    });
    if (ex.status !== 0) throw new PathError("failed to extract tar.gz archive");

    // strip one shared top dir when present
    let srcDir = extractDir;
    const top = fs.readdirSync(extractDir);
    if (top.length === 1 && fs.statSync(path.join(extractDir, top[0]!)).isDirectory()) {
      srcDir = path.join(extractDir, top[0]!);
    }
    if (strip === 1 && srcDir === extractDir) {
      // multiple top entries — move them individually with strip
      for (const name of top) {
        fs.cpSync(path.join(extractDir, name), path.join(root, name), { recursive: true, verbatimSymlinks: false });
      }
    } else {
      fs.cpSync(srcDir, root, { recursive: true, verbatimSymlinks: false });
    }
    fs.rmSync(extractDir, { recursive: true, force: true });

    let files = 0;
    let bytes = 0;
    const count = (dir: string): void => {
      for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
        const p = path.join(dir, e.name);
        if (e.isSymbolicLink()) {
          fs.rmSync(p, { force: true }); // remove any symlinks the archive smuggled in
          continue;
        }
        if (e.isDirectory()) count(p);
        else {
          files += 1;
          try {
            bytes += fs.statSync(p).size;
          } catch {
            // ignore
          }
        }
      }
    };
    count(root);
    return { files, bytes };
  } finally {
    fs.rmSync(tmp, { force: true });
  }
}

export function writeTemplateFiles(botId: string, files: Record<string, string>): void {
  const root = workspaceRoot(botId);
  fs.mkdirSync(root, { recursive: true });
  for (const [rel, content] of Object.entries(files)) {
    const target = safeResolve(botId, rel);
    fs.mkdirSync(path.dirname(target), { recursive: true });
    fs.writeFileSync(target, content);
  }
}
