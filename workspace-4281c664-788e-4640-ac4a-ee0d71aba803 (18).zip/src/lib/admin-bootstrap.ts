/**
 * Secure first-administrator bootstrap (server-only).
 *
 * PROBLEM THIS SOLVES
 * -------------------
 * The previous policy promoted the FIRST registered account to ADMIN. On a
 * freshly deployed, publicly reachable instance that means an arbitrary
 * stranger who registers first owns the platform.
 *
 * NEW POLICY
 * ----------
 * - Production (NODE_ENV=production) with an EMPTY user table:
 *     registration must present a valid one-time `ADMIN_BOOTSTRAP_TOKEN`
 *     (set by the operator as an environment variable). The account created
 *     with it becomes the initial ADMIN.
 *   - No token configured → the first registration is REFUSED with
 *     `admin_bootstrap_required` and a clear operator hint (setup incomplete).
 * - Development (no NODE_ENV=production): first account auto-becomes ADMIN
 *   for convenience, exactly as before, IF no ADMIN_BOOTSTRAP_TOKEN is set.
 *   Setting ADMIN_BOOTSTRAP_TOKEN in development enforces the same flow.
 * - All later registrations are plain USER — regardless of mode.
 * - OAuth-created users are ALWAYS USER (never affected).
 *
 * RACE SAFETY
 * -----------
 * Granting ADMIN is guarded by an atomically-created unique marker row
 * (PlatformSetting key `adminBootstrapUsed`). Two concurrent "first"
 * registrations cannot both win: the unique constraint lets exactly one
 * transaction commit the ADMIN + marker pair; the loser creates a normal
 * USER. This holds on SQLite (serialized writes) AND Postgres (constraint
 * enforced at commit).
 *
 * LEGACY DATABASES
 * ----------------
 * Databases that already contain users skip the bootstrap path entirely —
 * nobody gains ADMIN retroactively.
 */

import { safeEqual } from "./crypto";

export const ADMIN_BOOTSTRAP_KEY = "adminBootstrapUsed";

export function adminBootstrapTokenConfigured(): boolean {
  return Boolean(process.env.ADMIN_BOOTSTRAP_TOKEN?.trim());
}

/**
 * True when the very first account must present the setup token.
 * (Empty DB check is done by the caller; this is the mode check.)
 */
export function bootstrapEnforced(): boolean {
  return process.env.NODE_ENV === "production" || adminBootstrapTokenConfigured();
}

/** Constant-time check of the presented token against ADMIN_BOOTSTRAP_TOKEN. */
export function bootstrapTokenValid(presented: string | undefined): boolean {
  const expected = process.env.ADMIN_BOOTSTRAP_TOKEN?.trim();
  if (!expected) return false;
  return Boolean(presented) && safeEqual(presented!.trim(), expected);
}

/** True for a Prisma unique-constraint violation (P2002). */
export function isUniqueViolation(err: unknown): boolean {
  return (
    typeof err === "object" &&
    err !== null &&
    "code" in err &&
    (err as { code?: string }).code === "P2002"
  );
}
