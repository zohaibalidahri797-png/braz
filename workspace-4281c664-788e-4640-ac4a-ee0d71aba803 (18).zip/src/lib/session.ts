/**
 * Session management (server-only).
 *
 * Design: opaque random token in an httpOnly SameSite=Lax cookie; the token is
 * ALSO wrapped as a signed JWT (jose HS256) so tampering is detectable without
 * a DB hit, while revocation is enforced by the DB Session row (tokenHash).
 * Sessions expire after 7 days; logout and "sign out everywhere" revoke rows.
 */

import { SignJWT, jwtVerify } from "jose";
import { cookies } from "next/headers";
import { db } from "@/lib/db";
import { randomToken, sha256Hex } from "@/lib/crypto";

export const SESSION_COOKIE = "bd_session";
const SESSION_TTL_SEC = 60 * 60 * 24 * 7;

function secretKey(): Uint8Array {
  const secret = process.env.APP_SECRET ?? "";
  if (secret.length < 32) throw new Error("APP_SECRET must be at least 32 characters");
  return new TextEncoder().encode(secret);
}

export interface SessionUser {
  id: string;
  email: string;
  name: string | null;
  role: string;
  status: string;
  emailVerified: Date | null;
  image: string | null;
}

interface TokenPayload {
  sid: string; // session row id
  uid: string;
  tok: string; // raw random token (also hashed in DB)
}

export async function createSession(opts: {
  userId: string;
  ip?: string | null;
  userAgent?: string | null;
}): Promise<string> {
  const raw = randomToken(32);
  const row = await db.session.create({
    data: {
      userId: opts.userId,
      tokenHash: sha256Hex(raw),
      ip: opts.ip ?? null,
      userAgent: opts.userAgent?.slice(0, 300) ?? null,
      expiresAt: new Date(Date.now() + SESSION_TTL_SEC * 1000),
    },
  });
  const jwt = await new SignJWT({ sid: row.id, uid: opts.userId, tok: raw } satisfies TokenPayload)
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime(`${SESSION_TTL_SEC}s`)
    .sign(secretKey());

  const store = await cookies();
  store.set(SESSION_COOKIE, jwt, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: SESSION_TTL_SEC,
  });
  return row.id;
}

/** Returns the authenticated user (with role/status) or null. Checks revocation + expiry. */
export async function getSessionUser(): Promise<SessionUser | null> {
  const store = await cookies();
  const raw = store.get(SESSION_COOKIE)?.value;
  if (!raw) return null;

  let payload: TokenPayload;
  try {
    const verified = await jwtVerify(raw, secretKey());
    payload = verified.payload as unknown as TokenPayload;
  } catch {
    return null;
  }
  if (!payload?.sid || !payload?.tok || !payload?.uid) return null;

  const session = await db.session
    .findFirst({
      where: { id: payload.sid, revokedAt: null },
    })
    .catch(() => null);
  if (!session) return null;
  if (session.expiresAt.getTime() < Date.now()) return null;
  if (session.tokenHash !== sha256Hex(payload.tok)) return null;
  if (session.userId !== payload.uid) return null;

  const user = await db.user.findUnique({ where: { id: session.userId } });
  if (!user) return null;
  if (user.status === "BANNED" || user.status === "SUSPENDED") return null;

  return {
    id: user.id,
    email: user.email,
    name: user.name,
    role: user.role,
    status: user.status,
    emailVerified: user.emailVerified,
    image: user.image,
  };
}

export async function revokeCurrentSession(): Promise<void> {
  const store = await cookies();
  const raw = store.get(SESSION_COOKIE)?.value;
  store.delete(SESSION_COOKIE);
  if (!raw) return;
  try {
    const verified = await jwtVerify(raw, secretKey());
    const payload = verified.payload as unknown as TokenPayload;
    if (payload.sid) {
      await db.session
        .update({ where: { id: payload.sid }, data: { revokedAt: new Date() } })
        .catch(() => undefined);
    }
  } catch {
    // invalid cookie → nothing to revoke
  }
}

export async function revokeAllUserSessions(userId: string): Promise<number> {
  const res = await db.session.updateMany({
    where: { userId, revokedAt: null },
    data: { revokedAt: new Date() },
  });
  return res.count;
}

export async function revokeSessionById(userId: string, sessionId: string): Promise<boolean> {
  const res = await db.session.updateMany({
    where: { id: sessionId, userId, revokedAt: null },
    data: { revokedAt: new Date() },
  });
  return res.count > 0;
}

/** Prune expired/revoked sessions (called opportunistically). */
export async function pruneSessions(): Promise<void> {
  await db.session.deleteMany({
    where: {
      OR: [{ expiresAt: { lt: new Date() } }, { revokedAt: { not: null, lt: new Date(Date.now() - 7 * 86400_000) } }],
    },
  }).catch(() => undefined);
}

export const SESSION_MAX_AGE = SESSION_TTL_SEC;
