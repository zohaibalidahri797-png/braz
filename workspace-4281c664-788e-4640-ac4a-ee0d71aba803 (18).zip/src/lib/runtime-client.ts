/**
 * Typed server-side client for the botdock-runtime service
 * (mini-services/bot-runtime). NEVER import from client components.
 */

import { runtimeApiKey, runtimeBaseUrl } from "./runtime-config";

export type RuntimeState = "CREATED" | "BUILDING" | "DEPLOYING" | "RUNNING" | "STOPPED" | "FAILED";

export interface RuntimeLogLine {
  ts: number;
  stream: "out" | "err" | "system";
  text: string;
}

export interface RuntimeStatus {
  botId: string;
  state: RuntimeState;
  pid: number | null;
  startedAt: number | null;
  uptimeSec: number | null;
  memoryMb: number | "unknown";
  cpuPercent: number | null;
  lastExitCode: number | null;
  lastExitSignal: string | null;
  restarts: number;
  deploymentId: string | null;
  runtime: string | null;
  startCommand: string;
  port?: number | null;
}

export interface RuntimeHealth {
  ok: boolean;
  service: string;
  version: string;
  uptimeSec: number;
  activeBots: number;
  host: { platform: string; cpus: number; totalMemMb: number; freeMemMb: number };
}

export class RuntimeUnavailableError extends Error {
  constructor(public cause2?: unknown) {
    super("runtime_unavailable");
    this.name = "RuntimeUnavailableError";
  }
}

async function call<T>(
  method: "GET" | "POST",
  pathname: string,
  body?: unknown,
  timeoutMs = 15_000,
): Promise<T> {
  const key = runtimeApiKey();
  if (!key) throw new RuntimeUnavailableError("RUNTIME_API_KEY not configured");
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(`${runtimeBaseUrl()}${pathname}`, {
      method,
      headers: {
        "X-Runtime-Key": key,
        ...(body !== undefined ? { "Content-Type": "application/json" } : {}),
      },
      body: body !== undefined ? JSON.stringify(body) : undefined,
      signal: controller.signal,
      cache: "no-store",
    });
    const json = (await res.json().catch(() => ({}))) as Record<string, unknown>;
    return { status: res.status, ...json } as T;
  } catch (err) {
    throw new RuntimeUnavailableError(err);
  } finally {
    clearTimeout(timer);
  }
}

export interface RuntimeResponse {
  status: number;
  error?: string;
  message?: string;
}

export interface DeployResponse extends RuntimeResponse {
  ok?: boolean;
  state?: RuntimeState;
  pid?: number | null;
  port?: number | null;
  buildLogTail?: string[];
}

export interface StartResponse extends RuntimeResponse {
  ok?: boolean;
  state?: RuntimeState;
  pid?: number | null;
  startedAt?: number | null;
  port?: number | null;
  error?: string;
  logTail?: RuntimeLogLine[];
}

export interface StatusResponse extends RuntimeResponse, Partial<RuntimeStatus> {}

export interface LogsResponse extends RuntimeResponse {
  lines?: RuntimeLogLine[];
  truncated?: boolean;
}

export const runtimeClient = {
  health: (timeoutMs = 4000) => call<RuntimeHealth & RuntimeResponse>("GET", "/health", undefined, timeoutMs),
  deploy: (body: {
    botId: string;
    deploymentId: string;
    runtime: string;
    startCommand: string;
    env: Record<string, string>;
    limits: { memoryMb: number; cpuPercent: number; diskMb: number; maxProcesses: number };
    installTimeoutSec?: number;
  }) => call<DeployResponse>("POST", "/deploy", body, 600_000), // installs can take minutes
  start: (botId: string, body: { env?: Record<string, string>; limits?: unknown; startCommand?: string }) =>
    call<StartResponse>("POST", `/bots/${botId}/start`, body, 30_000),
  stop: (botId: string) => call<RuntimeResponse & { killed?: boolean }>("POST", `/bots/${botId}/stop`, {}, 20_000),
  restart: (botId: string) => call<StartResponse>("POST", `/bots/${botId}/restart`, {}, 30_000),
  undeploy: (botId: string) => call<RuntimeResponse>("POST", `/bots/${botId}/undeploy`, {}, 30_000),
  status: (botId: string) => call<StatusResponse>("GET", `/bots/${botId}/status`, undefined, 8000),
  logs: (botId: string, tail = 200) =>
    call<LogsResponse>("GET", `/bots/${botId}/logs?tail=${tail}`, undefined, 8000),
  buildLogs: (botId: string, deploymentId: string, tail = 200) =>
    call<LogsResponse>("GET", `/bots/${botId}/build-logs?deploymentId=${encodeURIComponent(deploymentId)}&tail=${tail}`, undefined, 8000),
  metrics: () => call<{ bots?: unknown[]; totals?: unknown } & RuntimeResponse>("GET", "/metrics", undefined, 8000),
};

export function isRuntimeUnavailable(err: unknown): boolean {
  return err instanceof RuntimeUnavailableError;
}
