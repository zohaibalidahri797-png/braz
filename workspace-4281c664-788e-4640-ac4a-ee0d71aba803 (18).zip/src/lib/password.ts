/**
 * Password hashing with bcrypt (bcryptjs — pure JS, no native build needed).
 * Cost 12 ≈ ~250ms/hash; acceptable for login/register flows.
 */

import bcrypt from "bcryptjs";

const COST = 12;

export async function hashPassword(plain: string): Promise<string> {
  return bcrypt.hash(plain, COST);
}

export async function verifyPassword(plain: string, hash: string | null): Promise<boolean> {
  if (!hash) return false;
  try {
    return await bcrypt.compare(plain, hash);
  } catch {
    return false;
  }
}

/** Password strength: >= 8 chars, at least one letter and one digit. */
export function passwordIssues(pw: string): string[] {
  const issues: string[] = [];
  if (pw.length < 8) issues.push("at least 8 characters");
  if (!/[a-zA-Z]/.test(pw)) issues.push("at least one letter");
  if (!/[0-9]/.test(pw)) issues.push("at least one digit");
  return issues;
}
