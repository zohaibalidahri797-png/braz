/**
 * Rate limiting — fixed-window, with two interchangeable backends.
 *
 * ── memory (default in local development) ────────────────────────────────────
 * In-process Map, zero latency, single instance only.
 *
 * ── db (default when the database is REMOTE, i.e. production on Workers) ─────
 * Fixed-window counters in the RateLimitBucket table, shared across all
 * instances/isolates (Cloudflare Workers isolates don't share memory, so the
 * in-memory limiter is per-isolate and ineffective there). The increment is a
 * single atomic conditional UPDATE (`count < limit` in the WHERE clause), so
 * concurrent requests cannot overrun the limit.
 *
 * Backend selection: RATE_LIMIT_BACKEND = "memory" | "db" | "auto" (auto:
 * db for libsql:// / https:// DATABASE_URL, memory for local files).
 *
 * Fail-open policy: if the DB backend errors, requests are ALLOWED (with a
 * server-side error log) — a limiter outage must not take the whole API down;
 * the database being down fails every other request path anyway.
 */

import { db } from "./db";

interface Bucket {
  count: number;
  resetAt: number;
}

const memoryBuckets = new Map<string, Bucket>();
let lastSweep = Date.now();

export type RateLimitBackend = "memory" | "db";

export function rateLimitBackend(): RateLimitBackend {
  const configured = process.env.RATE_LIMIT_BACKEND?.trim().toLowerCase();
  if (configured === "memory" || configured === "db") return configured;
  const url = process.env.DATABASE_URL?.trim() ?? "";
  // Remote database (production / Workers) → shared bucket table.
  return url.startsWith("libsql://") || /^https:\/\//i.test(url) ? "db" : "memory";
}

function sweepMemory(now: number): void {
  if (now - lastSweep < 60_000) return;
  lastSweep = now;
  for (const [k, b] of memoryBuckets) {
    if (b.resetAt < now) memoryBuckets.delete(k);
  }
}

export interface RateLimitResult {
  ok: boolean;
  remaining: number;
  retryAfterSec: number;
}

async function rateLimitDb(key: string, limit: number, windowSec: number): Promise<RateLimitResult> {
  const now = Date.now();
  const windowMs = windowSec * 1000;

  // 1) Atomic increment when the current window exists and is not exhausted.
  const bumped = await db.rateLimitBucket.updateMany({
    where: { key, resetAt: { gt: new Date(now) }, count: { lt: limit } },
    data: { count: { increment: 1 } },
  });
  if (bumped.count === 1) {
    const row = await db.rateLimitBucket.findUnique({ where: { key }, select: { count: true, resetAt: true } });
    return {
      ok: true,
      remaining: Math.max(0, limit - (row?.count ?? 1)),
      retryAfterSec: 0,
    };
  }

  // 2) No bump: window missing/expired (reset it) OR exhausted (deny).
  const expired = await db.rateLimitBucket.updateMany({
    where: { key, resetAt: { lte: new Date(now) } },
    data: { count: 1, resetAt: new Date(now + windowMs) },
  });
  if (expired.count === 1) return { ok: true, remaining: limit - 1, retryAfterSec: 0 };

  const existing = await db.rateLimitBucket.findUnique({ where: { key }, select: { resetAt: true } });
  if (!existing) {
    // Row missing → create atomically; loser of a create race re-checks limit.
    try {
      await db.rateLimitBucket.create({ data: { key, count: 1, resetAt: new Date(now + windowMs) } });
      return { ok: true, remaining: limit - 1, retryAfterSec: 0 };
    } catch {
      const bumped2 = await db.rateLimitBucket.updateMany({
        where: { key, resetAt: { gt: new Date(now) }, count: { lt: limit } },
        data: { count: { increment: 1 } },
      });
      if (bumped2.count === 1) return { ok: true, remaining: 0, retryAfterSec: 0 };
    }
  }

  const resetAt = existing?.resetAt?.getTime() ?? now + windowMs;
  return {
    ok: false,
    remaining: 0,
    retryAfterSec: Math.max(1, Math.ceil((resetAt - now) / 1000)),
  };
}

// Opportunistic cleanup of long-expired rows (2% of allowed requests).
async function maybeCleanupDb(): Promise<void> {
  if (Math.random() >= 0.02) return;
  try {
    await db.rateLimitBucket.deleteMany({
      where: { resetAt: { lt: new Date(Date.now() - 3_600_000) } },
    });
  } catch {
    // cleanup is best-effort
  }
}

export async function rateLimit(key: string, limit: number, windowSec: number): Promise<RateLimitResult> {
  if (rateLimitBackend() === "db") {
    try {
      const result = await rateLimitDb(key, limit, windowSec);
      if (result.ok) void maybeCleanupDb();
      return result;
    } catch (err) {
      console.error("[rate-limit] db backend failed (fail-open):", err instanceof Error ? err.message : err);
      // fall through to memory for this request rather than rejecting traffic
    }
  }
  const now = Date.now();
  sweepMemory(now);
  const existing = memoryBuckets.get(key);
  if (!existing || existing.resetAt < now) {
    memoryBuckets.set(key, { count: 1, resetAt: now + windowSec * 1000 });
    return { ok: true, remaining: limit - 1, retryAfterSec: 0 };
  }
  existing.count += 1;
  if (existing.count > limit) {
    return {
      ok: false,
      remaining: 0,
      retryAfterSec: Math.max(1, Math.ceil((existing.resetAt - now) / 1000)),
    };
  }
  return { ok: true, remaining: limit - existing.count, retryAfterSec: 0 };
}

export function clientIp(req: Request): string {
  const fwd = req.headers.get("x-forwarded-for");
  if (fwd) return fwd.split(",")[0]!.trim();
  return req.headers.get("x-real-ip") ?? "unknown";
}
