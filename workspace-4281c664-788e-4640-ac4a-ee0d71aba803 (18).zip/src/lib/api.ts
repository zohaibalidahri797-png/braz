/**
 * API route helpers: consistent error envelope, auth guards, CSRF-style origin
 * check for mutations, and request context extraction.
 */

import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSessionUser, type SessionUser } from "@/lib/session";
import { clientIp } from "@/lib/rate-limit";

export function ok<T>(data: T, init?: ResponseInit): NextResponse {
  return NextResponse.json(data as Record<string, unknown>, init);
}

export function fail(status: number, error: string, extra?: Record<string, unknown>): NextResponse {
  return NextResponse.json({ error, ...extra }, { status });
}

export async function requireUser(): Promise<
  { user: SessionUser } | { response: NextResponse }
> {
  const user = await getSessionUser();
  if (!user) return { response: fail(401, "authentication_required") };
  return { user };
}

export async function requireAdmin(): Promise<
  { user: SessionUser } | { response: NextResponse }
> {
  const result = await requireUser();
  if ("response" in result) return result;
  if (result.user.role !== "ADMIN") return { response: fail(403, "admin_required") };
  return result;
}

/**
 * CSRF defense for cookie-authenticated mutations: when an Origin header is
 * present it must match the request host (or the configured APP_URL).
 */
export function originCheck(req: Request): NextResponse | null {
  if (req.method === "GET" || req.method === "HEAD") return null;
  const origin = req.headers.get("origin");
  if (!origin) return null; // non-browser clients (curl) — cookie still required
  try {
    const originHost = new URL(origin).host;
    const host = req.headers.get("host");
    const appUrlHost = process.env.APP_URL ? new URL(process.env.APP_URL).host : null;
    if (originHost === host || (appUrlHost && originHost === appUrlHost)) return null;
  } catch {
    // malformed origin → reject
  }
  return fail(403, "origin_not_allowed");
}

export interface ReqCtx {
  ip: string;
  userAgent: string | null;
}

export function reqCtx(req: Request): ReqCtx {
  return { ip: clientIp(req), userAgent: req.headers.get("user-agent") };
}

export async function readJson<T>(req: Request): Promise<T | null> {
  try {
    return (await req.json()) as T;
  } catch {
    return null;
  }
}

/** DB connectivity probe used by /api/health. */
export async function dbHealthy(): Promise<boolean> {
  try {
    await db.$queryRaw`SELECT 1`;
    return true;
  } catch {
    return false;
  }
}
