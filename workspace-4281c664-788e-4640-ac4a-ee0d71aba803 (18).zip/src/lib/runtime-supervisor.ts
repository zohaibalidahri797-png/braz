/**
 * Bot runtime service supervisor (server-only).
 *
 * When the runtime is EMBEDDED (development sandbox), the Next.js server
 * health-checks and spawns it:
 *   1. Resolve the runtime URL (RUNTIME_SERVICE_URL or localhost default).
 *   2. Health-check <url>/health with the shared API key.
 *   3. If unhealthy AND the URL points at this machine (loopback), spawn
 *      `bun src/index.ts` detached with the same resolved config.
 *   4. Re-check every 60s; respawn if it died.
 *
 * NEVER spawns when:
 *   - RUNTIME_EMBEDDED=false (production: runtime is a separate service), or
 *   - the resolved runtime URL is a non-loopback host (external runtime —
 *     spawning a local process cannot serve a remote URL).
 *
 * This is what keeps Cloudflare Workers (RUNTIME_EMBEDDED=false) from ever
 * attempting to spawn the runtime.
 */

import { spawn } from "node:child_process";
import { openSync } from "node:fs";
import path from "node:path";
import {
  isRuntimeEmbedded,
  resolveRuntimeUrl,
  runtimeApiKey,
  runtimeDataDir,
  runtimePort,
} from "./runtime-config";

let spawnInFlight = false;
let monitorStarted = false;

function urlIsLoopback(base: string): boolean {
  try {
    const { hostname } = new URL(base);
    const h = hostname.toLowerCase();
    return h === "localhost" || h === "127.0.0.1" || h === "[::1]" || h === "::1" || h.endsWith(".localhost");
  } catch {
    return false;
  }
}

async function isHealthy(baseUrl: string): Promise<boolean> {
  const key = runtimeApiKey();
  if (!key) return false;
  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 1500);
    const res = await fetch(`${baseUrl}/health`, {
      headers: { "X-Runtime-Key": key },
      signal: controller.signal,
      cache: "no-store",
    });
    clearTimeout(timer);
    if (!res.ok) return false;
    const body = (await res.json()) as { ok?: boolean; service?: string };
    return body.ok === true && body.service === "botdock-runtime";
  } catch {
    return false;
  }
}

export async function spawnRuntimeService(): Promise<boolean> {
  if (spawnInFlight) return false;
  spawnInFlight = true;
  try {
    const resolution = resolveRuntimeUrl();
    if (!resolution.url) {
      console.error(`[runtime-supervisor] runtime URL invalid: ${resolution.reason}`);
      return false;
    }
    if (!urlIsLoopback(resolution.url)) {
      console.warn(
        `[runtime-supervisor] RUNTIME_SERVICE_URL (${resolution.url}) is not local — not spawning an embedded runtime`,
      );
      return false;
    }
    if (await isHealthy(resolution.url)) return true;

    const cwd = path.resolve(process.cwd(), "mini-services/bot-runtime");
    const logPath = path.resolve(process.cwd(), "bot-runtime.log");
    const out = openSync(logPath, "a");
    const child = spawn("bun", ["src/index.ts"], {
      cwd,
      detached: true,
      stdio: ["ignore", out, out],
      env: {
        ...process.env,
        PORT: String(runtimePort()),
        RUNTIME_API_KEY: runtimeApiKey(),
        RUNTIME_DATA_DIR: runtimeDataDir(), // resolved absolute → both sides agree
        HOSTNAME: "127.0.0.1",
      },
    });
    child.unref();
    console.log(`[runtime-supervisor] spawned botdock-runtime (pid ${child.pid}), log: ${logPath}`);

    // wait up to 8s for it to become healthy
    for (let i = 0; i < 16; i++) {
      await new Promise((r) => setTimeout(r, 500));
      if (await isHealthy(resolution.url)) {
        console.log("[runtime-supervisor] botdock-runtime is healthy");
        return true;
      }
    }
    console.error("[runtime-supervisor] botdock-runtime did not become healthy within 8s");
    return false;
  } catch (err) {
    console.error("[runtime-supervisor] spawn failed:", err);
    return false;
  } finally {
    spawnInFlight = false;
  }
}

export async function ensureRuntime(): Promise<void> {
  const resolution = resolveRuntimeUrl();

  // Surface configuration mistakes instead of silently falling back.
  if (resolution.invalid) {
    console.error(`[runtime-supervisor] ${resolution.reason}`);
    return;
  }
  if (!isRuntimeEmbedded()) {
    console.log(
      `[runtime-supervisor] RUNTIME_EMBEDDED=false → external runtime expected at ${resolution.url}`,
    );
    return;
  }
  if (!urlIsLoopback(resolution.url)) {
    console.warn(
      `[runtime-supervisor] RUNTIME_SERVICE_URL (${resolution.url}) is not local; skipping embedded spawn (set RUNTIME_EMBEDDED=false to silence)`,
    );
    return;
  }
  if (!runtimeApiKey()) {
    console.error("[runtime-supervisor] RUNTIME_API_KEY missing; bot runtime will be unavailable");
    return;
  }

  await spawnRuntimeService();

  if (monitorStarted) return;
  monitorStarted = true;
  setInterval(() => {
    void (async () => {
      if (spawnInFlight) return;
      if (!(await isHealthy(resolveRuntimeUrl().url))) {
        console.warn("[runtime-supervisor] runtime unhealthy → respawning");
        await spawnRuntimeService();
      }
    })();
  }, 60_000).unref();
}
